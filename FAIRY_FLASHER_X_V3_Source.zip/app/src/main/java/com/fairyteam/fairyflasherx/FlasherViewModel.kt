package com.fairyteam.fairyflasherx

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fairyteam.fairyflasherx.adb.AdbConnection
import com.fairyteam.fairyflasherx.adb.AdbKeys
import com.fairyteam.fairyflasherx.fastboot.FastbootClient
import com.fairyteam.fairyflasherx.fastboot.FastbootFlasher
import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.io.TreeFile
import com.fairyteam.fairyflasherx.io.TreeIndex
import com.fairyteam.fairyflasherx.io.UriImageSource
import com.fairyteam.fairyflasherx.script.FlashScriptParser
import com.fairyteam.fairyflasherx.script.PlanItem
import com.fairyteam.fairyflasherx.script.ScriptExecutor
import com.fairyteam.fairyflasherx.script.ScriptHost
import com.fairyteam.fairyflasherx.script.ScriptStep
import com.fairyteam.fairyflasherx.script.SkippedStep
import com.fairyteam.fairyflasherx.script.fileTokenOf
import com.fairyteam.fairyflasherx.script.isLockStep
import com.fairyteam.fairyflasherx.script.isWipeStep
import com.fairyteam.fairyflasherx.usb.CancelToken
import com.fairyteam.fairyflasherx.usb.LinkKind
import com.fairyteam.fairyflasherx.usb.StopRequestedException
import com.fairyteam.fairyflasherx.usb.UsbCandidate
import com.fairyteam.fairyflasherx.usb.UsbLink
import com.fairyteam.fairyflasherx.usb.UsbScan
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class DeviceEntry(val key: String, val kind: LinkKind, val vidPid: String, val permitted: Boolean)

class DeviceInfo(
    val model: String = "",
    val android: String = "",
    val state: String = "",
    val extra: String = ""
)

class PartitionInfo(val name: String, val size: String, val type: String)

class StepView(val step: ScriptStep, val file: TreeFile?, val missing: Boolean)

enum class FlashMode(val label: String) {
    NORMAL("Normal (Recommended)"),
    ALL_SLOTS("Both slots (_a and _b)"),
    BOOT_ONLY("Boot once (do not flash)")
}

class FlasherViewModel(private val app: Application) : AndroidViewModel(app) {

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val keys: AdbKeys by lazy { AdbKeys(app.filesDir) }
    private val permLatches = ConcurrentHashMap<String, CountDownLatch>()
    private val askedPermission = HashSet<String>()
    private var lastInfoKey = ""
    private var candidates: List<UsbCandidate> = emptyList()
    private var cancelToken = CancelToken()

    // ---------------------------------------------------------------- observable state

    var devices by mutableStateOf<List<DeviceEntry>>(emptyList())
        private set
    var info by mutableStateOf(DeviceInfo())
        private set

    var busy by mutableStateOf(false)
        private set
    var busyTitle by mutableStateOf("")
        private set
    var progressValue by mutableStateOf(-1f)
        private set
    var progressLabel by mutableStateOf("")
        private set

    var logLines by mutableStateOf<List<String>>(emptyList())
        private set
    var showLog by mutableStateOf(false)

    var shellOutput by mutableStateOf("")
        private set
    var packages by mutableStateOf<List<String>>(emptyList())
        private set
    var partitions by mutableStateOf<List<PartitionInfo>>(emptyList())
        private set
    var showPartitions by mutableStateOf(false)

    // image flash
    var imageUri by mutableStateOf<Uri?>(null)
        private set
    var imageName by mutableStateOf("")
        private set
    var flashPartition by mutableStateOf("")
    var flashMode by mutableStateOf(FlashMode.NORMAL)

    // script flash
    var scriptName by mutableStateOf("")
        private set
    var folderName by mutableStateOf("")
        private set
    var steps by mutableStateOf<List<StepView>>(emptyList())
        private set
    var treeFileCount by mutableStateOf(0)
        private set
    var keepData by mutableStateOf(true)
    var skipLock by mutableStateOf(true)
    private var parsedSteps: List<ScriptStep> = emptyList()
    private var treeFiles: List<TreeFile> = emptyList()

    // sideload
    var sideloadUri by mutableStateOf<Uri?>(null)
        private set
    var sideloadName by mutableStateOf("")
        private set
    var sideloadSize by mutableStateOf(0L)
        private set

    // ---------------------------------------------------------------- log + progress

    private val logLock = Any()
    private val logBuffer = ArrayList<String>()
    private var lastProgressTs = 0L

    fun addLog(line: String) {
        synchronized(logLock) {
            logBuffer.add(line)
            while (logBuffer.size > 600) logBuffer.removeAt(0)
            logLines = ArrayList(logBuffer)
        }
    }

    fun clearLog() {
        synchronized(logLock) {
            logBuffer.clear()
            logLines = emptyList()
        }
    }

    private fun postProgress(fraction: Float, text: String) {
        val now = System.currentTimeMillis()
        if (fraction >= 0f && fraction < 0.999f && now - lastProgressTs < 120) return
        lastProgressTs = now
        progressValue = fraction
        progressLabel = text
    }

    // ---------------------------------------------------------------- USB plumbing

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (action == ACTION_PERMISSION) {
                for (l in permLatches.values) l.countDown()
                scan()
            } else if (action == UsbManager.ACTION_USB_DEVICE_ATTACHED || action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                scan()
            }
        }
    }

    init {
        val filter = IntentFilter()
        filter.addAction(ACTION_PERMISSION)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        addLog("Fairy Flasher X is ready. Connect a phone with a USB OTG cable.")
    }

    override fun onCleared() {
        try {
            app.unregisterReceiver(receiver)
        } catch (e: Exception) {
            // already gone
        }
    }

    private fun requestPermissionFor(device: UsbDevice) {
        val intent = Intent(ACTION_PERMISSION).setPackage(app.packageName)
        val pi = PendingIntent.getBroadcast(
            app, 0, intent, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        usb.requestPermission(device, pi)
    }

    fun requestPermission() {
        val c = candidates.firstOrNull() ?: return
        requestPermissionFor(c.device)
    }

    private fun ensurePermission(device: UsbDevice) {
        if (usb.hasPermission(device)) return
        val latch = CountDownLatch(1)
        permLatches[device.deviceName] = latch
        try {
            addLog("Requesting USB permission - tap OK on the popup")
            requestPermissionFor(device)
            latch.await(60, TimeUnit.SECONDS)
        } finally {
            permLatches.remove(device.deviceName)
        }
        if (!usb.hasPermission(device)) throw IOException("USB permission was denied")
    }

    /** Called from the UI every second or so, and from USB broadcasts. */
    fun scan() {
        val found: List<UsbCandidate> = try {
            UsbScan.find(usb)
        } catch (e: Exception) {
            emptyList()
        }
        candidates = found
        val fresh = found.map { DeviceEntry(it.key, it.kind, it.vidPid, usb.hasPermission(it.device)) }
        var same = fresh.size == devices.size
        if (same) {
            for (i in fresh.indices) {
                if (fresh[i].key != devices[i].key || fresh[i].permitted != devices[i].permitted) same = false
            }
        }
        if (!same) devices = fresh
        val primary = found.firstOrNull()
        if (primary == null) {
            if (lastInfoKey.isNotEmpty()) {
                lastInfoKey = ""
                info = DeviceInfo()
            }
            return
        }
        if (!usb.hasPermission(primary.device)) {
            if (askedPermission.add(primary.key)) requestPermissionFor(primary.device)
            return
        }
        if (primary.key != lastInfoKey && !busy) {
            lastInfoKey = primary.key
            refreshInfo()
        }
    }

    private fun modeName(kind: LinkKind): String = if (kind == LinkKind.ADB) "ADB" else "Fastboot"

    // ---------------------------------------------------------------- session

    private inner class Session(val cancel: CancelToken) : ScriptHost, Closeable {
        private var adbLink: UsbLink? = null
        private var adbConn: AdbConnection? = null
        private var fbLink: UsbLink? = null
        private var fbClient: FastbootClient? = null

        private fun await(kind: LinkKind, waitMs: Long): UsbCandidate {
            val deadline = System.currentTimeMillis() + waitMs
            var announced = false
            while (true) {
                cancel.check()
                val all = UsbScan.find(usb)
                val hit = all.firstOrNull { it.kind == kind }
                if (hit != null) return hit
                if (System.currentTimeMillis() >= deadline) {
                    val other = all.firstOrNull()
                    if (other != null) {
                        throw IOException(
                            "The connected device is in " + modeName(other.kind) +
                                " mode, but this action needs " + modeName(kind) + " mode"
                        )
                    }
                    if (kind == LinkKind.ADB) {
                        throw IOException("No ADB device found. Enable USB debugging (or boot to recovery) and connect with an OTG cable.")
                    }
                    throw IOException("No fastboot device found. Boot the phone to bootloader mode and connect with an OTG cable.")
                }
                if (!announced && waitMs > 0) {
                    addLog("Waiting for a " + modeName(kind) + " device...")
                    announced = true
                }
                Thread.sleep(400)
            }
        }

        override fun adb(waitMs: Long): AdbConnection {
            val existing = adbConn
            if (existing != null) return existing
            val cand = await(LinkKind.ADB, waitMs)
            ensurePermission(cand.device)
            val link = UsbLink(usb, cand.device, cand.iface, cancel)
            link.open()
            val conn = AdbConnection(link, keys, { msg -> addLog(msg) }, cancel)
            try {
                conn.connect()
            } catch (e: Throwable) {
                link.close()
                throw e
            }
            adbLink = link
            adbConn = conn
            return conn
        }

        override fun fastboot(waitMs: Long): FastbootClient {
            val existing = fbClient
            if (existing != null) return existing
            val cand = await(LinkKind.FASTBOOT, waitMs)
            ensurePermission(cand.device)
            val link = UsbLink(usb, cand.device, cand.iface, cancel)
            link.open()
            val client = FastbootClient(link) { msg -> addLog(msg) }
            fbLink = link
            fbClient = client
            return client
        }

        override fun closeAdb() {
            try {
                adbConn?.close()
            } catch (e: Exception) {
                // ignore
            }
            adbLink?.close()
            adbConn = null
            adbLink = null
        }

        override fun closeFastboot() {
            fbLink?.close()
            fbClient = null
            fbLink = null
        }

        override fun log(text: String) {
            addLog(text)
        }

        override fun progress(fraction: Float, text: String) {
            postProgress(fraction, text)
        }

        override fun open(file: TreeFile): ImageSource = UriImageSource(app.contentResolver, file.uri)

        override fun close() {
            closeAdb()
            closeFastboot()
        }
    }

    private fun launchOp(title: String, quiet: Boolean = false, block: (Session) -> Unit) {
        if (busy) {
            addLog("Another operation is still running")
            return
        }
        busy = true
        busyTitle = title
        progressValue = -1f
        progressLabel = ""
        val token = CancelToken()
        cancelToken = token
        if (!quiet) addLog("> $title")
        viewModelScope.launch(Dispatchers.IO) {
            val session = Session(token)
            try {
                block(session)
                if (!quiet) addLog("OK  $title - done")
            } catch (e: StopRequestedException) {
                addLog("Stopped by user")
            } catch (e: Throwable) {
                addLog("ERROR  $title failed: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                session.close()
                withContext(NonCancellable + Dispatchers.Main) {
                    busy = false
                    progressValue = -1f
                    progressLabel = ""
                    scan()
                }
            }
        }
    }

    fun stop() {
        cancelToken.cancelled = true
    }

    // ---------------------------------------------------------------- device info

    fun refreshInfo() {
        if (candidates.isEmpty() || busy) return
        launchOp("Reading device info", true) { s -> readInfo(s) }
    }

    private fun readInfo(s: Session) {
        val cand = UsbScan.find(usb).firstOrNull() ?: return
        if (cand.kind == LinkKind.ADB) {
            val c = s.adb(0L)
            val model = c.bannerProp("ro.product.model") ?: c.bannerProp("ro.product.name") ?: ""
            var android = ""
            if (c.state == "device" || c.state == "recovery") {
                try {
                    android = c.shell("getprop ro.build.version.release", 10_000L).trim()
                } catch (e: StopRequestedException) {
                    throw e
                } catch (e: Exception) {
                    android = ""
                }
            }
            info = DeviceInfo(model, android, c.state)
        } else {
            val fb = s.fastboot(0L)
            val product = fb.getvar("product") ?: ""
            val userspace = fb.getvar("is-userspace") == "yes"
            val unlocked = fb.getvar("unlocked")
            val slot = fb.currentSlot()
            val extra = StringBuilder()
            if (unlocked != null) extra.append("Bootloader unlocked: ").append(unlocked).append("  ")
            if (slot != null) extra.append("Slot: ").append(slot)
            info = DeviceInfo(product, "", if (userspace) "fastbootd" else "bootloader", extra.toString().trim())
        }
    }

    // ---------------------------------------------------------------- ADB actions

    fun adbDetect() {
        launchOp("Detect ADB device") { s ->
            readInfo(s)
            addLog("Mode: " + info.state + (if (info.model.isNotEmpty()) "   Model: " + info.model else "") +
                (if (info.android.isNotEmpty()) "   Android: " + info.android else ""))
        }
    }

    fun adbReboot(target: String) {
        val name = if (target.isEmpty()) "system" else target
        launchOp("ADB reboot to $name") { s ->
            s.adb(0L).reboot(target)
            addLog("Reboot command sent")
        }
    }

    fun adbShellRun(command: String) {
        if (command.isBlank()) return
        launchOp("Shell: $command") { s ->
            val out = s.adb(0L).shell(command)
            shellOutput = if (out.isBlank()) "(no output)" else out
            addLog("$ $command")
            for (l in out.trimEnd().split('\n').take(200)) addLog(l)
        }
    }

    fun adbInstall(uri: Uri) {
        val name = queryName(uri)
        launchOp("Install $name") { s ->
            val c = s.adb(0L)
            val tmp = "/data/local/tmp/fairy_install.apk"
            UriImageSource(app.contentResolver, uri).use { src ->
                addLog("Copying " + name + " (" + formatSize(src.size) + ") to the device")
                c.push(src, tmp) { d, t -> postProgress(d.toFloat() / t, "Copying $name") }
            }
            postProgress(-1f, "Installing...")
            val out = c.shell("pm install -r $tmp", 300_000L)
            addLog(out.trim())
            try {
                c.shell("rm -f $tmp", 20_000L)
            } catch (e: Exception) {
                // not important
            }
            if (!out.contains("Success")) throw IOException("Install failed: " + out.trim())
        }
    }

    fun adbListPackages() {
        launchOp("List installed apps") { s ->
            val out = s.adb(0L).shell("pm list packages -3", 30_000L)
            packages = out.lines().map { it.trim().removePrefix("package:") }.filter { it.isNotEmpty() }.sorted()
            addLog("Found " + packages.size + " user apps")
        }
    }

    fun adbUninstall(pkg: String) {
        val p = pkg.trim()
        if (!Regex("^[A-Za-z0-9._]+$").matches(p)) {
            addLog("Invalid package name")
            return
        }
        launchOp("Uninstall $p") { s ->
            val out = s.adb(0L).shell("pm uninstall $p", 60_000L)
            addLog(out.trim())
            if (!out.contains("Success")) throw IOException("Uninstall failed: " + out.trim())
        }
    }

    fun adbPush(uri: Uri, remoteDir: String) {
        val name = queryName(uri)
        var target = remoteDir.trim()
        if (target.isEmpty()) target = "/sdcard/Download/"
        if (target.endsWith("/")) target += name
        val finalTarget = target
        launchOp("Push $name") { s ->
            val c = s.adb(0L)
            UriImageSource(app.contentResolver, uri).use { src ->
                addLog("Pushing to $finalTarget (" + formatSize(src.size) + ")")
                c.push(src, finalTarget) { d, t -> postProgress(d.toFloat() / t, "Pushing $name") }
            }
        }
    }

    fun adbPull(remote: String, out: Uri) {
        val r = remote.trim()
        if (r.isEmpty()) {
            addLog("Enter the remote file path")
            return
        }
        launchOp("Pull $r") { s ->
            val c = s.adb(0L)
            val stream = app.contentResolver.openOutputStream(out) ?: throw IOException("Cannot write the destination file")
            stream.use { os ->
                c.pull(r, os) { d, t -> postProgress(if (t > 0) d.toFloat() / t else -1f, "Pulling " + formatSize(d)) }
            }
        }
    }

    // ---------------------------------------------------------------- Fastboot actions

    fun fbDetect() {
        launchOp("Detect fastboot device") { s ->
            readInfo(s)
            addLog("Mode: " + info.state + (if (info.model.isNotEmpty()) "   Product: " + info.model else "") +
                (if (info.extra.isNotEmpty()) "   " + info.extra else ""))
            val fb = s.fastboot(0L)
            addLog("Max download size: " + formatSize(fb.getMaxDownload()))
        }
    }

    fun fbReboot(target: String) {
        val name = if (target.isEmpty()) "system" else target
        launchOp("Fastboot reboot to $name") { s ->
            s.fastboot(0L).reboot(target)
            addLog("Reboot command sent")
        }
    }

    fun fbPartitionInfo() {
        launchOp("Read partition info") { s ->
            val fb = s.fastboot(0L)
            val lines = fb.getAllVars()
            val sizes = LinkedHashMap<String, String>()
            val types = HashMap<String, String>()
            val other = ArrayList<String>()
            for (l in lines) {
                val t = l.trim().removePrefix("(bootloader)").trim()
                if (t.startsWith("partition-size:")) {
                    val rest = t.removePrefix("partition-size:")
                    sizes[rest.substringBefore(':').trim()] = rest.substringAfter(':', "").trim()
                } else if (t.startsWith("partition-type:")) {
                    val rest = t.removePrefix("partition-type:")
                    types[rest.substringBefore(':').trim()] = rest.substringAfter(':', "").trim()
                } else if (t.isNotEmpty()) {
                    other.add(t)
                }
            }
            partitions = sizes.map { PartitionInfo(it.key, hexSize(it.value), types[it.key] ?: "") }
            for (l in other.take(40)) addLog(l)
            addLog("Found " + partitions.size + " partitions")
            showPartitions = true
        }
    }

    private fun hexSize(v: String): String {
        val t = v.trim()
        val n = if (t.startsWith("0x") || t.startsWith("0X")) t.substring(2).toLongOrNull(16) else t.toLongOrNull()
        return if (n == null) t else formatSize(n)
    }

    fun fbErase(partition: String) {
        val p = partition.trim()
        if (p.isEmpty()) return
        launchOp("Erase $p") { s ->
            val fb = s.fastboot(0L)
            for (t in FastbootFlasher.resolvePartitions(fb, p, null)) {
                addLog("Erasing $t")
                fb.command("erase:$t", 600_000L)
            }
        }
    }

    fun fbSetActive(slot: String) {
        launchOp("Set active slot $slot") { s ->
            s.fastboot(0L).command("set_active:$slot", 30_000L)
        }
    }

    fun fbCustom(text: String) {
        var cmd = text.trim()
        if (cmd.isEmpty()) return
        if (!cmd.contains(':')) {
            val first = cmd.substringBefore(' ')
            if (first == "getvar" || first == "erase" || first == "set_active") {
                cmd = first + ":" + cmd.substringAfter(' ', "").trim()
            }
        }
        val finalCmd = cmd
        launchOp("fastboot $finalCmd") { s ->
            val r = s.fastboot(0L).command(finalCmd, 300_000L)
            if (r.isNotEmpty()) addLog(r)
        }
    }

    fun quickReboot(target: String) {
        val kind = candidates.firstOrNull()?.kind
        if (kind == null) {
            addLog("No device connected")
        } else if (kind == LinkKind.ADB) {
            adbReboot(target)
        } else {
            fbReboot(target)
        }
    }

    // ---------------------------------------------------------------- single image flash

    fun pickImage(uri: Uri) {
        imageUri = uri
        imageName = queryName(uri)
        if (flashPartition.isBlank()) {
            val base = imageName.substringBeforeLast('.').lowercase()
            val known = listOf(
                "boot", "init_boot", "vendor_boot", "recovery", "dtbo", "vbmeta", "vbmeta_system", "vbmeta_vendor",
                "system", "vendor", "product", "system_ext", "odm", "super", "userdata", "modem", "persist"
            )
            if (known.contains(base)) flashPartition = base
        }
    }

    fun startImageFlash() {
        val uri = imageUri
        if (uri == null) {
            addLog("Select an image file first")
            return
        }
        val part = flashPartition.trim()
        val mode = flashMode
        if (part.isEmpty() && mode != FlashMode.BOOT_ONLY) {
            addLog("Enter the target partition (for example boot)")
            return
        }
        launchOp("Flash $imageName") { s ->
            val fb = s.fastboot(0L)
            UriImageSource(app.contentResolver, uri).use { src ->
                if (mode == FlashMode.BOOT_ONLY) {
                    addLog("Booting " + imageName + " once (nothing is written)")
                    FastbootFlasher.bootImage(fb, src, s.cancel) { d, t -> postProgress(d.toFloat() / t, "Sending image") }
                } else {
                    val slot = if (mode == FlashMode.ALL_SLOTS) "all" else null
                    val targets = FastbootFlasher.resolvePartitions(fb, part, slot)
                    val maxDl = fb.getMaxDownload()
                    for (target in targets) {
                        addLog("Flashing " + imageName + " -> " + target + " (" + formatSize(src.size) + ")")
                        FastbootFlasher.flash(
                            fb, target, src, maxDl, s.cancel,
                            { d, t -> postProgress(d.toFloat() / t, "Flashing $target") },
                            { msg -> addLog(msg) }
                        )
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- script flash (.bat / .sh + images folder)

    fun pickScript(uri: Uri) {
        scriptName = queryName(uri)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = app.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open the script")
                val bytes = stream.use { it.readBytes() }
                if (bytes.size > 2 * 1024 * 1024) throw IOException("That file is too large to be a flash script")
                val text = String(bytes, Charsets.UTF_8)
                val ext = scriptName.substringAfterLast('.', "").lowercase()
                val isBat = ext == "bat" || ext == "cmd" || (ext != "sh" && text.contains("%~dp0"))
                parsedSteps = FlashScriptParser.parse(text, isBat)
                withContext(Dispatchers.Main) { rebuildPlan() }
                val flashCount = parsedSteps.count { it !is SkippedStep }
                addLog("Script loaded: " + scriptName + " - " + flashCount + " actions found")
            } catch (e: Exception) {
                addLog("Could not read the script: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    fun pickFolder(uri: Uri) {
        folderName = DocumentsContract.getTreeDocumentId(uri).substringAfterLast(':').substringAfterLast('/')
            .ifEmpty { "folder" }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val files = TreeIndex.scan(app.contentResolver, uri)
                treeFiles = files
                withContext(Dispatchers.Main) {
                    treeFileCount = files.size
                    rebuildPlan()
                }
                addLog("Folder scanned: " + files.size + " files")
            } catch (e: Exception) {
                addLog("Could not read the folder: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun rebuildPlan() {
        val haveFolder = treeFiles.isNotEmpty()
        steps = parsedSteps.map { st ->
            val token = fileTokenOf(st)
            val f = if (token != null && haveFolder) TreeIndex.resolve(treeFiles, token) else null
            StepView(st, f, token != null && haveFolder && f == null)
        }
    }

    /** Why a step will not run with the current switches, or null if it will run. */
    fun skipReason(v: StepView): String? {
        if (v.step is SkippedStep) return "not supported"
        if (keepData && isWipeStep(v.step)) return "keeps your data"
        if (skipLock && isLockStep(v.step)) return "lock/unlock skipped"
        return null
    }

    fun missingFiles(): List<String> {
        return steps.filter { it.missing && skipReason(it) == null }.mapNotNull { fileTokenOf(it.step) }
    }

    fun startScriptFlash() {
        if (steps.isEmpty()) {
            addLog("Select a flash script first")
            return
        }
        if (treeFiles.isEmpty()) {
            addLog("Select the images folder first")
            return
        }
        val missing = missingFiles()
        if (missing.isNotEmpty()) {
            addLog("These files are missing in the selected folder: " + missing.joinToString(", "))
            return
        }
        val items = steps.map { PlanItem(it.step, it.file) }
        val keep = keepData
        val noLock = skipLock
        launchOp("Flash script $scriptName") { s ->
            ScriptExecutor(s, s.cancel).run(items, keep, noLock)
        }
    }

    // ---------------------------------------------------------------- sideload

    fun pickSideload(uri: Uri) {
        sideloadUri = uri
        sideloadName = queryName(uri)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                UriImageSource(app.contentResolver, uri).use { sideloadSize = it.size }
            } catch (e: Exception) {
                sideloadSize = 0L
            }
        }
    }

    fun startSideload() {
        val uri = sideloadUri
        if (uri == null) {
            addLog("Select a ROM zip first")
            return
        }
        launchOp("ADB sideload $sideloadName") { s ->
            val c = s.adb(0L)
            if (c.state != "sideload") {
                addLog("Device state is '" + c.state + "'. In recovery choose: Apply update > Apply from ADB, then try again if this fails.")
            }
            UriImageSource(app.contentResolver, uri).use { src ->
                addLog("Sending " + formatSize(src.size) + " to the recovery")
                c.sideload(src) { d, t ->
                    postProgress(d.toFloat() / t, "Sideloading " + (d * 100 / t) + "%")
                }
            }
            addLog("Transfer finished. Follow the recovery screen on the phone.")
        }
    }

    // ---------------------------------------------------------------- misc

    private fun queryName(uri: Uri): String {
        try {
            val cursor = app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null) {
                cursor.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (n != null) return n
                    }
                }
            }
        } catch (e: Exception) {
            // fall through
        }
        return uri.lastPathSegment ?: "file"
    }

    companion object {
        const val ACTION_PERMISSION = "com.fairyteam.fairyflasherx.USB_PERMISSION"
    }
}

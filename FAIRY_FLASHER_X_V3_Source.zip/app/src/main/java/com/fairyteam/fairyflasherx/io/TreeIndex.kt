package com.fairyteam.fairyflasherx.io

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract

/** One file inside a folder picked with the Storage Access Framework. */
class TreeFile(val relPath: String, val name: String, val uri: Uri, val size: Long)

object TreeIndex {
    fun scan(cr: ContentResolver, treeUri: Uri, maxDepth: Int = 5, maxFiles: Int = 20000): List<TreeFile> {
        val out = ArrayList<TreeFile>()
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)

        fun walk(docId: String, prefix: String, depth: Int) {
            if (out.size >= maxFiles) return
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            val cursor = cr.query(childrenUri, cols, null, null, null) ?: return
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1)
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    if (id == null || name == null) continue
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < maxDepth) walk(id, prefix + name + "/", depth + 1)
                    } else {
                        out.add(TreeFile(prefix + name, name, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), size))
                    }
                }
            }
        }

        walk(rootId, "", 0)
        return out
    }

    /** Normalises a path taken from a script: slashes, leading "./" and "../". */
    fun normalize(token: String): String {
        var t = token.trim().replace('\\', '/')
        while (t.contains("//")) t = t.replace("//", "/")
        while (t.startsWith("./") || t.startsWith("../") || t.startsWith("/")) {
            t = if (t.startsWith("./")) t.substring(2) else if (t.startsWith("../")) t.substring(3) else t.substring(1)
        }
        return t
    }

    /** Finds the file a script refers to, matching on the longest possible path suffix. */
    fun resolve(files: List<TreeFile>, token: String): TreeFile? {
        val norm = normalize(token).lowercase()
        if (norm.isEmpty()) return null
        val segs = norm.split('/')
        for (drop in segs.indices) {
            val sub = segs.drop(drop).joinToString("/")
            val matches = files.filter {
                val rp = it.relPath.lowercase()
                rp == sub || rp.endsWith("/$sub")
            }
            if (matches.size == 1) return matches[0]
            if (matches.size > 1) return matches.minByOrNull { it.relPath.length }
        }
        return null
    }
}

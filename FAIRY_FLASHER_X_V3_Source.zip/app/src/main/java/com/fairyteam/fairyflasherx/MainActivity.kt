package com.fairyteam.fairyflasherx

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.fairyteam.fairyflasherx.ui.AboutScreen
import com.fairyteam.fairyflasherx.ui.AdbScreen
import com.fairyteam.fairyflasherx.ui.BusyCard
import com.fairyteam.fairyflasherx.ui.Blue
import com.fairyteam.fairyflasherx.ui.DevicesScreen
import com.fairyteam.fairyflasherx.ui.FastbootScreen
import com.fairyteam.fairyflasherx.ui.GlassBackground
import com.fairyteam.fairyflasherx.ui.HomeScreen
import com.fairyteam.fairyflasherx.ui.LogDialog
import com.fairyteam.fairyflasherx.ui.Muted
import com.fairyteam.fairyflasherx.ui.RomScreen
import com.fairyteam.fairyflasherx.ui.Screen
import com.fairyteam.fairyflasherx.ui.SplashScreen
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: FlasherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        setContent { FairyApp(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.scan()
    }
}

@Composable
fun FairyApp(vm: FlasherViewModel) {
    var showSplash by remember { mutableStateOf(true) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var romTab by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        delay(2300)
        showSplash = false
    }
    LaunchedEffect(Unit) {
        while (true) {
            vm.scan()
            delay(1500)
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) {
        if (showSplash) {
            SplashScreen()
        } else {
            BackHandler(enabled = screen != Screen.Home) { screen = Screen.Home }
            GlassBackground {
                Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                    Box(Modifier.weight(1f)) {
                        AnimatedContent(
                            targetState = screen,
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                            label = "screen"
                        ) { s ->
                            when (s) {
                                Screen.Home -> HomeScreen(vm) { screen = it }
                                Screen.Adb -> AdbScreen(vm) { screen = Screen.Home }
                                Screen.Fastboot -> FastbootScreen(vm, { screen = Screen.Home }) {
                                    romTab = 0
                                    screen = Screen.Rom
                                }
                                Screen.Rom -> RomScreen(vm, romTab, { romTab = it }) { screen = Screen.Home }
                                Screen.Devices -> DevicesScreen(vm) { screen = Screen.Home }
                                Screen.About -> AboutScreen { screen = Screen.Home }
                            }
                        }
                    }
                    if (vm.busy) BusyCard(vm)
                    BottomBar(screen) { screen = it }
                }
                if (vm.showLog) LogDialog(vm)
            }
        }
    }
}

@Composable
fun BottomBar(current: Screen, onSelect: (Screen) -> Unit) {
    NavigationBar(containerColor = Color.White.copy(alpha = 0.72f)) {
        val items = listOf(
            Triple(Screen.Home, "Home", Icons.Default.Home),
            Triple(Screen.Adb, "ADB", Icons.Default.Terminal),
            Triple(Screen.Fastboot, "Fastboot", Icons.Default.FlashOn),
            Triple(Screen.Rom, "ROM", Icons.Default.Memory)
        )
        for ((target, label, icon) in items) {
            NavigationBarItem(
                selected = current == target,
                onClick = { onSelect(target) },
                icon = { Icon(icon, null) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Blue,
                    selectedTextColor = Blue,
                    indicatorColor = Blue.copy(alpha = 0.16f),
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}

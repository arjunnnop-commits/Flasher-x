package com.fairyteam.fairyflasherx.io

import android.content.ContentResolver
import android.net.Uri
import java.io.Closeable
import java.io.EOFException
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/** Random access, read-only file. */
interface ImageSource : Closeable {
    val size: Long
    fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int
}

fun ImageSource.readFullyAt(pos: Long, buf: ByteArray, off: Int, len: Int) {
    var done = 0
    while (done < len) {
        val r = readAt(pos + done, buf, off + done, len - done)
        if (r <= 0) throw EOFException("Unexpected end of file")
        done += r
    }
}

/** A file picked through the Storage Access Framework. */
class UriImageSource(cr: ContentResolver, uri: Uri) : ImageSource {
    private val pfd = cr.openFileDescriptor(uri, "r")
        ?: throw IOException("Cannot open the selected file")
    private val channel: FileChannel = FileInputStream(pfd.fileDescriptor).channel

    override val size: Long

    init {
        val s = pfd.statSize
        size = if (s > 0) s else channel.size()
    }

    override fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        return channel.read(ByteBuffer.wrap(buf, off, len), pos)
    }

    override fun close() {
        try {
            channel.close()
        } catch (e: Exception) {
        }
        try {
            pfd.close()
        } catch (e: Exception) {
        }
    }
}

package com.fairyteam.fairyflasherx.adb

import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.io.readFullyAt
import com.fairyteam.fairyflasherx.usb.CancelToken
import com.fairyteam.fairyflasherx.usb.StopRequestedException
import com.fairyteam.fairyflasherx.usb.UsbLink
import java.io.Closeable
import java.io.EOFException
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

private const val A_CNXN = 0x4e584e43
private const val A_OPEN = 0x4e45504f
private const val A_OKAY = 0x59414b4f
private const val A_CLSE = 0x45534c43
private const val A_WRTE = 0x45545257
private const val A_AUTH = 0x48545541

private const val AUTH_TOKEN = 1
private const val AUTH_SIGNATURE = 2
private const val AUTH_RSAPUBLICKEY = 3

private const val ADB_VERSION = 0x01000000
private const val MAX_PAYLOAD = 256 * 1024

class AdbMessage(val cmd: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

/**
 * Minimal ADB-over-USB client. Everything is synchronous and single threaded:
 * one stream is used at a time, which is all the flasher needs.
 */
class AdbConnection(
    private val link: UsbLink,
    private val keys: AdbKeys,
    private val log: (String) -> Unit,
    private val cancel: CancelToken
) : Closeable {

    var maxData: Int = 4096
        private set
    var banner: String = ""
        private set

    /** "device", "recovery", "sideload", "bootloader" or "host". */
    val state: String get() = banner.substringBefore(':')

    private var nextLocalId = 1
    private val streams = HashMap<Int, AdbStream>()
    private val headerBuf = ByteArray(24)

    fun bannerProp(name: String): String? {
        val props = banner.substringAfter("::", "")
        for (p in props.split(';')) {
            val k = p.substringBefore('=')
            if (k == name) return p.substringAfter('=', "")
        }
        return null
    }

    // ---------------------------------------------------------------- low level

    internal fun sendMessage(cmd: Int, arg0: Int, arg1: Int, data: ByteArray?, off: Int = 0, len: Int = data?.size ?: 0) {
        var sum = 0
        if (data != null) {
            for (i in off until off + len) sum += data[i].toInt() and 0xFF
        }
        val bb = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(cmd)
        bb.putInt(arg0)
        bb.putInt(arg1)
        bb.putInt(len)
        bb.putInt(sum)
        bb.putInt(cmd.inv())
        link.write(bb.array(), 0, 24)
        if (data != null && len > 0) link.write(data, off, len)
    }

    internal fun readMessage(timeoutMs: Long): AdbMessage {
        link.readFully(headerBuf, 24, timeoutMs)
        val bb = ByteBuffer.wrap(headerBuf).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.getInt()
        val arg0 = bb.getInt()
        val arg1 = bb.getInt()
        val len = bb.getInt()
        bb.getInt() // data checksum, not verified
        val magic = bb.getInt()
        if (magic != cmd.inv()) throw IOException("Corrupt ADB packet received")
        if (len < 0 || len > 4 * 1024 * 1024) throw IOException("Invalid ADB packet size")
        val data = ByteArray(len)
        if (len > 0) link.readFully(data, len, timeoutMs)
        return AdbMessage(cmd, arg0, arg1, data)
    }

    /** Reads one message and routes it to the stream it belongs to. */
    internal fun pump(timeoutMs: Long) {
        val m = readMessage(timeoutMs)
        val s = streams[m.arg1] ?: return
        when (m.cmd) {
            A_OKAY -> {
                if (!s.opened) {
                    s.remoteId = m.arg0
                    s.opened = true
                } else {
                    s.okayCount++
                }
            }
            A_WRTE -> {
                s.queue.add(m.data)
                sendMessage(A_OKAY, s.localId, s.remoteId, null)
            }
            A_CLSE -> {
                s.closed = true
            }
            else -> {}
        }
    }

    // ---------------------------------------------------------------- handshake

    fun connect(authTimeoutMs: Long = 90_000) {
        sendMessage(A_CNXN, ADB_VERSION, MAX_PAYLOAD, "host::\u0000".toByteArray(Charsets.US_ASCII))
        var sentSignature = false
        var sentKey = false
        while (true) {
            cancel.check()
            val m = readMessage(if (sentKey) authTimeoutMs else 15_000L)
            when (m.cmd) {
                A_AUTH -> {
                    if (m.arg0 == AUTH_TOKEN) {
                        if (!sentSignature) {
                            sentSignature = true
                            sendMessage(A_AUTH, AUTH_SIGNATURE, 0, keys.sign(m.data))
                        } else if (!sentKey) {
                            sentKey = true
                            log("Waiting for you to tap \"Allow USB debugging\" on the target device...")
                            sendMessage(A_AUTH, AUTH_RSAPUBLICKEY, 0, keys.publicKeyPayload())
                        } else {
                            throw IOException("USB debugging was not authorised on the target device")
                        }
                    }
                }
                A_CNXN -> {
                    maxData = if (m.arg1 in 1..MAX_PAYLOAD) m.arg1 else if (m.arg1 > MAX_PAYLOAD) MAX_PAYLOAD else 4096
                    banner = String(m.data, Charsets.UTF_8).trim { it <= ' ' }
                    return
                }
                else -> {}
            }
        }
    }

    // ---------------------------------------------------------------- streams

    fun openStream(service: String, timeoutMs: Long = 20_000): AdbStream {
        val localId = nextLocalId++
        val s = AdbStream(this, localId)
        streams[localId] = s
        sendMessage(A_OPEN, localId, 0, (service + "\u0000").toByteArray(Charsets.UTF_8))
        while (!s.opened) {
            if (s.closed) {
                streams.remove(localId)
                throw IOException("The device refused the service \"" + service.substringBefore(':') + "\"")
            }
            pump(timeoutMs)
        }
        return s
    }

    internal fun releaseStream(s: AdbStream) {
        streams.remove(s.localId)
    }

    internal fun sendClose(s: AdbStream) {
        try {
            sendMessage(A_CLSE, s.localId, s.remoteId, null)
        } catch (e: Exception) {
            // device already gone
        }
    }

    // ---------------------------------------------------------------- high level helpers

    /** Runs a shell command and returns everything it printed. */
    fun shell(command: String, timeoutMs: Long = 120_000): String {
        val s = openStream("shell:$command")
        val out = java.io.ByteArrayOutputStream()
        try {
            val buf = ByteArray(8192)
            while (true) {
                val n = s.read(buf, 0, buf.size, timeoutMs)
                if (n < 0) break
                out.write(buf, 0, n)
            }
        } finally {
            s.close()
        }
        return String(out.toByteArray(), Charsets.UTF_8).replace("\r\n", "\n")
    }

    fun reboot(target: String) {
        val service = if (target.isEmpty()) "reboot:" else "reboot:$target"
        try {
            val s = openStream(service, 10_000)
            try {
                s.read(ByteArray(64), 0, 64, 5_000)
            } catch (e: IOException) {
                // the device drops off the bus while rebooting
            }
        } catch (e: StopRequestedException) {
            throw e
        } catch (e: IOException) {
            // connection ended because the device is rebooting
        }
    }

    /** Pushes [src] to [remotePath] using the sync protocol. */
    fun push(src: ImageSource, remotePath: String, onProgress: (Long, Long) -> Unit) {
        val s = openStream("sync:")
        try {
            val pathMode = (remotePath + ",33206").toByteArray(Charsets.UTF_8)
            s.write(syncHeader("SEND", pathMode.size) + pathMode)
            val buf = ByteArray(65536 + 8)
            var pos = 0L
            while (pos < src.size) {
                val want = minOf(65536L, src.size - pos).toInt()
                src.readFullyAt(pos, buf, 8, want)
                val h = syncHeader("DATA", want)
                System.arraycopy(h, 0, buf, 0, 8)
                s.write(buf, 0, 8 + want)
                pos += want
                onProgress(pos, src.size)
            }
            val done = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            done.put("DONE".toByteArray(Charsets.US_ASCII))
            done.putInt((System.currentTimeMillis() / 1000).toInt())
            s.write(done.array())
            val resp = s.readFully(8, 120_000)
            val id = String(resp, 0, 4, Charsets.US_ASCII)
            if (id != "OKAY") {
                val len = ByteBuffer.wrap(resp, 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt()
                val msg = if (len in 1..4096) String(s.readFully(len, 10_000), Charsets.UTF_8) else "unknown error"
                throw IOException("Push failed: $msg")
            }
            try {
                s.write(syncHeader("QUIT", 0))
            } catch (e: IOException) {
                // ignore
            }
        } finally {
            s.close()
        }
    }

    /** Pulls [remotePath] into [out]. */
    fun pull(remotePath: String, out: OutputStream, onProgress: (Long, Long) -> Unit) {
        val s = openStream("sync:")
        try {
            val path = remotePath.toByteArray(Charsets.UTF_8)
            s.write(syncHeader("STAT", path.size) + path)
            val st = s.readFully(16, 20_000)
            val sb = ByteBuffer.wrap(st).order(ByteOrder.LITTLE_ENDIAN)
            sb.getInt() // id
            val mode = sb.getInt()
            val size = sb.getInt().toLong() and 0xFFFFFFFFL
            if (mode == 0) throw IOException("Remote file not found: $remotePath")
            s.write(syncHeader("RECV", path.size) + path)
            var got = 0L
            while (true) {
                val h = s.readFully(8, 60_000)
                val id = String(h, 0, 4, Charsets.US_ASCII)
                val len = ByteBuffer.wrap(h, 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt()
                if (id == "DATA") {
                    var left = len
                    while (left > 0) {
                        val chunk = s.readSome(minOf(left, 65536), 60_000)
                        out.write(chunk, 0, chunk.size)
                        left -= chunk.size
                        got += chunk.size
                    }
                    onProgress(got, if (size > 0) size else got)
                } else if (id == "DONE") {
                    break
                } else if (id == "FAIL") {
                    val msg = if (len in 1..4096) String(s.readFully(len, 10_000), Charsets.UTF_8) else "unknown error"
                    throw IOException("Pull failed: $msg")
                } else {
                    throw IOException("Unexpected sync reply: $id")
                }
            }
        } finally {
            s.close()
        }
    }

    /**
     * ADB sideload (host side of "adb sideload"). The recovery asks for 64 KiB blocks by number
     * and finishes with "DONEDONE".
     */
    fun sideload(src: ImageSource, onProgress: (Long, Long) -> Unit) {
        val blockSize = 65536
        val total = src.size
        val s = openStream("sideload-host:$total:$blockSize", 30_000)
        val buf = ByteArray(blockSize)
        var servedLast = false
        try {
            while (true) {
                val req = try {
                    s.readFully(8, 180_000)
                } catch (e: EOFException) {
                    if (servedLast) return
                    throw IOException("The device closed the sideload session early")
                }
                val text = String(req, Charsets.US_ASCII)
                if (text == "DONEDONE") return
                if (text.startsWith("FAIL")) throw IOException("Device reported a sideload failure")
                val block = text.trim { it <= ' ' || it == '\u0000' }.toLongOrNull()
                    ?: throw IOException("Bad block request from device: $text")
                val offset = block * blockSize
                if (offset >= total) throw IOException("Device requested a block beyond the end of the file")
                val n = minOf(blockSize.toLong(), total - offset).toInt()
                src.readFullyAt(offset, buf, 0, n)
                s.write(buf, 0, n)
                if (offset + n >= total) servedLast = true
                onProgress(minOf(offset + n, total), total)
            }
        } finally {
            s.close()
        }
    }

    private fun syncHeader(id: String, len: Int): ByteArray {
        val bb = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
        bb.put(id.toByteArray(Charsets.US_ASCII))
        bb.putInt(len)
        return bb.array()
    }

    override fun close() {
        for (s in ArrayList(streams.values)) {
            if (!s.closed) sendClose(s)
        }
        streams.clear()
    }
}

class AdbStream internal constructor(private val conn: AdbConnection, val localId: Int) : Closeable {
    internal var remoteId: Int = 0
    internal var opened: Boolean = false
    internal var closed: Boolean = false
    internal var okayCount: Int = 0
    internal val queue = java.util.ArrayDeque<ByteArray>()

    private var cur: ByteArray? = null
    private var curPos = 0

    fun write(data: ByteArray, off: Int = 0, len: Int = data.size) {
        var p = 0
        while (p < len) {
            if (closed) throw IOException("The device closed the stream")
            val n = minOf(conn.maxData, len - p)
            conn.sendMessage(A_WRTE, localId, remoteId, data, off + p, n)
            p += n
            while (okayCount == 0) {
                if (closed) throw IOException("The device closed the stream")
                conn.pump(60_000)
            }
            okayCount--
        }
    }

    /** Reads up to [len] bytes. Returns -1 once the device closed the stream. */
    fun read(buf: ByteArray, off: Int, len: Int, timeoutMs: Long): Int {
        while (true) {
            val c = cur
            if (c != null && curPos < c.size) {
                val n = minOf(len, c.size - curPos)
                System.arraycopy(c, curPos, buf, off, n)
                curPos += n
                return n
            }
            val next = queue.poll()
            if (next != null) {
                cur = next
                curPos = 0
                continue
            }
            if (closed) return -1
            conn.pump(timeoutMs)
        }
    }

    /** Returns between 1 and [max] bytes. */
    fun readSome(max: Int, timeoutMs: Long): ByteArray {
        val tmp = ByteArray(max)
        val n = read(tmp, 0, max, timeoutMs)
        if (n < 0) throw EOFException("Stream closed by the device")
        return if (n == max) tmp else tmp.copyOf(n)
    }

    fun readFully(n: Int, timeoutMs: Long): ByteArray {
        val out = ByteArray(n)
        var pos = 0
        while (pos < n) {
            val r = read(out, pos, n - pos, timeoutMs)
            if (r < 0) throw EOFException("Stream closed by the device")
            pos += r
        }
        return out
    }

    override fun close() {
        if (!closed) {
            conn.sendClose(this)
            closed = true
        }
        conn.releaseStream(this)
    }
}

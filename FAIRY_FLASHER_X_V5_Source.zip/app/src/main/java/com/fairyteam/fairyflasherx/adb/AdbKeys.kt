package com.fairyteam.fairyflasherx.adb

import android.util.Base64
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

/** RSA key pair used to authorise this phone with the target device's adbd. */
class AdbKeys(dir: File) {
    private val priv: PrivateKey
    private val pub: RSAPublicKey

    init {
        val privFile = File(dir, "adb_priv.pk8")
        val pubFile = File(dir, "adb_pub.x509")
        var loadedPriv: PrivateKey? = null
        var loadedPub: RSAPublicKey? = null
        try {
            if (privFile.exists() && pubFile.exists()) {
                val kf = KeyFactory.getInstance("RSA")
                loadedPriv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
                loadedPub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes())) as RSAPublicKey
            }
        } catch (e: Exception) {
            loadedPriv = null
            loadedPub = null
        }
        if (loadedPriv == null || loadedPub == null) {
            val gen = KeyPairGenerator.getInstance("RSA")
            gen.initialize(2048)
            val pair = gen.generateKeyPair()
            loadedPriv = pair.private
            loadedPub = pair.public as RSAPublicKey
            try {
                dir.mkdirs()
                privFile.writeBytes(loadedPriv.encoded)
                pubFile.writeBytes(loadedPub.encoded)
            } catch (e: Exception) {
                // keys just won't persist; user will be asked to authorise again
            }
        }
        priv = loadedPriv!!
        pub = loadedPub!!
    }

    /** Signs the 20 byte AUTH token (already a SHA-1 sized value) the way adbd expects. */
    fun sign(token: ByteArray): ByteArray {
        val prefix = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
        )
        val padded = ByteArray(256)
        padded[0] = 0
        padded[1] = 1
        val padLen = 256 - 3 - prefix.size - token.size
        for (i in 0 until padLen) padded[2 + i] = 0xFF.toByte()
        padded[2 + padLen] = 0
        System.arraycopy(prefix, 0, padded, 3 + padLen, prefix.size)
        System.arraycopy(token, 0, padded, 3 + padLen + prefix.size, token.size)
        val cipher = Cipher.getInstance("RSA/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, priv)
        return cipher.doFinal(padded)
    }

    /** Public key in the "Android RSAPublicKey" format, base64 + name + NUL. */
    fun publicKeyPayload(): ByteArray {
        val struct = androidPublicKey(pub)
        val b64 = Base64.encode(struct, Base64.NO_WRAP)
        val tail = " fairyflasherx@android".toByteArray(Charsets.US_ASCII)
        val out = ByteArray(b64.size + tail.size + 1)
        System.arraycopy(b64, 0, out, 0, b64.size)
        System.arraycopy(tail, 0, out, b64.size, tail.size)
        out[out.size - 1] = 0
        return out
    }

    private fun androidPublicKey(key: RSAPublicKey): ByteArray {
        val words = 64
        val r32 = BigInteger.ZERO.setBit(32)
        var n = key.modulus
        val r = BigInteger.ZERO.setBit(2048)
        var rr = r.modPow(BigInteger.valueOf(2), n)
        val n0inv = n.remainder(r32).modInverse(r32)
        val myN = IntArray(words)
        val myRr = IntArray(words)
        for (i in 0 until words) {
            val a = rr.divideAndRemainder(r32)
            rr = a[0]
            myRr[i] = a[1].toInt()
            val b = n.divideAndRemainder(r32)
            n = b[0]
            myN[i] = b[1].toInt()
        }
        val bb = ByteBuffer.allocate(4 + 4 + 4 * words + 4 * words + 4).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(words)
        bb.putInt(n0inv.negate().toInt())
        for (v in myN) bb.putInt(v)
        for (v in myRr) bb.putInt(v)
        bb.putInt(key.publicExponent.toInt())
        return bb.array()
    }
}

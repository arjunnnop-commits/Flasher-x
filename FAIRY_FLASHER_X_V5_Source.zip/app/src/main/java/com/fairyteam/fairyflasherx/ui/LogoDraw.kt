package com.fairyteam.fairyflasherx.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.fairyteam.fairyflasherx.R
import kotlin.math.roundToInt

private class LogoShape(val path: Path, val measure: PathMeasure, val length: Float)

/** Builds the traced outline in "height = 1" units so one uniform scale maps it onto the canvas. */
private fun buildLogoShapes(): List<LogoShape> = LOGO_CONTOURS.map { c ->
    val p = Path()
    var i = 0
    while (i + 1 < c.size) {
        val x = c[i] * LOGO_ASPECT
        val y = c[i + 1]
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        i += 2
    }
    p.close()
    val m = PathMeasure()
    m.setPath(p, true)
    LogoShape(p, m, m.length)
}

/**
 * The Fairy Team logo that "draws" itself: a glowing line traces the outline (0 .. 0.65),
 * then the solid logo fades in while the line fades out (0.55 .. 1).
 */
@Composable
fun DrawnLogo(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    glow: Color = Color(0xFFFF1744),
    pulse: Float = 1f
) {
    val bmp = ImageBitmap.imageResource(R.drawable.fairy_logo)
    val shapes = remember { buildLogoShapes() }
    val seg = remember { Path() }

    Canvas(modifier.aspectRatio(LOGO_ASPECT)) {
        val w = size.width
        val h = size.height
        val drawP = FastOutSlowInEasing.transform((progress / 0.65f).coerceIn(0f, 1f))
        val fillP = ((progress - 0.55f) / 0.45f).coerceIn(0f, 1f)
        val strokeA = (1f - fillP).coerceIn(0f, 1f)

        if (fillP > 0f) {
            val r = w * 0.8f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(glow.copy(alpha = 0.30f * fillP * pulse), Color.Transparent),
                    center = center, radius = r
                ),
                radius = r,
                center = center
            )
            drawImage(
                image = bmp,
                dstSize = IntSize(w.roundToInt(), h.roundToInt()),
                alpha = fillP,
                colorFilter = ColorFilter.tint(color),
                filterQuality = FilterQuality.High
            )
        }

        if (strokeA > 0f && drawP > 0f) {
            scale(h, h, Offset.Zero) {
                for (s in shapes) {
                    seg.rewind()
                    s.measure.getSegment(0f, s.length * drawP, seg, true)
                    drawPath(
                        seg, glow.copy(alpha = 0.35f * strokeA),
                        style = Stroke(width = 16f / h, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                    drawPath(
                        seg, color.copy(alpha = strokeA),
                        style = Stroke(width = 3.5f / h, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
            if (drawP < 0.995f) {
                for (s in shapes) {
                    val pos = s.measure.getPosition(s.length * drawP)
                    val c = Offset(pos.x * h, pos.y * h)
                    drawCircle(glow.copy(alpha = 0.45f * strokeA), radius = 16f, center = c)
                    drawCircle(Color.White.copy(alpha = strokeA), radius = 5f, center = c)
                }
            }
        }
    }
}

/** Logo block for the About page: draws itself on open, tap to replay. */
@Composable
fun AboutLogo() {
    val pal = LocalFairy.current
    var replay by remember { mutableIntStateOf(0) }
    val t = remember { Animatable(0f) }
    LaunchedEffect(replay) {
        t.snapTo(0f)
        t.animateTo(1f, tween(2800, easing = LinearEasing))
    }
    val inf = rememberInfiniteTransition(label = "aboutLogo")
    val pulse by inf.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { replay++ },
        contentAlignment = Alignment.Center
    ) {
        DrawnLogo(
            progress = t.value,
            modifier = Modifier.fillMaxWidth(0.58f),
            color = if (pal.dark) Color.White else pal.ink,
            glow = pal.accent,
            pulse = pulse
        )
    }
}

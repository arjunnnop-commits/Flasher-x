package com.fairyteam.fairyflasherx.script

/** One action found in a flash_all.bat / flash_all.sh style script. */
sealed class ScriptStep {
    abstract val raw: String
}

class FbFlash(val partition: String, val file: String, val slot: String?, override val raw: String) : ScriptStep()
class FbErase(val partition: String, override val raw: String) : ScriptStep()
class FbWipe(override val raw: String) : ScriptStep()
class FbSetActive(val slot: String, override val raw: String) : ScriptStep()
class FbReboot(val target: String, override val raw: String) : ScriptStep()
class FbBoot(val file: String, override val raw: String) : ScriptStep()
class FbRaw(val command: String, val lockChange: Boolean, override val raw: String) : ScriptStep()
class AdbRebootStep(val target: String, override val raw: String) : ScriptStep()
class AdbSideloadStep(val file: String, override val raw: String) : ScriptStep()
class AdbShellStep(val command: String, override val raw: String) : ScriptStep()
class AdbPushStep(val local: String, val remote: String, override val raw: String) : ScriptStep()
class AdbWaitStep(override val raw: String) : ScriptStep()
class SkippedStep(val reason: String, override val raw: String) : ScriptStep()

/** The file name a step needs from the images folder, if any. */
fun fileTokenOf(step: ScriptStep): String? {
    return when (step) {
        is FbFlash -> step.file
        is FbBoot -> step.file
        is AdbSideloadStep -> step.file
        is AdbPushStep -> step.local
        else -> null
    }
}

fun isWipeStep(step: ScriptStep): Boolean {
    return when (step) {
        is FbWipe -> true
        is FbFlash -> {
            val p = step.partition.lowercase().removeSuffix("_ab").removeSuffix("_a").removeSuffix("_b")
            p == "userdata" || p == "metadata" || p == "cache"
        }
        is FbErase -> {
            val p = step.partition.lowercase()
            p == "userdata" || p == "metadata" || p == "data" || p == "cache" || p.startsWith("userdata_")
        }
        else -> false
    }
}

fun isLockStep(step: ScriptStep): Boolean {
    return step is FbRaw && step.lockChange
}

fun describeStep(step: ScriptStep): String {
    return when (step) {
        is FbFlash -> "flash " + step.partition + (if (step.slot != null) " (slot " + step.slot + ")" else "") + "  <-  " + step.file
        is FbErase -> "erase " + step.partition
        is FbWipe -> "wipe user data (fastboot -w)"
        is FbSetActive -> "set active slot " + step.slot
        is FbReboot -> if (step.target.isEmpty()) "reboot system" else "reboot " + step.target
        is FbBoot -> "boot  <-  " + step.file
        is FbRaw -> step.command
        is AdbRebootStep -> "adb reboot " + step.target
        is AdbSideloadStep -> "adb sideload  <-  " + step.file
        is AdbShellStep -> "adb shell " + step.command
        is AdbPushStep -> "adb push " + step.local + " -> " + step.remote
        is AdbWaitStep -> "wait for adb device"
        is SkippedStep -> "skipped: " + step.reason
    }
}

object FlashScriptParser {

    private val FB_SUBCOMMANDS = setOf(
        "flash", "flash:raw", "erase", "format", "format:ext4", "format:f2fs", "reboot", "reboot-bootloader",
        "reboot-recovery", "reboot-fastboot", "set_active", "getvar", "oem", "flashing", "boot", "continue",
        "update", "flashall", "delete-logical-partition", "create-logical-partition",
        "resize-logical-partition", "snapshot-update", "wipe-super", "gsi", "devices"
    )

    private val NOISE_WORDS = listOf(
        "echo", "pause", "setlocal", "endlocal", "cls", "title", "color", "chcp", "exit", "goto", "timeout",
        "sleep", "read", "cd", "if", "fi", "else", "then", "for", "done", "do", "export", "clear", "mode",
        "ver", "return", "trap", "set", "shift", "while", "case", "esac", "function", "pushd", "popd", "type",
        "cmd", "start", "mkdir", "rmdir", "del", "copy", "move", "ren", "rename", "chmod", "source"
    )

    private val SH_ASSIGN = Regex("^([A-Za-z_][A-Za-z0-9_]*)=(.*)$")
    private val REDIR = Regex("^[0-9&]?>{1,2}.*|^<.*")
    private val REDIR_ONLY = Regex("^[0-9&]?>{1,2}$|^<$")

    fun parse(text: String, isBat: Boolean): List<ScriptStep> {
        val steps = ArrayList<ScriptStep>()
        val vars = HashMap<String, String>()
        val rawLines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        for (rawLine in joinContinuations(rawLines, isBat)) {
            var line = rawLine.trim().removePrefix("\uFEFF").trim()
            if (line.isEmpty()) continue
            if (line.startsWith("@")) line = line.substring(1).trim()
            if (line.isEmpty()) continue
            val lower = line.lowercase()

            // comments and labels
            if (isBat) {
                if (lower == "rem" || lower.startsWith("rem ") || line.startsWith("::") || line.startsWith(":")) continue
            } else if (line.startsWith("#")) {
                continue
            }

            // variable assignments
            if (isBat && startsWithWord(lower, "set")) {
                handleBatSet(line, vars)
                continue
            }
            if (!isBat) {
                val m = SH_ASSIGN.matchEntire(line)
                if (m != null) {
                    vars[m.groupValues[1]] = unquote(expand(m.groupValues[2], vars, false))
                    continue
                }
            }

            if (!lower.contains("fastboot") && !lower.contains("adb")) continue

            val expanded = expand(line, vars, isBat)
            for (part in splitCommands(expanded, isBat)) {
                val seg = part.trim()
                if (seg.isEmpty() || isNoise(seg.lowercase())) continue
                val tokens = dropRedirections(tokenize(seg, isBat))
                if (tokens.isEmpty()) continue
                steps.addAll(parseCommand(tokens, line, lower))
            }
        }
        return steps
    }

    // ------------------------------------------------------------------ helpers

    private fun startsWithWord(lower: String, word: String): Boolean {
        return lower == word || lower.startsWith("$word ") || lower.startsWith("$word\t")
    }

    private fun isNoise(lower: String): Boolean {
        if (lower.startsWith("echo")) return true
        for (w in NOISE_WORDS) {
            if (startsWithWord(lower, w)) return true
        }
        return false
    }

    private fun joinContinuations(lines: List<String>, isBat: Boolean): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (l in lines) {
            val t = l.trimEnd()
            val cont = if (isBat) t.endsWith("^") else t.endsWith("\\")
            if (cont) {
                cur.append(t.substring(0, t.length - 1)).append(' ')
            } else {
                cur.append(t)
                out.add(cur.toString())
                cur.setLength(0)
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun unquote(s: String): String {
        val t = s.trim()
        if (t.length >= 2 && ((t.startsWith("\"") && t.endsWith("\"")) || (t.startsWith("'") && t.endsWith("'")))) {
            return t.substring(1, t.length - 1)
        }
        return t
    }

    private fun handleBatSet(line: String, vars: HashMap<String, String>) {
        var body = line.substring(3).trim()
        if (body.startsWith("/")) return // set /a, set /p
        body = unquote(body)
        val eq = body.indexOf('=')
        if (eq <= 0) return
        val name = body.substring(0, eq).trim().lowercase()
        val value = unquote(expand(body.substring(eq + 1), vars, true))
        vars[name] = value
    }

    private fun expand(s: String, vars: Map<String, String>, isBat: Boolean): String {
        var r = s
        if (isBat) {
            r = r.replace("%~dp0", "").replace("%~dpnx0", "script.bat").replace("%~f0", "script.bat")
                .replace("%~n0", "script").replace("%~0", "script.bat").replace("%*", "")
            r = r.replace(Regex("(?i)%cd%"), "")
            r = r.replace(Regex("%[1-9]"), "")
            r = Regex("[%!]([A-Za-z0-9_.\\-]+)[%!]").replace(r) { m -> vars[m.groupValues[1].lowercase()] ?: "" }
        } else {
            r = Regex("\\\$\\((?:[^()]|\\([^()]*\\))*\\)").replace(r, ".")
            r = Regex("`[^`]*`").replace(r, ".")
            r = r.replace("\${0%/*}", ".")
            r = Regex("\\\$\\{([A-Za-z_][A-Za-z0-9_]*)[^}]*\\}").replace(r) { m -> vars[m.groupValues[1]] ?: "" }
            r = Regex("\\\$([A-Za-z_][A-Za-z0-9_]*)").replace(r) { m -> vars[m.groupValues[1]] ?: "" }
            r = Regex("\\\$[@*#0-9]").replace(r, "")
        }
        return r
    }

    /**
     * Splits one script line into the commands it chains with ";", "&&" or "&".
     * Everything after a pipe or "||" is dropped (it is only error handling).
     */
    private fun splitCommands(s: String, isBat: Boolean): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var inSingle = false
        var inDouble = false
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '"' && !inSingle) {
                inDouble = !inDouble
                cur.append(ch)
            } else if (ch == '\'' && !inDouble && !isBat) {
                inSingle = !inSingle
                cur.append(ch)
            } else if (!inSingle && !inDouble && ch == '|') {
                break
            } else if (!inSingle && !inDouble && ch == '&') {
                val prev = if (i > 0) s[i - 1] else ' '
                val next = if (i + 1 < s.length) s[i + 1] else ' '
                if (prev == '>' || next == '>') {
                    cur.append(ch)
                } else {
                    out.add(cur.toString())
                    cur.setLength(0)
                    if (next == '&') i++
                }
            } else if (!inSingle && !inDouble && ch == ';' && !isBat) {
                out.add(cur.toString())
                cur.setLength(0)
            } else {
                cur.append(ch)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun tokenize(s: String, isBat: Boolean): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var inSingle = false
        var inDouble = false
        var has = false
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (inSingle) {
                if (ch == '\'') inSingle = false else cur.append(ch)
            } else if (inDouble) {
                if (ch == '"') {
                    inDouble = false
                } else if (ch == '\\' && !isBat && i + 1 < s.length && (s[i + 1] == '"' || s[i + 1] == '\\')) {
                    cur.append(s[i + 1])
                    i++
                } else {
                    cur.append(ch)
                }
            } else if (ch == '"') {
                inDouble = true
                has = true
            } else if (ch == '\'' && !isBat) {
                inSingle = true
                has = true
            } else if (ch == '\\' && !isBat && i + 1 < s.length) {
                cur.append(s[i + 1])
                i++
                has = true
            } else if (ch.isWhitespace()) {
                if (has || cur.isNotEmpty()) {
                    out.add(cur.toString())
                    cur.setLength(0)
                    has = false
                }
            } else {
                cur.append(ch)
                has = true
            }
            i++
        }
        if (has || cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun dropRedirections(tokens: List<String>): List<String> {
        val out = ArrayList<String>()
        var skipNext = false
        for (t in tokens) {
            if (skipNext) {
                skipNext = false
                continue
            }
            if (REDIR.matches(t)) {
                if (REDIR_ONLY.matches(t)) skipNext = true
                continue
            }
            if (t.isNotEmpty()) out.add(t)
        }
        return out
    }

    private fun baseName(token: String): String {
        return token.replace('\\', '/').substringAfterLast('/').lowercase().removeSuffix(".exe")
    }

    private fun parseCommand(tokens: List<String>, raw: String, lowerRaw: String): List<ScriptStep> {
        var idx = -1
        for (i in tokens.indices) {
            val b = baseName(tokens[i])
            if (b == "fastboot" || b == "adb") {
                idx = i
                break
            }
        }
        if (idx >= 0) {
            val prog = baseName(tokens[idx])
            val rest = tokens.subList(idx + 1, tokens.size)
            return if (prog == "fastboot") parseFastboot(rest, raw) else parseAdb(rest, raw)
        }
        // the program variable was not resolved (e.g. %fastboot%) - guess from the first word
        val firstWord = tokens[0].lowercase()
        if (lowerRaw.contains("fastboot") && (FB_SUBCOMMANDS.contains(firstWord) || firstWord.startsWith("-"))) {
            return parseFastboot(tokens, raw)
        }
        return emptyList()
    }

    private fun parseFastboot(rest: List<String>, raw: String): List<ScriptStep> {
        var slot: String? = null
        var wipe = false
        var setActive: String? = null
        val pos = ArrayList<String>()
        var i = 0
        while (i < rest.size) {
            val a = rest[i]
            if (a.startsWith("--")) {
                if (a.startsWith("--slot=")) slot = a.substringAfter('=')
                else if (a == "--slot") {
                    slot = rest.getOrNull(i + 1)
                    i++
                } else if (a.startsWith("--set-active=")) setActive = a.substringAfter('=')
                // every other long option (--disable-verity, --skip-reboot, ...) is ignored
            } else if (a.startsWith("-") && a.length >= 2 && pos.isEmpty()) {
                if (a == "-w") wipe = true
                else if (a == "-s" || a == "-S" || a == "-i" || a == "-c" || a == "-b") i++
                else if (a == "-a") setActive = ""
                // other short flags are ignored
            } else {
                pos.add(a)
            }
            i++
        }

        val out = ArrayList<ScriptStep>()
        if (wipe) out.add(FbWipe(raw))
        val sub = pos.firstOrNull()?.lowercase()
        val params = if (pos.size > 1) pos.subList(1, pos.size) else emptyList<String>()

        if (sub == null) {
            if (!setActive.isNullOrEmpty()) out.add(FbSetActive(setActive, raw))
            return out
        }

        when (sub) {
            "flash", "flash:raw" -> {
                if (params.size >= 2) out.add(FbFlash(params[0], params[1], slot, raw))
                else out.add(SkippedStep("flash without an image file is not supported", raw))
            }
            "erase" -> {
                if (params.isNotEmpty()) out.add(FbErase(params[0], raw))
                else out.add(SkippedStep("erase without a partition", raw))
            }
            "format", "format:ext4", "format:f2fs" -> {
                if (params.isNotEmpty()) out.add(FbErase(params[params.size - 1], raw))
                else out.add(SkippedStep("format without a partition", raw))
            }
            "reboot" -> out.add(FbReboot(if (params.isNotEmpty()) params[0].lowercase() else "", raw))
            "reboot-bootloader" -> out.add(FbReboot("bootloader", raw))
            "reboot-recovery" -> out.add(FbReboot("recovery", raw))
            "reboot-fastboot" -> out.add(FbReboot("fastboot", raw))
            "set_active" -> {
                if (params.isNotEmpty()) out.add(FbSetActive(params[0], raw))
                else out.add(SkippedStep("set_active without a slot", raw))
            }
            "getvar" -> out.add(FbRaw("getvar:" + params.joinToString(":"), false, raw))
            "oem" -> {
                val text = params.joinToString(" ").lowercase()
                out.add(FbRaw("oem " + params.joinToString(" "), text.contains("lock"), raw))
            }
            "flashing" -> {
                val text = params.joinToString(" ").lowercase()
                out.add(FbRaw("flashing " + params.joinToString(" "), text.contains("lock"), raw))
            }
            "boot" -> {
                if (params.isNotEmpty()) out.add(FbBoot(params[0], raw))
                else out.add(SkippedStep("boot without an image", raw))
            }
            "continue" -> out.add(FbRaw("continue", false, raw))
            "delete-logical-partition" -> {
                if (params.isNotEmpty()) out.add(FbRaw("delete-logical-partition:" + params[0], false, raw))
            }
            "create-logical-partition", "resize-logical-partition" -> {
                if (params.size >= 2) out.add(FbRaw(sub + ":" + params[0] + ":" + params[1], false, raw))
            }
            "snapshot-update" -> {
                if (params.isNotEmpty()) out.add(FbRaw("snapshot-update:" + params[0], false, raw))
            }
            "devices" -> {}
            "update", "flashall" ->
                out.add(SkippedStep("\"fastboot $sub\" needs an image zip - use a flash_all script with separate .img files", raw))
            else -> if (sub.isNotEmpty() && sub[0].isLetter()) out.add(SkippedStep("unsupported fastboot command: $sub", raw))
        }
        if (!setActive.isNullOrEmpty()) out.add(FbSetActive(setActive, raw))
        return out
    }

    private fun parseAdb(rest: List<String>, raw: String): List<ScriptStep> {
        val pos = ArrayList<String>()
        var i = 0
        while (i < rest.size) {
            val a = rest[i]
            if (pos.isEmpty() && a == "-s") {
                i += 2
                continue
            }
            if (pos.isEmpty() && (a == "-d" || a == "-e")) {
                i++
                continue
            }
            pos.add(a)
            i++
        }
        val sub = pos.firstOrNull()?.lowercase() ?: return emptyList()
        val params = pos.subList(1, pos.size)
        return when (sub) {
            "reboot" -> listOf(AdbRebootStep(if (params.isNotEmpty()) params[0].lowercase() else "", raw))
            "sideload" -> if (params.isNotEmpty()) listOf(AdbSideloadStep(params[0], raw)) else listOf(SkippedStep("sideload without a file", raw))
            "shell" -> listOf(AdbShellStep(params.joinToString(" "), raw))
            "push" -> if (params.size >= 2) listOf(AdbPushStep(params[0], params[1], raw)) else listOf(SkippedStep("push needs two paths", raw))
            "wait-for-device", "wait-for-recovery", "wait-for-sideload", "wait-for-any" -> listOf(AdbWaitStep(raw))
            "devices", "kill-server", "start-server", "version", "usb", "tcpip", "root" -> emptyList()
            else -> listOf(SkippedStep("unsupported adb command: $sub", raw))
        }
    }
}

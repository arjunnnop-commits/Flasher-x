package com.fairyteam.fairyflasherx.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairyteam.fairyflasherx.FlashMode
import com.fairyteam.fairyflasherx.FlasherViewModel
import com.fairyteam.fairyflasherx.R
import com.fairyteam.fairyflasherx.formatSize
import com.fairyteam.fairyflasherx.io.PartitionGuess
import com.fairyteam.fairyflasherx.script.describeStep
import com.fairyteam.fairyflasherx.usb.LinkKind

enum class Screen { Home, Adb, Fastboot, Rom, Devices, About, Themes }

// ===================================================================== splash

/** A small glowing butterfly drawn with paths. flap = 0.2 .. 1 is the wing opening. */
@Composable
fun Butterfly(flap: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        for (dir in listOf(-1f, 1f)) {
            val k = flap * dir
            val upper = Path().apply {
                moveTo(cx, cy)
                cubicTo(cx + k * w * 0.20f, cy - h * 0.62f, cx + k * w * 0.85f, cy - h * 0.55f, cx + k * w * 0.48f, cy - h * 0.02f)
                close()
            }
            val lower = Path().apply {
                moveTo(cx, cy)
                cubicTo(cx + k * w * 0.50f, cy + h * 0.02f, cx + k * w * 0.62f, cy + h * 0.55f, cx + k * w * 0.10f, cy + h * 0.38f)
                close()
            }
            val brush = Brush.linearGradient(listOf(Color(0xFFFF8FA9), Color(0xFFFF1744)))
            drawPath(upper, Color(0xFFFF1744).copy(alpha = 0.25f), style = Stroke(width = 7f))
            drawPath(lower, Color(0xFFFF1744).copy(alpha = 0.25f), style = Stroke(width = 7f))
            drawPath(upper, brush, alpha = 0.85f)
            drawPath(lower, brush, alpha = 0.75f)
            drawPath(upper, Color.White.copy(alpha = 0.8f), style = Stroke(width = 1.5f))
            drawPath(lower, Color.White.copy(alpha = 0.8f), style = Stroke(width = 1.5f))
        }
        drawLine(Color.White, Offset(cx, cy - h * 0.12f), Offset(cx, cy + h * 0.22f), strokeWidth = 3f)
    }
}

// ===================================================================== home

@Composable
fun HomeScreen(vm: FlasherViewModel, go: (Screen) -> Unit) {
    PageScaffold(
        title = "FAIRY FLASHER X",
        subtitle = "ADB  •  FASTBOOT  •  ROM FLASHER",
        onBack = null,
        actions = {
            GlassIconButton(Icons.Default.Refresh) {
                vm.scan()
                vm.refreshInfo()
            }
            Spacer(Modifier.width(8.dp))
            GlassIconButton(Icons.Default.Palette) { go(Screen.Themes) }
            Spacer(Modifier.width(8.dp))
            GlassIconButton(Icons.Default.Info) { go(Screen.About) }
        }
    ) {
        DeviceStatusCard(vm)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeTile("ADB Tools", "Manage your device", Icons.Default.Terminal, Color(0xFF4F7BFF), Color(0xFF8B7BFF), Modifier.weight(1f)) { go(Screen.Adb) }
            HomeTile("Fastboot Tools", "Bootloader & flash", Icons.Default.FlashOn, Color(0xFFF07BE6), Color(0xFFB98BFF), Modifier.weight(1f)) { go(Screen.Fastboot) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeTile("ROM Flasher", "Images, scripts, sideload", Icons.Default.Memory, Color(0xFF30D5C8), Color(0xFF5CE0F0), Modifier.weight(1f)) { go(Screen.Rom) }
            HomeTile("Device Manager", "Connected devices", Icons.Default.Devices, Color(0xFF9D82F2), Color(0xFFC2A6FF), Modifier.weight(1f)) { go(Screen.Devices) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, null, tint = Blue, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Flash safely", color = Ink, fontWeight = FontWeight.Bold)
                    Text(
                        "Use a good OTG cable, keep the battery above 50% and check the partition before you flash.",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
        }
        ConsoleBar(vm)
    }
}

@Composable
fun DeviceStatusCard(vm: FlasherViewModel) {
    val primary = vm.devices.firstOrNull()
    val permitted = primary != null && primary.permitted
    val statusText = if (primary == null) "No device" else if (!permitted) "Permission needed" else "Connected"
    val dot = if (primary == null) Color(0xFFB0B7CC) else if (!permitted) Amber else Green
    val isAdb = permitted && primary != null && primary.kind == LinkKind.ADB
    val isFb = permitted && primary != null && primary.kind == LinkKind.FASTBOOT
    val info = vm.info

    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Device Status", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(dot, CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text(statusText, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }
            Box(
                Modifier.size(46.dp).background(Brush.linearGradient(listOf(LocalFairy.current.iconBase, Cyan.copy(alpha = 0.4f))), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.PhoneAndroid, null, tint = Blue, modifier = Modifier.size(26.dp)) }
        }
        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = LocalFairy.current.divider)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            StatusItem("Device Model", info.model.ifEmpty { "-" }, Modifier.weight(1f))
            StatusItem("Android Version", info.android.ifEmpty { "-" }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            StatusItem("ADB Status", if (isAdb) "Online" else "Offline", Modifier.weight(1f), if (isAdb) Green else Amber)
            StatusItem("Fastboot Status", if (isFb) "Online" else "Offline", Modifier.weight(1f), if (isFb) Green else Amber)
        }
        if (info.state.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            StatusItem("Mode", info.state + (if (info.extra.isNotEmpty()) "   " + info.extra else ""), Modifier.fillMaxWidth())
        }
        if (primary != null && !permitted) {
            Spacer(Modifier.height(12.dp))
            PrimaryButton("Grant USB permission") { vm.requestPermission() }
        }
        if (primary == null) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Connect the target phone with a USB OTG cable. For ADB turn on USB debugging; for fastboot boot to the bootloader.",
                color = Muted, fontSize = 12.sp
            )
        }
    }
}

@Composable
fun StatusItem(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Ink) {
    Column(modifier) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = valueColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun HomeTile(title: String, subtitle: String, icon: ImageVector, c1: Color, c2: Color, modifier: Modifier, onClick: () -> Unit) {
    val tileShape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .bounceClick(tileShape, Color.White, onTap = onClick)
            .clip(tileShape)
            .background(Brush.linearGradient(listOf(c1.copy(alpha = 0.85f), c2.copy(alpha = 0.75f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.Transparent, Color.White.copy(alpha = 0.18f))), tileShape)
            .padding(16.dp)
    ) {
        Box(
            Modifier.size(40.dp).background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(23.dp)) }
        Spacer(Modifier.height(26.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
    }
}

// ===================================================================== ADB tools

@Composable
fun AdbScreen(vm: FlasherViewModel, back: () -> Unit) {
    var dialog by remember { mutableStateOf("") }
    var pendingUninstall by remember { mutableStateOf("") }
    var remoteDir by remember { mutableStateOf("/sdcard/Download/") }
    var pullPath by remember { mutableStateOf("") }

    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.adbInstall(uri)
    }
    val pickPush = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.adbPush(uri, remoteDir)
    }
    val savePull = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.adbPull(pullPath, uri)
    }

    PageScaffold("ADB Tools", "Connect  •  Manage  •  Control", back) {
        ToolRow(Icons.Default.Search, "Detect Device", "Check ADB connection", Blue) { vm.adbDetect() }
        ToolRow(Icons.Default.RestartAlt, "Reboot", "Reboot device (system / recovery / bootloader)", Violet) { dialog = "reboot" }
        ToolRow(Icons.Default.InstallMobile, "Install APK", "Pick an APK and install it", Blue) { pickApk.launch(arrayOf("*/*")) }
        ToolRow(Icons.Default.DeleteOutline, "Uninstall App", "Remove an installed package", Pink) {
            vm.adbListPackages()
            dialog = "uninstall"
        }
        ToolRow(Icons.Default.Terminal, "Shell Commands", "Run a custom command", Teal) { dialog = "shell" }
        ToolRow(Icons.Default.Folder, "File Transfer", "Push / pull files", Violet) { dialog = "files" }
        ConsoleBar(vm)
    }

    when (dialog) {
        "reboot" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("Reboot device", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    RebootChoice("System") { vm.adbReboot(""); dialog = "" }
                    RebootChoice("Recovery") { vm.adbReboot("recovery"); dialog = "" }
                    RebootChoice("Bootloader (fastboot)") { vm.adbReboot("bootloader"); dialog = "" }
                    RebootChoice("Fastbootd (userspace)") { vm.adbReboot("fastboot"); dialog = "" }
                    RebootChoice("Sideload (from recovery)") { vm.adbReboot("sideload"); dialog = "" }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close", color = Muted) } }
        )
        "shell" -> ShellDialog(vm) { dialog = "" }
        "uninstall" -> UninstallDialog(vm, onPick = { pendingUninstall = it; dialog = "confirm-uninstall" }) { dialog = "" }
        "confirm-uninstall" -> ConfirmDialog(
            "Uninstall app", "Remove " + pendingUninstall + " from the device?", "Uninstall",
            onDismiss = { dialog = "" }, onConfirm = { vm.adbUninstall(pendingUninstall) }
        )
        "files" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("File transfer", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Push a file from this phone", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    FairyField(remoteDir, { remoteDir = it }, "Destination folder on device")
                    TextButton(onClick = { dialog = ""; pickPush.launch(arrayOf("*/*")) }) { Text("Choose file and push", color = Blue, fontWeight = FontWeight.Bold) }
                    HorizontalDivider()
                    Text("Pull a file from the device", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    FairyField(pullPath, { pullPath = it }, "Remote file path")
                    TextButton(onClick = {
                        if (pullPath.isNotBlank()) {
                            dialog = ""
                            savePull.launch(pullPath.trim().substringAfterLast('/'))
                        }
                    }) { Text("Choose destination and pull", color = Blue, fontWeight = FontWeight.Bold) }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close", color = Muted) } }
        )
        else -> {}
    }
}

@Composable
fun RebootChoice(text: String, onClick: () -> Unit) {
    Text(
        text,
        color = Ink,
        fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp)
    )
}

@Composable
fun ShellDialog(vm: FlasherViewModel, onClose: () -> Unit) {
    var cmd by remember { mutableStateOf("getprop ro.product.model") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Shell command", color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FairyField(cmd, { cmd = it }, "Command")
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 80.dp, max = 220.dp).clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1D2540)).padding(10.dp)
                ) {
                    LazyColumn {
                        item {
                            Text(
                                vm.shellOutput.ifEmpty { "Output appears here" },
                                color = Color(0xFFCBD3F0), fontFamily = FontFamily.Monospace, fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.adbShellRun(cmd) }) { Text("Run", color = Blue, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close", color = Muted) } }
    )
}

@Composable
fun UninstallDialog(vm: FlasherViewModel, onPick: (String) -> Unit, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = vm.packages.filter { it.contains(query.trim(), ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Uninstall app", color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FairyField(query, { query = it }, "Search or type a package name")
                if (vm.packages.isEmpty()) {
                    Text(if (vm.busy) "Loading apps..." else "No apps loaded. Check the connection.", color = Muted, fontSize = 12.sp)
                }
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    items(list) { p ->
                        Text(
                            p, color = Ink, fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (query.isNotBlank()) onPick(query.trim()) }) { Text("Use typed name", color = Pink, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close", color = Muted) } }
    )
}

// ===================================================================== Fastboot tools

@Composable
fun FastbootScreen(vm: FlasherViewModel, back: () -> Unit, openFlash: () -> Unit) {
    var dialog by remember { mutableStateOf("") }
    PageScaffold("Fastboot Tools", "Bootloader  •  Partitions  •  Flash", back) {
        ToolRow(Icons.Default.Search, "Detect Fastboot", "Check fastboot connection", Blue) { vm.fbDetect() }
        ToolRow(Icons.Default.Memory, "Reboot to Bootloader", "Restart into fastboot mode", Pink) { vm.fbReboot("bootloader") }
        ToolRow(Icons.Default.Build, "Reboot to Recovery", "Restart into recovery mode", Teal) { vm.fbReboot("recovery") }
        ToolRow(Icons.Default.RestartAlt, "Reboot to System", "Normal restart", Violet) { vm.fbReboot("") }
        ToolRow(Icons.Default.Storage, "Partition Info", "View partition details", Blue) { vm.fbPartitionInfo() }
        ToolRow(Icons.Default.FlashOn, "Flash Image", "Flash boot, recovery, system etc.", Pink, onClick = openFlash)
        ToolRow(Icons.Default.DeleteOutline, "Erase Partition", "Erase one partition", Amber) { dialog = "erase" }
        ToolRow(Icons.Default.Layers, "Set Active Slot", "Switch between slot A and B", Teal) { dialog = "slot" }
        ToolRow(Icons.Default.Terminal, "Custom Command", "Run any fastboot command", Violet) { dialog = "custom" }
        ConsolePanel(vm)
    }

    when (dialog) {
        "erase" -> InputDialog("Erase partition", "Partition name (e.g. userdata)", "", "Erase", { dialog = "" }) { dialog = "confirm-erase:" + it.trim() }
        "slot" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("Set active slot", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    RebootChoice("Slot A") { vm.fbSetActive("a"); dialog = "" }
                    RebootChoice("Slot B") { vm.fbSetActive("b"); dialog = "" }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close", color = Muted) } }
        )
        "custom" -> InputDialog("Custom command", "e.g. getvar:all or oem device-info", "getvar:all", "Run", { dialog = "" }) { vm.fbCustom(it) }
        else -> {
            if (dialog.startsWith("confirm-erase:")) {
                val part = dialog.removePrefix("confirm-erase:")
                ConfirmDialog(
                    "Erase $part?", "This permanently erases the partition \"$part\" on the device.", "Erase",
                    onDismiss = { dialog = "" }, onConfirm = { vm.fbErase(part) }
                )
            }
        }
    }

    if (vm.showPartitions) {
        var query by remember { mutableStateOf("") }
        val list = vm.partitions.filter { it.name.contains(query.trim(), ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { vm.showPartitions = false },
            title = { Text("Partitions (" + vm.partitions.size + ")", color = Ink, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FairyField(query, { query = it }, "Search partition")
                    Text("Tap a partition to flash an image to it", color = Muted, fontSize = 11.sp)
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { p ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        vm.flashPartition = p.name
                                        vm.showPartitions = false
                                        openFlash()
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(p.name, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text(p.size + (if (p.type.isNotEmpty()) "  " + p.type else ""), color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.showPartitions = false }) { Text("Close", color = Blue, fontWeight = FontWeight.Bold) } }
        )
    }
}

// ===================================================================== ROM flasher

@Composable
fun RomScreen(vm: FlasherViewModel, tab: Int, onTab: (Int) -> Unit, back: () -> Unit) {
    PageScaffold("ROM Flasher", "Flash your dream", back) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(LocalFairy.current.surface).padding(4.dp)
        ) {
            val names = listOf("Image", "Script", "Sideload")
            for ((i, n) in names.withIndex()) {
                val sel = tab == i
                Box(
                    Modifier
                        .weight(1f)
                        .bounceClick(RoundedCornerShape(14.dp), Color.White) { onTab(i) }
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Brush.horizontalGradient(LocalFairy.current.button) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) { Text(n, color = if (sel) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
        }
        when (tab) {
            0 -> ImageTab(vm)
            1 -> ScriptTab(vm)
            else -> SideloadTab(vm)
        }
        ConsoleBar(vm)
    }
}

@Composable
fun ImageTab(vm: FlasherViewModel) {
    var menu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(-1) }       // -1 closed, 0 = main partition, 1.. = zip item index + 1
    var editZip by remember { mutableStateOf(-1) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.pickImage(uri)
    }
    val isZip = vm.zipName.isNotEmpty()

    GlassCard(Modifier.fillMaxWidth()) {
        SelectRow(
            if (isZip) Icons.Default.FolderZip else Icons.Default.Folder,
            "Select Image or ZIP",
            if (isZip) vm.zipName + "  (" + vm.zipItems.size + " images)"
            else if (vm.imageName.isEmpty()) "Any .img / .bin / .mbn / .elf file or a .zip" else vm.imageName
        ) { pick.launch(arrayOf("*/*")) }
        if (!isZip) {
            Spacer(Modifier.height(12.dp))
            FairyField(vm.flashPartition, { vm.flashPartition = it }, "Partition (e.g. boot, recovery, modem)")
            Spacer(Modifier.height(10.dp))
            SelectRow(Icons.Default.Storage, "Select Partition", "Choose from the device list") { picker = 0 }
        }
        Spacer(Modifier.height(12.dp))
        Box {
            SelectRow(Icons.Default.Tune, "Flash Mode", vm.flashMode.label) { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                for (m in FlashMode.values()) {
                    DropdownMenuItem(text = { Text(m.label) }, onClick = { vm.flashMode = m; menu = false })
                }
            }
        }
    }

    if (isZip) {
        if (vm.zipNotice.isNotEmpty()) WarningCard(vm.zipNotice)
        if (vm.zipItems.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Images in zip", color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.selectAllZip(true) }) { Text("All", color = Blue) }
                    TextButton(onClick = { vm.selectAllZip(false) }) { Text("None", color = Muted) }
                }
                for ((i, z) in vm.zipItems.take(250).withIndex()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = z.selected,
                            onCheckedChange = { vm.toggleZipItem(i) },
                            colors = CheckboxDefaults.colors(checkedColor = Blue, uncheckedColor = Muted)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(z.file.name, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(formatSize(z.file.size), color = Muted, fontSize = 11.sp)
                        }
                        Text(
                            if (z.partition.isEmpty()) "set partition" else z.partition,
                            color = if (z.partition.isEmpty()) Amber else Blue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { picker = i + 1 }.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
                TextButton(onClick = { vm.clearImageSelection() }) { Text("Clear selection", color = Muted) }
            }
        }
    }

    WarningCard("Make sure your device is in fastboot mode and you have selected the correct partition.")
    if (isZip) {
        val n = vm.zipItems.count { it.selected && it.partition.isNotBlank() }
        PrimaryButton("Flash " + n + " selected", enabled = !vm.busy && n > 0) { confirm = true }
    } else {
        PrimaryButton("Start Flash", enabled = !vm.busy) { confirm = true }
    }
    if (confirm) {
        ConfirmDialog(
            "Start flashing?",
            "Flashing the wrong image or partition can make the device unbootable. Continue?",
            "Flash",
            onDismiss = { confirm = false },
            onConfirm = { if (isZip) vm.startZipFlash() else vm.startImageFlash() }
        )
    }
    if (picker >= 0) {
        PartitionPickerDialog(
            vm,
            onDismiss = { picker = -1 },
            onPick = { name ->
                if (picker == 0) vm.flashPartition = name else vm.setZipPartition(picker - 1, name)
                picker = -1
            }
        )
    }
}

/** Search + pick a partition: the device's own list when connected, otherwise the usual names. */
@Composable
fun PartitionPickerDialog(vm: FlasherViewModel, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (vm.partitions.isEmpty() && vm.devices.any { it.kind == LinkKind.FASTBOOT && it.permitted }) vm.loadPartitions(false)
    }
    val fromDevice = vm.partitions.isNotEmpty()
    val names: List<String> = if (fromDevice) vm.partitions.map { it.name } else PartitionGuess.COMMON
    val list = names.filter { it.contains(query.trim(), ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select partition", color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FairyField(query, { query = it }, "Search or type a name")
                Text(
                    if (vm.partitionsLoading) "Reading partitions from the device..."
                    else if (fromDevice) "From your device (" + names.size + ")" else "Common partitions - connect in fastboot to see yours",
                    color = Muted, fontSize = 11.sp
                )
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(list) { n ->
                        Text(
                            n, color = Ink, fontSize = 14.sp,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(n) }.padding(vertical = 10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (query.isNotBlank()) onPick(query.trim()) }) { Text("Use typed name", color = Blue, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.loadPartitions(false) }) { Text("Reload", color = Muted) }
                TextButton(onClick = onDismiss) { Text("Close", color = Muted) }
            }
        }
    )
}

@Composable
fun WarningCard(text: String) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.WarningAmber, null, tint = Amber)
            Spacer(Modifier.width(8.dp))
            Text(text, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun ScriptTab(vm: FlasherViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val pickScript = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.pickScript(uri)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.pickFolder(uri)
    }
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.pickRomZip(uri)
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Text("Flash a ROM package", color = Ink, fontWeight = FontWeight.Bold)
        Text(
            "Easiest: pick the ROM .zip - the script and images are read from inside it. Or pick the flash_all .bat / .sh script and the folder with the images.",
            color = Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))
        SelectRow(
            Icons.Default.FolderZip, "Select ROM .zip",
            "Fastboot ROM package (no need to unpack)"
        ) { pickZip.launch(arrayOf("*/*")) }
        Spacer(Modifier.height(10.dp))
        SelectRow(
            Icons.Default.Description, "Select script (.bat / .sh)",
            if (vm.scriptName.isEmpty()) "Choose flash_all.bat or flash_all.sh" else vm.scriptName
        ) { pickScript.launch(arrayOf("*/*")) }
        Spacer(Modifier.height(10.dp))
        SelectRow(
            Icons.Default.FolderOpen, "Select images folder",
            if (vm.folderName.isEmpty()) "Folder with .img / .bin files (script is optional)" else vm.folderName + "  (" + vm.treeFileCount + " files)"
        ) { pickFolder.launch(null) }
    }

    if (vm.steps.isNotEmpty()) {
        val missing = vm.missingFiles()
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("Keep my data", "Skip userdata / metadata wipe", vm.keepData) { vm.keepData = it }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Skip bootloader lock / unlock", "Safer when flashing custom ROMs", vm.skipLock) { vm.skipLock = it }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Skip missing files", "Flash everything that exists, skip images not in the folder", vm.skipMissing) { vm.skipMissing = it }
        }
        if (vm.stepStates.isNotEmpty()) StepChecklist(vm)
        if (vm.stepStates.isEmpty()) GlassCard(Modifier.fillMaxWidth()) {
            Text("Actions in this script (" + vm.steps.size + ")", color = Ink, fontWeight = FontWeight.Bold)
            if (vm.treeFileCount == 0) {
                Text("Select the images folder to check the files.", color = Amber, fontSize = 12.sp)
            } else if (missing.isEmpty()) {
                Text("All required files were found.", color = Green, fontSize = 12.sp)
            } else {
                Text(
                    missing.size.toString() + " file(s) not found in the folder (" + vm.treeFileCount + " files scanned): " + missing.joinToString(", ") +
                        (if (vm.skipMissing) "\nThese will be skipped." else "\nTurn on \"Skip missing files\" to flash the rest."),
                    color = if (vm.skipMissing) Amber else Pink, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(8.dp))
            for ((i, v) in vm.steps.take(150).withIndex()) {
                val why = vm.skipReason(v)
                val color = if (why != null) Muted else if (v.missing) (if (vm.skipMissing) Amber else Pink) else if (v.approx) Amber else Ink
                Text(
                    (i + 1).toString() + ". " + describeStep(v.step) + (if (why != null) "  [" + why + "]" else "") + (if (v.approx && why == null && v.file != null) "  [using " + v.file.name + "]" else "") + (if (v.missing && why == null) (if (vm.skipMissing) "  [missing - will be skipped]" else "  [file missing]") else ""),
                    color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            if (vm.steps.size > 150) Text("... and " + (vm.steps.size - 150) + " more", color = Muted, fontSize = 11.sp)
        }
        WarningCard("The device must be in fastboot (or fastbootd) mode. Flashing runs every action above in order.")
        PrimaryButton("Start Script Flash", enabled = !vm.busy && vm.treeFileCount > 0 && (missing.isEmpty() || vm.skipMissing)) { confirm = true }
    }

    if (confirm) {
        ConfirmDialog(
            "Run this script?",
            "The app will flash " + vm.steps.size + " actions from " + vm.scriptName + ". Do not unplug the cable." +
                (vm.steps.count { it.approx && vm.skipReason(it) == null }.let { n ->
                    if (n > 0) "\n\n" + n + " file(s) were matched by a similar name (amber, shown as [using ...]). Check them first, especially preloader / bootloader files." else ""
                }) + "\n\nContinue?",
            "Start",
            onDismiss = { confirm = false },
            onConfirm = { vm.startScriptFlash() }
        )
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Blue)
        )
    }
}

@Composable
fun SideloadTab(vm: FlasherViewModel) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.pickSideload(uri)
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Text("ADB sideload (AOSP / custom ROMs)", color = Ink, fontWeight = FontWeight.Bold)
        Text(
            "1. Boot the target phone into its custom recovery.\n" +
                "2. Choose Apply update > Apply from ADB.\n" +
                "3. Connect with an OTG cable, pick the ROM zip and start.",
            color = Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))
        SelectRow(
            Icons.Default.Folder, "Select ROM zip",
            if (vm.sideloadName.isEmpty()) "Choose the .zip to sideload" else vm.sideloadName + "  (" + formatSize(vm.sideloadSize) + ")"
        ) { pick.launch(arrayOf("*/*")) }
    }
    PrimaryButton("Start Sideload", enabled = !vm.busy && vm.sideloadUri != null) { vm.startSideload() }
}

// ===================================================================== Device manager

@Composable
fun DevicesScreen(vm: FlasherViewModel, back: () -> Unit) {
    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.adbInstall(uri)
    }
    PageScaffold("Device Manager", "Connected devices", back) {
        if (vm.devices.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Usb, null, tint = Muted, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("No device detected", color = Ink, fontWeight = FontWeight.Bold)
                        Text("Connect a phone with a USB OTG cable", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        for (d in vm.devices) {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, null, tint = Blue, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (vm.info.model.isNotEmpty() && d.permitted) vm.info.model else "USB device " + d.vidPid,
                            color = Ink, fontWeight = FontWeight.Bold
                        )
                        Text(
                            (if (d.kind == LinkKind.ADB) "ADB" else "Fastboot") + "  •  " + (if (d.permitted) "Connected" else "Permission needed"),
                            color = Muted, fontSize = 12.sp
                        )
                    }
                    Box(Modifier.size(10.dp).background(if (d.permitted) Green else Amber, CircleShape))
                }
                if (!d.permitted) {
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton("Grant USB permission") { vm.requestPermission() }
                }
            }
        }
        SectionTitle("Quick Actions")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction("Reboot", Icons.Default.RestartAlt, Modifier.weight(1f)) { vm.quickReboot("") }
            QuickAction("Recovery", Icons.Default.Build, Modifier.weight(1f)) { vm.quickReboot("recovery") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction("Bootloader", Icons.Default.Memory, Modifier.weight(1f)) { vm.quickReboot("bootloader") }
            QuickAction("Install APK", Icons.Default.InstallMobile, Modifier.weight(1f)) { pickApk.launch(arrayOf("*/*")) }
        }
        ConsoleBar(vm)
    }
}

@Composable
fun QuickAction(text: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier, onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(text, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

// ===================================================================== About

@Composable
fun AboutScreen(back: () -> Unit, openThemes: () -> Unit) {
    val uri = LocalUriHandler.current
    PageScaffold("About", "", back) {
        AboutLogo()
        Text("FAIRY FLASHER X", color = Ink, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        GlassCard(Modifier.fillMaxWidth()) {
            AboutRow("Built by", "@yooitachiijod", null)
            HorizontalDivider(color = LocalFairy.current.divider)
            AboutRow("Telegram", "Join Channel") { uri.openUri("https://t.me/FairysTeamBase") }
            HorizontalDivider(color = LocalFairy.current.divider)
            HorizontalDivider(color = LocalFairy.current.divider)
            AboutRow("Theme", LocalFairy.current.name) { openThemes() }
            HorizontalDivider(color = LocalFairy.current.divider)
            AboutRow("Version", "4.0", null)
        }
        Text("Power  •  Control  •  Freedom", color = Muted, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text(
            "Flashing can damage your device. You are responsible for what you flash.",
            color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AboutRow(label: String, value: String, onClick: (() -> Unit)?) {
    var m = Modifier.fillMaxWidth().padding(vertical = 12.dp)
    if (onClick != null) m = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp)
    Row(m, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Ink, fontWeight = FontWeight.SemiBold)
        Text(value, color = if (onClick != null) Blue else Muted)
    }
}

// ===================================================================== Themes

@Composable
fun ThemesScreen(currentId: String, onPick: (String) -> Unit, back: () -> Unit) {
    PageScaffold("Themes", "Pick your look", back) {
        for (p in Palettes.all) {
            val sel = p.id == currentId
            val shape = RoundedCornerShape(24.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(112.dp)
                    .bounceClick(shape, if (p.dark) Color.White else p.accent) { onPick(p.id) }
                    .clip(shape)
                    .background(Brush.linearGradient(p.bg))
                    .border(if (sel) 2.dp else 1.dp, if (sel) p.accent else p.cardBorder.first(), shape)
            ) {
                Box(
                    Modifier.size(150.dp).offset(x = (-40).dp, y = (-50).dp)
                        .background(Brush.radialGradient(listOf(p.blob1.copy(alpha = 0.55f), Color.Transparent)), CircleShape)
                )
                Box(
                    Modifier.align(Alignment.BottomEnd).size(170.dp).offset(x = 50.dp, y = 60.dp)
                        .background(Brush.radialGradient(listOf(p.blob2.copy(alpha = 0.50f), Color.Transparent)), CircleShape)
                )
                ThemeDecor(p, 0.12f, Modifier.fillMaxSize(), 1.4f)
                Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = p.ink, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text(p.tagline, color = p.muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (c in listOf(p.accent, p.accent2, p.blob2, p.blob3)) {
                                Box(Modifier.size(16.dp).background(c, CircleShape))
                            }
                        }
                    }
                    if (sel) {
                        Box(Modifier.size(34.dp).background(p.accent, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    } else {
                        Box(
                            Modifier.size(width = 58.dp, height = 40.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(Brush.linearGradient(listOf(p.cardTop, p.cardMid, p.cardBottom)))
                                .border(1.dp, Brush.linearGradient(p.cardBorder), RoundedCornerShape(13.dp))
                        )
                    }
                }
            }
        }
        Text(
            "Your choice is saved and used the next time you open the app too.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }
}

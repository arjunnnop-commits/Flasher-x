package com.fairyteam.fairyflasherx.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairyteam.fairyflasherx.R

/** Open animation: logo draws itself at the top, the girl rises from the bottom, the name types in. */
@Composable
fun SplashScreen() {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(4000, easing = LinearEasing)) }
    val p = t.value

    val inf = rememberInfiniteTransition(label = "splash")
    val pulse by inf.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    val logoP = (p / 0.55f).coerceIn(0f, 1f)
    val girlIn = FastOutSlowInEasing.transform(((p - 0.18f) / 0.40f).coerceIn(0f, 1f))

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(
            painter = painterResource(R.drawable.splash_girl),
            contentDescription = null,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .graphicsLayer {
                    alpha = girlIn
                    translationY = (1f - girlIn) * 90f
                }
        )

        Box(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 64.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            DrawnLogo(progress = logoP, modifier = Modifier.fillMaxWidth(0.60f), pulse = pulse)
        }

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Row(Modifier.offset(y = (-24).dp)) {
                val title = "FAIRY FLASHER X"
                for ((i, ch) in title.withIndex()) {
                    val a = ((p - 0.42f - i * 0.018f) / 0.08f).coerceIn(0f, 1f)
                    androidx.compose.material3.Text(
                        if (ch == ' ') "\u00A0" else ch.toString(),
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp,
                        style = TextStyle(
                            shadow = Shadow(Color.White.copy(alpha = 0.85f * pulse), Offset.Zero, 22f)
                        ),
                        modifier = Modifier.graphicsLayer {
                            alpha = a
                            translationY = (1f - a) * 24f
                        }
                    )
                }
            }
        }
    }
}

package com.fairyteam.fairyflasherx.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** All colors of one look. Every screen reads these through [LocalFairy]. */
class FairyPalette(
    val id: String,
    val name: String,
    val tagline: String,
    val dark: Boolean,
    val bg: List<Color>,
    val blob1: Color,
    val blob2: Color,
    val blob3: Color,
    val ink: Color,
    val muted: Color,
    val accent: Color,
    val accent2: Color,
    val cardTop: Color,
    val cardMid: Color,
    val cardBottom: Color,
    val cardBorder: List<Color>,
    val surface: Color,
    val iconBase: Color,
    val divider: Color,
    val dialog: Color,
    val bar: Color,
    val button: List<Color>,
    val console: List<Color>
)

object Palettes {
    val Liquid = FairyPalette(
        id = "liquid", name = "Liquid Glass", tagline = "Light, soft and glossy", dark = false,
        bg = listOf(Color(0xFFE6E8F8), Color(0xFFFBEFF6), Color(0xFFD9F7F7)),
        blob1 = Color(0xFFF18BEA), blob2 = Color(0xFF69E6E4), blob3 = Color(0xFF9274EF),
        ink = Color(0xFF17223D), muted = Color(0xFF697694),
        accent = Color(0xFF6967F5), accent2 = Color(0xFFF18BEA),
        cardTop = Color.White.copy(alpha = 0.82f), cardMid = Color(0xFFE8F3FF).copy(alpha = 0.67f), cardBottom = Color.White.copy(alpha = 0.55f),
        cardBorder = listOf(Color.White, Color(0xFF69E6E4).copy(alpha = 0.55f), Color(0xFFF18BEA).copy(alpha = 0.3f)),
        surface = Color.White.copy(alpha = 0.6f), iconBase = Color.White, divider = Color.White.copy(alpha = 0.8f),
        dialog = Color(0xFFF6F7FF), bar = Color.White.copy(alpha = 0.72f),
        button = listOf(Color(0xFF4F9BFF), Color(0xFF6967F5), Color(0xFFF18BEA)),
        console = listOf(Color(0xFF1D2540), Color(0xFF3A4366))
    )

    val Midnight = FairyPalette(
        id = "midnight", name = "Midnight Liquid", tagline = "Dark glass with blue glow", dark = true,
        bg = listOf(Color(0xFF080C1C), Color(0xFF111A3A), Color(0xFF07232E)),
        blob1 = Color(0xFF6C8CFF), blob2 = Color(0xFF22D3EE), blob3 = Color(0xFFB26BFF),
        ink = Color(0xFFF1F4FF), muted = Color(0xFF9AA6C8),
        accent = Color(0xFF7C9BFF), accent2 = Color(0xFFB26BFF),
        cardTop = Color.White.copy(alpha = 0.14f), cardMid = Color(0xFF9DB4FF).copy(alpha = 0.08f), cardBottom = Color.White.copy(alpha = 0.05f),
        cardBorder = listOf(Color.White.copy(alpha = 0.35f), Color(0xFF22D3EE).copy(alpha = 0.25f), Color(0xFFB26BFF).copy(alpha = 0.25f)),
        surface = Color.White.copy(alpha = 0.09f), iconBase = Color.White.copy(alpha = 0.12f), divider = Color.White.copy(alpha = 0.14f),
        dialog = Color(0xFF16204A), bar = Color(0xFF0E1530).copy(alpha = 0.85f),
        button = listOf(Color(0xFF3F7BFF), Color(0xFF7C5CFF), Color(0xFFB26BFF)),
        console = listOf(Color(0xFF0A1128), Color(0xFF1B2650))
    )

    val Crimson = FairyPalette(
        id = "crimson", name = "Fairy Crimson", tagline = "Matches the Fairy Team art", dark = true,
        bg = listOf(Color(0xFF14040B), Color(0xFF2B0614), Color(0xFF0A0105)),
        blob1 = Color(0xFFFF2D55), blob2 = Color(0xFFB0124A), blob3 = Color(0xFFFF6A3D),
        ink = Color(0xFFFFEFF3), muted = Color(0xFFC99AA8),
        accent = Color(0xFFFF3B6B), accent2 = Color(0xFFFF8FA9),
        cardTop = Color(0xFFFF5C84).copy(alpha = 0.18f), cardMid = Color(0xFFFF2D55).copy(alpha = 0.09f), cardBottom = Color.White.copy(alpha = 0.04f),
        cardBorder = listOf(Color(0xFFFF8FA9).copy(alpha = 0.55f), Color(0xFFFF2D55).copy(alpha = 0.30f), Color(0xFFFF6A3D).copy(alpha = 0.25f)),
        surface = Color(0xFFFF5C84).copy(alpha = 0.10f), iconBase = Color(0xFFFF5C84).copy(alpha = 0.16f), divider = Color(0xFFFF8FA9).copy(alpha = 0.18f),
        dialog = Color(0xFF2A0A17), bar = Color(0xFF1A0610).copy(alpha = 0.9f),
        button = listOf(Color(0xFFFF2D55), Color(0xFFE0245E), Color(0xFFFF6A3D)),
        console = listOf(Color(0xFF12030A), Color(0xFF3A0B1E))
    )

    val Aurora = FairyPalette(
        id = "aurora", name = "Aurora", tagline = "Green and teal northern lights", dark = true,
        bg = listOf(Color(0xFF03141A), Color(0xFF063A3A), Color(0xFF0A1E3C)),
        blob1 = Color(0xFF2CE5B3), blob2 = Color(0xFF4FA8FF), blob3 = Color(0xFF8B5CF6),
        ink = Color(0xFFEAFFF8), muted = Color(0xFF8CBAB5),
        accent = Color(0xFF2CE5B3), accent2 = Color(0xFF4FA8FF),
        cardTop = Color(0xFF9CFFE6).copy(alpha = 0.14f), cardMid = Color(0xFF2CE5B3).copy(alpha = 0.07f), cardBottom = Color.White.copy(alpha = 0.04f),
        cardBorder = listOf(Color(0xFF9CFFE6).copy(alpha = 0.45f), Color(0xFF4FA8FF).copy(alpha = 0.28f), Color(0xFF8B5CF6).copy(alpha = 0.22f)),
        surface = Color(0xFF9CFFE6).copy(alpha = 0.09f), iconBase = Color(0xFF9CFFE6).copy(alpha = 0.14f), divider = Color(0xFF9CFFE6).copy(alpha = 0.16f),
        dialog = Color(0xFF0B2E33), bar = Color(0xFF05222A).copy(alpha = 0.88f),
        button = listOf(Color(0xFF14B8A6), Color(0xFF2CE5B3), Color(0xFF4FA8FF)),
        console = listOf(Color(0xFF041419), Color(0xFF0B3A44))
    )

    val Sakura = FairyPalette(
        id = "sakura", name = "Sakura Dream", tagline = "Pink pastel light glass", dark = false,
        bg = listOf(Color(0xFFFFE6F0), Color(0xFFFFF5F9), Color(0xFFF1E4FF)),
        blob1 = Color(0xFFFF8FBF), blob2 = Color(0xFFC9A6FF), blob3 = Color(0xFFFFC2A8),
        ink = Color(0xFF3A1B2C), muted = Color(0xFF8E6577),
        accent = Color(0xFFEC4E95), accent2 = Color(0xFFB77BFF),
        cardTop = Color.White.copy(alpha = 0.85f), cardMid = Color(0xFFFFEAF4).copy(alpha = 0.70f), cardBottom = Color.White.copy(alpha = 0.55f),
        cardBorder = listOf(Color.White, Color(0xFFFF8FBF).copy(alpha = 0.5f), Color(0xFFC9A6FF).copy(alpha = 0.4f)),
        surface = Color.White.copy(alpha = 0.65f), iconBase = Color.White, divider = Color.White.copy(alpha = 0.85f),
        dialog = Color(0xFFFFF4F9), bar = Color.White.copy(alpha = 0.75f),
        button = listOf(Color(0xFFFF7AB5), Color(0xFFEC4E95), Color(0xFFB77BFF)),
        console = listOf(Color(0xFF3A1B2C), Color(0xFF6B3550))
    )

    val Amoled = FairyPalette(
        id = "amoled", name = "AMOLED Violet", tagline = "Pure black, neon violet", dark = true,
        bg = listOf(Color(0xFF000000), Color(0xFF07040F), Color(0xFF000000)),
        blob1 = Color(0xFF7C3AED), blob2 = Color(0xFF06B6D4), blob3 = Color(0xFFEC4899),
        ink = Color(0xFFF5F3FF), muted = Color(0xFF9A93B8),
        accent = Color(0xFF9B7BFF), accent2 = Color(0xFFEC4899),
        cardTop = Color.White.copy(alpha = 0.10f), cardMid = Color(0xFF9B7BFF).copy(alpha = 0.07f), cardBottom = Color.White.copy(alpha = 0.03f),
        cardBorder = listOf(Color.White.copy(alpha = 0.28f), Color(0xFF9B7BFF).copy(alpha = 0.35f), Color(0xFFEC4899).copy(alpha = 0.25f)),
        surface = Color.White.copy(alpha = 0.07f), iconBase = Color.White.copy(alpha = 0.10f), divider = Color.White.copy(alpha = 0.12f),
        dialog = Color(0xFF14101F), bar = Color(0xFF050308).copy(alpha = 0.92f),
        button = listOf(Color(0xFF6D28D9), Color(0xFF9B7BFF), Color(0xFFEC4899)),
        console = listOf(Color(0xFF050308), Color(0xFF1A1230))
    )

    val all: List<FairyPalette> = listOf(Liquid, Midnight, Crimson, Aurora, Sakura, Amoled)

    fun byId(id: String?): FairyPalette = all.firstOrNull { it.id == id } ?: Liquid
}

val LocalFairy = staticCompositionLocalOf { Palettes.Liquid }

// Colors that follow the selected theme. They are read inside composables, so old call sites keep working.
val Ink: Color @Composable get() = LocalFairy.current.ink
val Muted: Color @Composable get() = LocalFairy.current.muted
val Blue: Color @Composable get() = LocalFairy.current.accent
val Pink: Color @Composable get() = LocalFairy.current.accent2

// Fixed status / tint colors
val Cyan = Color(0xFF69E6E4)
val Teal = Color(0xFF15BFC6)
val Violet = Color(0xFF9274EF)
val Green = Color(0xFF20A879)
val Amber = Color(0xFFEC8C44)

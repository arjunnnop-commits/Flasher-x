package com.fairyteam.fairyflasherx.io

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract

/** One file inside a folder picked with the Storage Access Framework. */
class TreeFile(
    val relPath: String,
    val name: String,
    val uri: Uri,
    val size: Long,
    /** Set when the file lives inside a .zip: uri is then the zip itself. */
    val zipEntry: ZipEntryRef? = null
)

object TreeIndex {
    fun scan(cr: ContentResolver, treeUri: Uri, maxDepth: Int = 5, maxFiles: Int = 20000): List<TreeFile> {
        val out = ArrayList<TreeFile>()
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)

        fun walk(docId: String, prefix: String, depth: Int) {
            if (out.size >= maxFiles) return
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            val cursor = cr.query(childrenUri, cols, null, null, null) ?: return
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1)
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    if (id == null || name == null) continue
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < maxDepth) walk(id, prefix + name + "/", depth + 1)
                    } else {
                        out.add(TreeFile(prefix + name, name, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), size))
                    }
                }
            }
        }

        walk(rootId, "", 0)
        return out
    }

    /** Normalises a path taken from a script: slashes, leading "./" and "../". */
    fun normalize(token: String): String {
        var t = token.trim().replace('\\', '/')
        while (t.contains("//")) t = t.replace("//", "/")
        while (t.startsWith("./") || t.startsWith("../") || t.startsWith("/")) {
            t = if (t.startsWith("./")) t.substring(2) else if (t.startsWith("../")) t.substring(3) else t.substring(1)
        }
        return t
    }

    class Resolved(val file: TreeFile?, val approx: Boolean)

    /** Finds the file a script refers to, matching on the longest possible path suffix. */
    fun resolve(files: List<TreeFile>, token: String): TreeFile? = resolveEx(files, token).file

    /**
     * Same as [resolve] but also says when the match is only approximate:
     * same name with another extension (logo.img -> logo.bin), or the same partition by name
     * (preloader_raw.img -> preloader_duchamp.bin).
     */
    fun resolveEx(files: List<TreeFile>, token: String): Resolved {
        val norm = normalize(token).lowercase()
        if (norm.isEmpty()) return Resolved(null, false)
        val segs = norm.split('/')
        for (drop in segs.indices) {
            val sub = segs.drop(drop).joinToString("/")
            val matches = files.filter {
                val rp = it.relPath.lowercase()
                rp == sub || rp.endsWith("/$sub")
            }
            if (matches.size == 1) return Resolved(matches[0], false)
            if (matches.size > 1) return Resolved(matches.minByOrNull { it.relPath.length }, false)
        }
        val last = segs.last()
        // 1) same name, other extension / with or without "_raw"
        fun key(name: String): String {
            val n = name.lowercase()
            return n.substringBeforeLast('.', n).removeSuffix("_raw").removeSuffix("-raw")
        }
        val want = key(last)
        if (want.isEmpty()) return Resolved(null, false)
        val alt = files.filter { key(it.name) == want && PartitionGuess.isFlashable(it.name) }
        if (alt.isNotEmpty()) return Resolved(alt.minByOrNull { it.relPath.length }, true)
        // 2) same partition by name, only when that is unambiguous
        val part = PartitionGuess.guess(last) ?: return Resolved(null, false)
        val same = files.filter { PartitionGuess.isFlashable(it.name) && PartitionGuess.guess(it.name) == part }
        if (same.size == 1) return Resolved(same[0], true)
        return Resolved(null, false)
    }
}


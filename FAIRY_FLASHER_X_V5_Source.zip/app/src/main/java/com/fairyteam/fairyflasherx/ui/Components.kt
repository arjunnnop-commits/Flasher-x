package com.fairyteam.fairyflasherx.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairyteam.fairyflasherx.FlasherViewModel


@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val p = LocalFairy.current
    val t = rememberInfiniteTransition(label = "liquid")
    val d1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "d1")
    val d2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "d2")
    val d3 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse), label = "d3")
    val boost = if (p.dark) 1.0f else 0.0f
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(p.bg))
    ) {
        Box(
            Modifier
                .size(320.dp)
                .offset(x = (-100 + 70 * d1).dp, y = (-80 + 60 * d2).dp)
                .background(Brush.radialGradient(listOf(p.blob1.copy(alpha = if (p.dark) 0.38f else 0.35f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .size(340.dp)
                .offset(x = (100 - 70 * d2).dp, y = (100 - 60 * d1).dp)
                .background(Brush.radialGradient(listOf(p.blob2.copy(alpha = if (p.dark) 0.32f else 0.40f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .size(260.dp)
                .offset(x = (-130 + 160 * d3).dp, y = (80 - 140 * d3).dp)
                .background(Brush.radialGradient(listOf(p.blob3.copy(alpha = 0.16f + 0.10f * boost), Color.Transparent)), CircleShape)
        )
        val decorT by t.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart), label = "decor")
        ThemeDecor(p, decorT)
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalFairy.current
    val shape = RoundedCornerShape(24.dp)
    val sheenA = if (p.dark) 0.10f else 0.45f
    val lineA = if (p.dark) 0.35f else 0.9f
    var m = modifier
    if (onClick != null) m = m.bounceClick(shape, if (p.dark) Color.White else p.accent, onTap = onClick)
    m = m
        .clip(shape)
        .background(Brush.linearGradient(listOf(p.cardTop, p.cardMid, p.cardBottom)))
        .drawBehind {
            // glass sheen: a soft diagonal highlight and a thin specular line along the top edge
            drawRect(Brush.linearGradient(0f to Color.White.copy(alpha = sheenA), 0.5f to Color.Transparent, 1f to Color.White.copy(alpha = sheenA * 0.25f)))
            drawLine(
                Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = lineA), Color.Transparent)),
                Offset(size.width * 0.12f, 1.5f), Offset(size.width * 0.88f, 1.5f), strokeWidth = 2f
            )
        }
        .border(1.dp, Brush.linearGradient(p.cardBorder), shape)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun GlassIconButton(icon: ImageVector, onClick: () -> Unit) {
    val p = LocalFairy.current
    Box(
        Modifier
            .size(42.dp)
            .bounceClick(CircleShape, if (p.dark) Color.White else p.accent, onTap = onClick)
            .clip(CircleShape)
            .background(p.surface)
            .border(1.dp, p.cardBorder.first(), CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Ink, modifier = Modifier.size(22.dp)) }
}

@Composable
fun PageScaffold(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                GlassIconButton(Icons.Default.ArrowBack, onBack)
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black)
                if (subtitle.isNotEmpty()) Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            actions()
        }
        content()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ToolRow(icon: ImageVector, title: String, subtitle: String, tint: Color = Blue, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .background(Brush.linearGradient(listOf(LocalFairy.current.iconBase, tint.copy(alpha = 0.22f))), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, null, tint = tint)
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val p = LocalFairy.current
    val brush = if (enabled) Brush.horizontalGradient(p.button)
    else Brush.horizontalGradient(listOf(p.muted.copy(alpha = 0.45f), p.muted.copy(alpha = 0.35f)))
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .bounceClick(shape, Color.White, enabled = enabled, onTap = onClick)
            .clip(shape)
            .background(brush),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun SelectRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    val pal = LocalFairy.current
    Row(
        Modifier
            .fillMaxWidth()
            .bounceClick(RoundedCornerShape(16.dp), if (pal.dark) Color.White else pal.accent, onTap = onClick)
            .clip(RoundedCornerShape(16.dp))
            .background(pal.surface)
            .border(1.dp, pal.cardBorder.first().copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(value, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun FairyField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Blue,
            unfocusedBorderColor = Muted.copy(alpha = 0.4f),
            focusedTextColor = Ink,
            unfocusedTextColor = Ink,
            focusedLabelColor = Blue,
            unfocusedLabelColor = Muted,
            cursorColor = Blue
        )
    )
}

@Composable
fun InputDialog(
    title: String,
    label: String,
    initial: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold) },
        text = { FairyField(text, { text = it }, label) },
        confirmButton = {
            TextButton(onClick = { onDismiss(); onConfirm(text) }) { Text(confirmText, color = Blue, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmText: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold) },
        text = { Text(message, color = Muted, fontSize = 14.sp) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmText, color = Pink, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}

/** Dark pill at the bottom of tool pages that shows the latest log line. */
@Composable
fun ConsoleBar(vm: FlasherViewModel) {
    val last = vm.logLines.lastOrNull() ?: "ready"
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(LocalFairy.current.console))
            .clickable { vm.showLog = true }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "> $last",
            color = Color(0xFFCBD3F0),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFCBD3F0))
    }
}

/** Sticky card shown while an operation is running. */
@Composable
fun BusyCard(vm: FlasherViewModel) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(LocalFairy.current.dialog.copy(alpha = 0.96f))
            .border(1.dp, Brush.horizontalGradient(listOf(Cyan, Blue, Pink)), RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.busyTitle, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (vm.progressLabel.isNotEmpty()) {
                    Text(vm.progressLabel, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            TextButton(onClick = { vm.stop() }) { Text("Stop", color = Pink, fontWeight = FontWeight.Bold) }
        }
        if (vm.failedIndex >= 0) {
            val i = vm.failedIndex
            Spacer(Modifier.height(6.dp))
            Text(
                "Step " + (i + 1) + " failed: " + vm.stepMessages.getOrElse(i) { "" },
                color = Color(0xFFFF4D6D), fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                QuickChip("Retry", Blue, true) { vm.decideStep(1) }
                QuickChip("Skip", Amber, true) { vm.decideStep(2) }
                QuickChip("Abort", Color(0xFFFF4D6D), true) { vm.decideStep(0) }
            }
        }
        Spacer(Modifier.height(6.dp))
        val p = vm.progressValue
        if (p in 0f..1f) {
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Blue, trackColor = Blue.copy(alpha = 0.15f))
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Blue, trackColor = Blue.copy(alpha = 0.15f))
        }
    }
}

@Composable
fun LogDialog(vm: FlasherViewModel) {
    val clipboard = LocalClipboardManager.current
    val lines = vm.logLines
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1)
    }
    AlertDialog(
        onDismissRequest = { vm.showLog = false },
        title = { Text("Log", color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp), state = listState) {
                items(lines) { line ->
                    Text(line, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.showLog = false }) { Text("Close", color = Blue, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n"))) }) { Text("Copy", color = Muted) }
                TextButton(onClick = { vm.clearLog() }) { Text("Clear", color = Muted) }
            }
        }
    )
}

/** Inline terminal for the Fastboot page: live log with status marks, a command field and Send. */
@Composable
fun ConsolePanel(vm: FlasherViewModel) {
    val clipboard = LocalClipboardManager.current
    val lines = vm.logLines.takeLast(200)
    val listState = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1)
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Console", color = Ink, fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { clipboard.setText(AnnotatedString(vm.logLines.joinToString("\n"))) }) { Text("Copy", color = Muted) }
            TextButton(onClick = { vm.clearLog() }) { Text("Clear", color = Muted) }
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0B0B0F))
                .padding(12.dp)
        ) {
            if (lines.isEmpty()) {
                Text("Type a fastboot command below, e.g. getvar:product", color = Color(0xFF7C8199), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    items(lines) { line ->
                        val (mark, body, color) = when {
                            line.startsWith("> ") -> Triple("\u25B6 ", line.removePrefix("> "), Color(0xFF8FB4FF))
                            line.startsWith("OK  ") -> Triple("\u2714 ", line.removePrefix("OK  "), Color(0xFF6EE7A0))
                            line.startsWith("ERROR") -> Triple("\u2716 ", line.removePrefix("ERROR").trim(), Color(0xFFFF6B8B))
                            else -> Triple("", line, Color(0xFFE3E7F7))
                        }
                        Text(mark + body, color = color, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { FairyField(text, { text = it }, "getvar:product") }
            Spacer(Modifier.width(10.dp))
            val can = text.isNotBlank() && !vm.busy
            Box(
                Modifier
                    .bounceClick(RoundedCornerShape(50), Color.White, enabled = can) { vm.fbCustom(text); text = "" }
                    .clip(RoundedCornerShape(50))
                    .background(if (can) Blue else Blue.copy(alpha = 0.25f))
                    .padding(horizontal = 22.dp, vertical = 14.dp)
            ) { Text("Send", color = Color.White, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(12.dp))
        QuickActions(vm)
    }
}

@Composable
private fun QuickChip(text: String, tint: Color, enabled: Boolean, onTap: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val p = LocalFairy.current
    Box(
        Modifier
            .bounceClick(shape, tint, enabled = enabled, onTap = onTap)
            .clip(shape)
            .background(tint.copy(alpha = if (enabled) 0.14f else 0.06f))
            .border(1.dp, tint.copy(alpha = if (enabled) 0.45f else 0.2f), shape)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) { Text(text, color = if (enabled) p.ink else p.muted, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
}

/** One-tap fastboot shortcuts. The risky ones ask first. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuickActions(vm: FlasherViewModel) {
    var ask by remember { mutableStateOf("") }
    val ok = !vm.busy
    Text("Quick actions", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        QuickChip("Reboot", Blue, ok) { vm.fbReboot("") }
        QuickChip("Bootloader", Blue, ok) { vm.fbReboot("bootloader") }
        QuickChip("Recovery", Blue, ok) { vm.fbReboot("recovery") }
        QuickChip("FastbootD", Blue, ok) { vm.fbReboot("fastboot") }
        QuickChip("getvar all", Teal, ok) { vm.fbCustom("getvar:all") }
        QuickChip("Unlock BL", Amber, ok) { ask = "unlock" }
        QuickChip("Lock BL", Amber, ok) { ask = "lock" }
        QuickChip("Wipe data", Color(0xFFFF4D6D), ok) { ask = "wipe" }
    }
    when (ask) {
        "unlock" -> ConfirmDialog(
            "Unlock bootloader?", "This sends \"flashing unlock\". Most phones erase all data when they unlock.", "Unlock",
            onDismiss = { ask = "" }, onConfirm = { vm.fbCustom("flashing unlock") }
        )
        "lock" -> ConfirmDialog(
            "Lock bootloader?", "Locking with a custom or modified ROM can stop the phone from booting. Only lock with the original stock ROM.", "Lock",
            onDismiss = { ask = "" }, onConfirm = { vm.fbCustom("flashing lock") }
        )
        "wipe" -> ConfirmDialog(
            "Wipe all data?", "This erases userdata and metadata. Photos, apps and settings on the phone will be gone.", "Wipe",
            onDismiss = { ask = "" }, onConfirm = { vm.fbErase("userdata"); vm.fbErase("metadata") }
        )
    }
}

/** Live checklist of a script flash: waiting, running, done, failed or skipped for every action. */
@Composable
fun StepChecklist(vm: FlasherViewModel) {
    val labels = vm.stepLabels
    val states = vm.stepStates
    val msgs = vm.stepMessages
    val done = states.count { it == 2 }
    val failed = states.count { it == 3 }
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Flash progress", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    done.toString() + " of " + labels.size + " done" + (if (failed > 0) "  -  $failed failed" else ""),
                    color = if (failed > 0) Color(0xFFFF4D6D) else Muted, fontSize = 12.sp
                )
            }
            if (!vm.busy) TextButton(onClick = { vm.clearSteps() }) { Text("Hide", color = Muted) }
        }
        Spacer(Modifier.height(6.dp))
        for (i in labels.indices) {
            val st = states.getOrElse(i) { 0 }
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                    when (st) {
                        1 -> CircularProgressIndicator(Modifier.size(17.dp), color = Blue, strokeWidth = 2.dp)
                        2 -> Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(20.dp))
                        3 -> Icon(Icons.Default.Error, null, tint = Color(0xFFFF4D6D), modifier = Modifier.size(20.dp))
                        4 -> Icon(Icons.Default.SkipNext, null, tint = Amber, modifier = Modifier.size(20.dp))
                        else -> Icon(Icons.Default.RadioButtonUnchecked, null, tint = Muted.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        (i + 1).toString() + ". " + labels[i],
                        color = when (st) { 3 -> Color(0xFFFF4D6D); 4 -> Muted; 0 -> Muted; else -> Ink },
                        fontSize = 13.sp, fontWeight = if (st == 1) FontWeight.Bold else FontWeight.Normal
                    )
                    val m = msgs.getOrElse(i) { "" }
                    if (m.isNotEmpty() && (st == 3 || st == 4)) Text(m, color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

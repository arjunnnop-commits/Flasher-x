package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.usb.CancelToken
import java.io.IOException

object FastbootFlasher {

    /**
     * Works out which partitions a "flash <name>" really targets, like the desktop fastboot tool:
     * "boot_ab" means both slots, slotted partitions get the current (or requested) slot suffix.
     */
    fun resolvePartitions(fb: FastbootClient, name: String, slot: String?): List<String> {
        if (name.endsWith("_ab")) {
            val base = name.removeSuffix("_ab")
            return listOf(base + "_a", base + "_b")
        }
        if (name.endsWith("_a") || name.endsWith("_b")) return listOf(name)
        val hasSlot = fb.getvar("has-slot:$name")?.trim()
        if (hasSlot == "yes") {
            if (slot == "all") return listOf(name + "_a", name + "_b")
            val s = if (slot != null && slot.isNotEmpty()) slot else (fb.currentSlot() ?: "a")
            return listOf(name + "_" + s)
        }
        return listOf(name)
    }

    private class Piece(val size: Long, val writer: ((ByteArray, Int, Int) -> Unit) -> Unit)

    private fun buildPieces(src: ImageSource, maxDownload: Long): List<Piece> {
        val buffer = ByteArray(512 * 1024)
        val sparse = Sparse.isSparse(src)
        if (src.size <= maxDownload) {
            val whole = Piece(src.size) { sink ->
                var pos = 0L
                while (pos < src.size) {
                    val n = minOf(buffer.size.toLong(), src.size - pos).toInt()
                    var done = 0
                    while (done < n) {
                        val r = src.readAt(pos + done, buffer, done, n - done)
                        if (r <= 0) throw IOException("Unexpected end of image file")
                        done += r
                    }
                    sink(buffer, 0, n)
                    pos += n
                }
            }
            return listOf(whole)
        }
        val layout = if (sparse) Sparse.parse(src) else Sparse.rawLayout(src.size)
        val plan = Sparse.plan(layout, maxDownload)
        return plan.map { p -> Piece(p.size) { sink -> Sparse.writePiece(p, src, buffer, sink) } }
    }

    /** Downloads [src] and runs "flash:<partition>". Large images are split into sparse pieces. */
    fun flash(
        fb: FastbootClient,
        partition: String,
        src: ImageSource,
        maxDownload: Long,
        cancel: CancelToken,
        progress: (Long, Long) -> Unit,
        log: (String) -> Unit
    ) {
        val pieces = buildPieces(src, maxDownload)
        var overall = 0L
        for (p in pieces) overall += p.size
        var sent = 0L
        for ((index, piece) in pieces.withIndex()) {
            cancel.check()
            if (pieces.size > 1) log("  part " + (index + 1) + " of " + pieces.size)
            fb.beginDownload(piece.size)
            piece.writer { buf, off, len ->
                fb.sendData(buf, off, len)
                sent += len
                progress(sent, overall)
            }
            fb.endDownload()
            fb.command("flash:$partition", 15L * 60_000L)
        }
    }

    /** Downloads [src] and boots it once ("fastboot boot"). */
    fun bootImage(fb: FastbootClient, src: ImageSource, cancel: CancelToken, progress: (Long, Long) -> Unit) {
        val buffer = ByteArray(512 * 1024)
        val total = src.size
        fb.beginDownload(total)
        var pos = 0L
        while (pos < total) {
            cancel.check()
            val n = minOf(buffer.size.toLong(), total - pos).toInt()
            var done = 0
            while (done < n) {
                val r = src.readAt(pos + done, buffer, done, n - done)
                if (r <= 0) throw IOException("Unexpected end of image file")
                done += r
            }
            fb.sendData(buffer, 0, n)
            pos += n
            progress(pos, total)
        }
        fb.endDownload()
        fb.command("boot", 60_000L)
    }
}

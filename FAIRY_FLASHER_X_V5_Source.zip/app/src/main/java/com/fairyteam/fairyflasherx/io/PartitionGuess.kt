package com.fairyteam.fairyflasherx.io

/** Works out the fastboot partition for a file name, and lists the usual partition names. */
object PartitionGuess {

    /** File extensions that normally hold flashable data. */
    val FLASH_EXT = setOf("img", "bin", "mbn", "elf", "hex", "melf", "imgf", "fv", "mdt", "dtb", "dtbo", "ext4", "raw", "sin", "ops", "tar")

    /** Names that are already partition names when used as a file name. */
    val COMMON: List<String> = listOf(
        "boot", "init_boot", "vendor_boot", "recovery", "dtbo", "dtb", "vbmeta", "vbmeta_system", "vbmeta_vendor",
        "system", "system_ext", "system_other", "vendor", "vendor_dlkm", "odm", "odm_dlkm", "product", "super",
        "userdata", "cache", "metadata", "persist", "modem", "bluetooth", "dsp", "abl", "xbl", "xbl_config",
        "tz", "hyp", "rpm", "aop", "devcfg", "keymaster", "cmnlib", "cmnlib64", "imagefv", "uefisecapp",
        "multiimgoem", "qupfw", "storsec", "featenabler", "sbl1", "aboot", "splash", "logo", "misc", "cust",
        "mdtp", "mdtpsecapp", "lk", "preloader", "tee1", "tee2", "spmfw", "scp", "sspm", "md1img", "md1dsp",
        "gz", "gz1", "vcp", "pi_img", "dpm", "mcupm", "cam_vpu1", "cam_vpu2", "cam_vpu3", "boot_para", "frp",
        "ramdisk", "radio", "bootloader", "vm-bootsys", "apdp", "vbmeta_a",
        "tee", "apusys", "audio_dsp", "ccu", "connsys_bt", "connsys_gnss", "connsys_wifi", "efuse", "gpueb",
        "gsort", "mcf_ota", "mvpu_algo", "oem_misc1", "rescue", "dpm", "sec1", "seccfg", "nvdata", "nvram",
        "nvcfg", "proinfo", "para", "expdb", "boot_para", "cdt", "oemcfg", "oem_misc", "vm", "pstore"
    )

    private val COMMON_BY_LENGTH: List<String> by lazy { COMMON.sortedByDescending { it.length } }

    private val ALIAS = mapOf(
        "non-hlos" to "modem",
        "nonhlos" to "modem",
        "radio" to "modem",
        "btfm" to "bluetooth",
        "dspso" to "dsp",
        "keymaster64" to "keymaster",
        "km4" to "keymaster",
        "emmc_appsboot" to "aboot",
        "appsboot" to "aboot",
        "sbl1" to "sbl1",
        "dtbo" to "dtbo",
        "boot_para" to "boot_para",
        "vbmeta_system" to "vbmeta_system",
        "vbmeta_vendor" to "vbmeta_vendor",
        "super_empty" to "super"
    )

    private val EXT_STRIP = FLASH_EXT

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun isFlashable(name: String): Boolean = extOf(name) in FLASH_EXT

    fun baseName(fileName: String): String {
        val n = fileName.substringAfterLast('/')
        val ext = extOf(n)
        return (if (ext in EXT_STRIP) n.substringBeforeLast('.') else n).lowercase()
    }

    /** Best guess of the partition for [fileName], or null when nothing fits. */
    fun guess(fileName: String): String? {
        val base = baseName(fileName)
        if (base.isEmpty()) return null
        ALIAS[base]?.let { return it }
        if (base in COMMON) return base
        // slot suffixes such as boot_a.img keep their name
        if ((base.endsWith("_a") || base.endsWith("_b")) && base.dropLast(2) in COMMON) return base
        if (base.endsWith("_ab") && base.dropLast(3) in COMMON) return base

        if (base.contains("vendor_boot") || base.contains("vendor-boot")) return "vendor_boot"
        if (base.contains("init_boot") || base.contains("init-boot")) return "init_boot"
        if (base.contains("vbmeta")) return if (base.contains("system")) "vbmeta_system" else if (base.contains("vendor")) "vbmeta_vendor" else "vbmeta"
        if (base.contains("dtbo")) return "dtbo"
        val recoveryWords = listOf("recovery", "twrp", "orangefox", "ofox", "pbrp", "shrp", "skyhawk", "redwolf", "cwm")
        if (recoveryWords.any { base.contains(it) }) return "recovery"
        if (base.contains("modem") || base.contains("non-hlos")) return "modem"
        if (Regex("(^|[^a-z])boot([^a-z]|$)").containsMatchIn(base)) return "boot"
        // "system-sparsechunk.0" style or "system_new"
        for (p in listOf("system_ext", "system", "vendor", "product", "odm", "userdata", "super", "cache", "persist")) {
            if (base == p || base.startsWith(p + "-") || base.startsWith(p + "_") || base.startsWith(p + ".")) return p
        }
        // firmware files with a device name in them: preloader_duchamp.bin, lk_duchamp.img, logo_xxx.bin ...
        if (base.startsWith("preloader")) return "preloader"
        for (p in COMMON_BY_LENGTH) {
            if (p.length >= 2 && (base.startsWith(p + "_") || base.startsWith(p + "-"))) return p
        }
        return null
    }

    /** Like [guess], but a plain .img / .bin / .mbn / .elf with an unknown name is flashed to a partition of the same name. */
    fun guessOrName(fileName: String): String? {
        guess(fileName)?.let { return it }
        val n = fileName.substringAfterLast('/')
        if (extOf(n) !in setOf("img", "bin", "mbn", "elf")) return null
        val base = baseName(n)
        return if (base.isNotEmpty() && base.all { it.isLetterOrDigit() || it == '_' || it == '-' }) base else null
    }

    /** 0 = firmware (flash first), 1 = boot images, 2 = vbmeta, 3 = big system images, 4 = userdata (last). */
    fun order(partition: String): Int {
        val p = partition.removeSuffix("_a").removeSuffix("_b").removeSuffix("_ab")
        return when (p) {
            "userdata", "cache", "metadata" -> 4
            "super", "system", "system_ext", "vendor", "product", "odm", "vendor_dlkm", "odm_dlkm", "system_other" -> 3
            "vbmeta", "vbmeta_system", "vbmeta_vendor" -> 2
            "boot", "init_boot", "vendor_boot", "recovery", "dtbo", "dtb" -> 1
            else -> 0
        }
    }
}

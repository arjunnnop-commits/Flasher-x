# FAIRY FLASHER X  (V4)

Android app (Kotlin + Jetpack Compose, liquid-glass UI) that turns one phone into an
ADB / Fastboot host for another phone, using a USB OTG cable. No root, no desktop PC.

Built by @yooitachiijod  -  Telegram: https://t.me/FairysTeamBase

## Features

**ADB (USB host, own implementation of the protocol)**
- Detect device, model, Android version, mode (device / recovery / sideload)
- Reboot: system, recovery, bootloader, fastbootd, sideload
- Install APK, uninstall app (with app list), shell commands, push / pull files
- **ADB sideload** for AOSP / custom ROM zips (LineageOS, PixelExperience, ...) with progress

**Fastboot (USB host, own implementation of the protocol)**
- Detect, reboot (system / bootloader / recovery), partition info (`getvar all`)
- Flash a single image, erase partition, set active slot, custom command, boot once
- Big images (super.img etc.) are split into sparse pieces that fit `max-download-size`
- Slot handling like desktop fastboot (`boot` -> `boot_a/_b`, `boot_ab`, both slots)

**Flash script (.bat / .sh) + images folder**
- Pick `flash_all.bat` / `flash_all.sh` (Xiaomi style or any fastboot script) and the images folder
- The script is parsed, every `fastboot` / `adb` action is listed and the images are matched by name
- Preview with missing-file check, then the exact same steps are flashed from the phone
- Switches: *Keep my data* (skips userdata/metadata wipe) and *Skip bootloader lock/unlock* (both ON by default)

## New in V4

- **Animated open screen**: the Fairy Team logo draws itself (glowing outline, then solid), the anime girl rises from the bottom, and the title FAIRY FLASHER X types in letter by letter
  glowing progress bar with shine, zoom-out transition into the app
- **About page**: the logo draws itself on open (tap it to replay); new adaptive launcher icon with the logo
- **ZIP support**
  - Image tab: pick a `.zip`, every image inside is listed with an auto-detected partition (tick / edit / flash many at once)
  - Script tab: *Select ROM .zip* reads the `flash_all` script and images straight from the zip (no unpacking);
    if the zip has no script an automatic plan is built from the image names
  - Stored entries are read in place, compressed ones are unpacked to the cache for the moment they are flashed
  - Recovery / OTA zips (`payload.bin`, `update-binary`) are detected and sent to the Sideload tab
- **All partitions**: *Select Partition* lists every partition the bootloader reports (slots, logical partitions included);
  falls back to probing common names. Any file type is flashable (`.img .bin .mbn .elf ...`), partition is guessed from the
  file name (`NON-HLOS.bin` -> modem, `twrp-*.img` -> recovery, `xbl.elf`, `abl.elf`, `tz.mbn` ...)
- New flash modes: Slot A only / Slot B only
- **6 themes**: Liquid Glass, Midnight Liquid, Fairy Crimson, Aurora, Sakura Dream, AMOLED Violet (palette button on Home)

## Build on GitHub (no unpacking needed)

1. Create a GitHub repository.
2. Upload this `.zip` to the repository root (drag and drop - do not unpack it).
3. Add the workflow file: **Add file > Create new file**, name it `.github/workflows/build.yml`
   and paste the contents of `build.yml` (included next to this zip).
4. Open the **Actions** tab. The build starts automatically. When it is green open the run and
   download the artifact **FairyFlasherX-APK**.

If the repository already contains the unpacked project the same workflow also works.
If a build fails, download the artifact **build-log** and send it for a fix.

Local build: JDK 17, Android SDK 35, Gradle 8.9, then `gradle assembleDebug`.

## Using it

- Phone A (running this app) connects to phone B with a USB OTG cable.
- ADB: enable USB debugging on B and accept the "Allow USB debugging" prompt (tick "Always allow").
- Fastboot: boot B into the bootloader (power + volume down on most phones).
- Sideload: boot B into recovery, choose *Apply update > Apply from ADB*.
- Flashing needs an unlocked bootloader. A wrong image can brick a phone - you are responsible.

## Limits

- Phone A needs USB host (OTG) support.
- Images must be picked from local storage (not from cloud providers) so they can be read randomly.
- `fastboot update` / `flashall` zips are not supported; use the extracted `.img` files with a script.

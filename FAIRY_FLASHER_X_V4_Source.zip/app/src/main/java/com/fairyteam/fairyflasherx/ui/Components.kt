package com.fairyteam.fairyflasherx.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairyteam.fairyflasherx.FlasherViewModel


@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val p = LocalFairy.current
    val t = rememberInfiniteTransition(label = "liquid")
    val d1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "d1")
    val d2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "d2")
    val d3 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse), label = "d3")
    val boost = if (p.dark) 1.0f else 0.0f
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(p.bg))
    ) {
        Box(
            Modifier
                .size(320.dp)
                .offset(x = (-100 + 70 * d1).dp, y = (-80 + 60 * d2).dp)
                .background(Brush.radialGradient(listOf(p.blob1.copy(alpha = if (p.dark) 0.38f else 0.35f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .size(340.dp)
                .offset(x = (100 - 70 * d2).dp, y = (100 - 60 * d1).dp)
                .background(Brush.radialGradient(listOf(p.blob2.copy(alpha = if (p.dark) 0.32f else 0.40f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .size(260.dp)
                .offset(x = (-130 + 160 * d3).dp, y = (80 - 140 * d3).dp)
                .background(Brush.radialGradient(listOf(p.blob3.copy(alpha = 0.16f + 0.10f * boost), Color.Transparent)), CircleShape)
        )
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalFairy.current
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .shadow(if (p.dark) 4.dp else 10.dp, shape, ambientColor = p.accent.copy(alpha = 0.25f), spotColor = p.accent2.copy(alpha = 0.25f))
        .clip(shape)
        .background(Brush.linearGradient(listOf(p.cardTop, p.cardMid, p.cardBottom)))
        .border(1.dp, Brush.linearGradient(p.cardBorder), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun GlassIconButton(icon: ImageVector, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = LocalFairy.current.surface,
        modifier = Modifier.size(42.dp),
        border = BorderStroke(1.dp, LocalFairy.current.cardBorder.first()),
        shadowElevation = 6.dp
    ) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Ink, modifier = Modifier.size(22.dp)) }
    }
}

@Composable
fun PageScaffold(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                GlassIconButton(Icons.Default.ArrowBack, onBack)
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black)
                if (subtitle.isNotEmpty()) Text(subtitle, color = Muted, fontSize = 13.sp)
            }
            actions()
        }
        content()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ToolRow(icon: ImageVector, title: String, subtitle: String, tint: Color = Blue, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .background(Brush.linearGradient(listOf(LocalFairy.current.iconBase, tint.copy(alpha = 0.22f))), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, null, tint = tint)
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val p = LocalFairy.current
    val brush = if (enabled) Brush.horizontalGradient(p.button)
    else Brush.horizontalGradient(listOf(p.muted.copy(alpha = 0.45f), p.muted.copy(alpha = 0.35f)))
    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(shape)
            .background(brush)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun SelectRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(LocalFairy.current.surface)
            .clickable(onClick = onClick)
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(value, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun FairyField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Blue,
            unfocusedBorderColor = Muted.copy(alpha = 0.4f),
            focusedTextColor = Ink,
            unfocusedTextColor = Ink,
            focusedLabelColor = Blue,
            unfocusedLabelColor = Muted,
            cursorColor = Blue
        )
    )
}

@Composable
fun InputDialog(
    title: String,
    label: String,
    initial: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold) },
        text = { FairyField(text, { text = it }, label) },
        confirmButton = {
            TextButton(onClick = { onDismiss(); onConfirm(text) }) { Text(confirmText, color = Blue, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmText: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Ink, fontWeight = FontWeight.Bold) },
        text = { Text(message, color = Muted, fontSize = 14.sp) },
        confirmButton = {
            TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmText, color = Pink, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}

/** Dark pill at the bottom of tool pages that shows the latest log line. */
@Composable
fun ConsoleBar(vm: FlasherViewModel) {
    val last = vm.logLines.lastOrNull() ?: "ready"
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(LocalFairy.current.console))
            .clickable { vm.showLog = true }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "> $last",
            color = Color(0xFFCBD3F0),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFCBD3F0))
    }
}

/** Sticky card shown while an operation is running. */
@Composable
fun BusyCard(vm: FlasherViewModel) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(LocalFairy.current.dialog.copy(alpha = 0.96f))
            .border(1.dp, Brush.horizontalGradient(listOf(Cyan, Blue, Pink)), RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.busyTitle, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (vm.progressLabel.isNotEmpty()) {
                    Text(vm.progressLabel, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            TextButton(onClick = { vm.stop() }) { Text("Stop", color = Pink, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(6.dp))
        val p = vm.progressValue
        if (p in 0f..1f) {
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Blue, trackColor = Blue.copy(alpha = 0.15f))
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Blue, trackColor = Blue.copy(alpha = 0.15f))
        }
    }
}

@Composable
fun LogDialog(vm: FlasherViewModel) {
    val clipboard = LocalClipboardManager.current
    val lines = vm.logLines
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1)
    }
    AlertDialog(
        onDismissRequest = { vm.showLog = false },
        title = { Text("Log", color = Ink, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp), state = listState) {
                items(lines) { line ->
                    Text(line, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.showLog = false }) { Text("Close", color = Blue, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n"))) }) { Text("Copy", color = Muted) }
                TextButton(onClick = { vm.clearLog() }) { Text("Clear", color = Muted) }
            }
        }
    )
}

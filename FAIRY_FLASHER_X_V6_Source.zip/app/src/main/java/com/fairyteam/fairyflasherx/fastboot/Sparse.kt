package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.io.readFullyAt
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** One contiguous run of blocks inside a sparse image. */
class SparseChunk(
    val type: Int,
    val startBlock: Long,
    val blocks: Long,
    val srcOffset: Long,
    val fill: Int
)

class SparseLayout(val blockSize: Int, val totalBlocks: Long, val chunks: List<SparseChunk>)

/** A sparse image that fits in the device's download buffer. */
class SparsePiece(val layout: SparseLayout, val chunks: List<SparseChunk>) {
    val size: Long
        get() {
            var total = HEADER_SIZE.toLong()
            var cursor = 0L
            for (c in chunks) {
                if (c.startBlock > cursor) total += CHUNK_HEADER_SIZE
                total += CHUNK_HEADER_SIZE + Sparse.dataBytes(c, layout.blockSize)
                cursor = c.startBlock + c.blocks
            }
            if (cursor < layout.totalBlocks) total += CHUNK_HEADER_SIZE
            return total
        }
}

const val HEADER_SIZE = 28
const val CHUNK_HEADER_SIZE = 12

object Sparse {
    val MAGIC: Int = 0xED26FF3A.toInt()
    const val TYPE_RAW = 0xCAC1
    const val TYPE_FILL = 0xCAC2
    const val TYPE_DONT_CARE = 0xCAC3
    const val TYPE_CRC32 = 0xCAC4

    fun dataBytes(c: SparseChunk, blockSize: Int): Long {
        return when (c.type) {
            TYPE_RAW -> c.blocks * blockSize
            TYPE_FILL -> 4L
            else -> 0L
        }
    }

    fun isSparse(src: ImageSource): Boolean {
        if (src.size < HEADER_SIZE) return false
        val b = ByteArray(4)
        src.readFullyAt(0, b, 0, 4)
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt() == MAGIC
    }

    /** Layout of a plain raw file: one RAW chunk covering the whole file. */
    fun rawLayout(size: Long, blockSize: Int = 4096): SparseLayout {
        val blocks = (size + blockSize - 1) / blockSize
        return SparseLayout(blockSize, blocks, listOf(SparseChunk(TYPE_RAW, 0, blocks, 0, 0)))
    }

    fun parse(src: ImageSource): SparseLayout {
        val h = ByteArray(HEADER_SIZE)
        src.readFullyAt(0, h, 0, HEADER_SIZE)
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        bb.getInt() // magic
        bb.getShort() // major
        bb.getShort() // minor
        val fileHdr = bb.getShort().toInt() and 0xFFFF
        val chunkHdr = bb.getShort().toInt() and 0xFFFF
        val blockSize = bb.getInt()
        val totalBlocks = bb.getInt().toLong() and 0xFFFFFFFFL
        val totalChunks = bb.getInt().toLong() and 0xFFFFFFFFL
        if (blockSize <= 0 || blockSize % 4 != 0) throw IOException("Invalid sparse image block size")
        val chunks = ArrayList<SparseChunk>()
        var off = fileHdr.toLong()
        var block = 0L
        val ch = ByteArray(CHUNK_HEADER_SIZE)
        var i = 0L
        while (i < totalChunks) {
            src.readFullyAt(off, ch, 0, CHUNK_HEADER_SIZE)
            val cb = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
            val type = cb.getShort().toInt() and 0xFFFF
            cb.getShort() // reserved
            val chunkBlocks = cb.getInt().toLong() and 0xFFFFFFFFL
            val totalSz = cb.getInt().toLong() and 0xFFFFFFFFL
            when (type) {
                TYPE_RAW -> {
                    chunks.add(SparseChunk(TYPE_RAW, block, chunkBlocks, off + chunkHdr, 0))
                    block += chunkBlocks
                }
                TYPE_FILL -> {
                    val f = ByteArray(4)
                    src.readFullyAt(off + chunkHdr, f, 0, 4)
                    val fv = ByteBuffer.wrap(f).order(ByteOrder.LITTLE_ENDIAN).getInt()
                    chunks.add(SparseChunk(TYPE_FILL, block, chunkBlocks, 0, fv))
                    block += chunkBlocks
                }
                TYPE_DONT_CARE -> block += chunkBlocks
                TYPE_CRC32 -> {}
                else -> throw IOException("Unknown sparse chunk type 0x" + Integer.toHexString(type))
            }
            off += totalSz
            i++
        }
        return SparseLayout(blockSize, totalBlocks, chunks)
    }

    /** The part of [layout] that lies at or after [startBlock] (used to resume an interrupted flash). */
    fun trimFrom(layout: SparseLayout, startBlock: Long): SparseLayout {
        if (startBlock <= 0L) return layout
        val bs = layout.blockSize
        val out = ArrayList<SparseChunk>()
        for (c in layout.chunks) {
            val end = c.startBlock + c.blocks
            if (end <= startBlock) continue
            if (c.startBlock >= startBlock) {
                out.add(c)
                continue
            }
            val skip = startBlock - c.startBlock
            if (c.type == TYPE_RAW) {
                out.add(SparseChunk(TYPE_RAW, startBlock, c.blocks - skip, c.srcOffset + skip * bs, 0))
            } else {
                out.add(SparseChunk(c.type, startBlock, c.blocks - skip, 0, c.fill))
            }
        }
        return SparseLayout(layout.blockSize, layout.totalBlocks, out)
    }

    /** Splits a layout into pieces that each serialise to at most [limit] bytes. */
    fun plan(layout: SparseLayout, limit: Long): List<SparsePiece> {
        val bs = layout.blockSize
        val pieces = ArrayList<SparsePiece>()
        var cur = ArrayList<SparseChunk>()
        val base = (HEADER_SIZE + CHUNK_HEADER_SIZE).toLong() // header + trailing DONT_CARE
        var curBytes = base

        for (c in layout.chunks) {
            var chunk = c
            while (true) {
                val need = 2L * CHUNK_HEADER_SIZE + dataBytes(chunk, bs) // chunk header + possible gap chunk
                if (curBytes + need <= limit) {
                    cur.add(chunk)
                    curBytes += need
                    break
                }
                if (chunk.type == TYPE_RAW) {
                    val avail = limit - curBytes - 2L * CHUNK_HEADER_SIZE
                    val k = avail / bs
                    if (k >= 1) {
                        cur.add(SparseChunk(TYPE_RAW, chunk.startBlock, k, chunk.srcOffset, 0))
                        pieces.add(SparsePiece(layout, cur))
                        cur = ArrayList()
                        curBytes = base
                        chunk = SparseChunk(
                            TYPE_RAW,
                            chunk.startBlock + k,
                            chunk.blocks - k,
                            chunk.srcOffset + k * bs,
                            0
                        )
                        continue
                    }
                }
                if (cur.isEmpty()) throw IOException("The device's max-download-size is too small for this image")
                pieces.add(SparsePiece(layout, cur))
                cur = ArrayList()
                curBytes = base
            }
        }
        if (cur.isNotEmpty() || pieces.isEmpty()) pieces.add(SparsePiece(layout, cur))
        return pieces
    }

    private fun chunkHeader(type: Int, blocks: Long, totalSize: Long): ByteArray {
        val bb = ByteBuffer.allocate(CHUNK_HEADER_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        bb.putShort(type.toShort())
        bb.putShort(0.toShort())
        bb.putInt(blocks.toInt())
        bb.putInt(totalSize.toInt())
        return bb.array()
    }

    private fun readPadded(src: ImageSource, pos: Long, buf: ByteArray, n: Int) {
        var done = 0
        while (done < n) {
            val absolute = pos + done
            if (absolute >= src.size) {
                java.util.Arrays.fill(buf, done, n, 0.toByte())
                return
            }
            val want = minOf((n - done).toLong(), src.size - absolute).toInt()
            val r = src.readAt(absolute, buf, done, want)
            if (r <= 0) throw IOException("Unexpected end of image file")
            done += r
        }
    }

    /** Streams one piece as a valid sparse image to [sink]. */
    fun writePiece(piece: SparsePiece, src: ImageSource, buf: ByteArray, sink: (ByteArray, Int, Int) -> Unit) {
        val layout = piece.layout
        val bs = layout.blockSize
        var count = 0
        var cursor = 0L
        for (c in piece.chunks) {
            if (c.startBlock > cursor) count++
            count++
            cursor = c.startBlock + c.blocks
        }
        if (cursor < layout.totalBlocks) count++

        val hdr = ByteBuffer.allocate(HEADER_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        hdr.putInt(MAGIC)
        hdr.putShort(1.toShort())
        hdr.putShort(0.toShort())
        hdr.putShort(HEADER_SIZE.toShort())
        hdr.putShort(CHUNK_HEADER_SIZE.toShort())
        hdr.putInt(bs)
        hdr.putInt(layout.totalBlocks.toInt())
        hdr.putInt(count)
        hdr.putInt(0)
        sink(hdr.array(), 0, HEADER_SIZE)

        cursor = 0L
        for (c in piece.chunks) {
            if (c.startBlock > cursor) {
                val gap = chunkHeader(TYPE_DONT_CARE, c.startBlock - cursor, CHUNK_HEADER_SIZE.toLong())
                sink(gap, 0, gap.size)
            }
            if (c.type == TYPE_RAW) {
                val bytes = c.blocks * bs
                val h = chunkHeader(TYPE_RAW, c.blocks, CHUNK_HEADER_SIZE + bytes)
                sink(h, 0, h.size)
                var remaining = bytes
                var pos = c.srcOffset
                while (remaining > 0) {
                    val n = minOf(buf.size.toLong(), remaining).toInt()
                    readPadded(src, pos, buf, n)
                    sink(buf, 0, n)
                    pos += n
                    remaining -= n
                }
            } else if (c.type == TYPE_FILL) {
                val h = chunkHeader(TYPE_FILL, c.blocks, CHUNK_HEADER_SIZE + 4L)
                sink(h, 0, h.size)
                val f = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                f.putInt(c.fill)
                sink(f.array(), 0, 4)
            }
            cursor = c.startBlock + c.blocks
        }
        if (cursor < layout.totalBlocks) {
            val gap = chunkHeader(TYPE_DONT_CARE, layout.totalBlocks - cursor, CHUNK_HEADER_SIZE.toLong())
            sink(gap, 0, gap.size)
        }
    }
}

package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.formatSize
import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.usb.CancelToken
import com.fairyteam.fairyflasherx.usb.StopRequestedException
import java.io.IOException

object FastbootFlasher {

    /**
     * Works out which partitions a "flash <name>" really targets, like the desktop fastboot tool:
     * "boot_ab" means both slots, slotted partitions get the current (or requested) slot suffix.
     */
    fun resolvePartitions(fb: FastbootClient, name: String, slot: String?): List<String> {
        if (name.endsWith("_ab")) {
            val base = name.removeSuffix("_ab")
            return listOf(base + "_a", base + "_b")
        }
        if (name.endsWith("_a") || name.endsWith("_b")) return listOf(name)
        val hasSlot = fb.getvar("has-slot:$name")?.trim()
        if (hasSlot == "yes") {
            if (slot == "all") return listOf(name + "_a", name + "_b")
            val s = if (slot != null && slot.isNotEmpty()) slot else (fb.currentSlot() ?: "a")
            return listOf(name + "_" + s)
        }
        return listOf(name)
    }

    private class Piece(val size: Long, val writer: ((ByteArray, Int, Int) -> Unit) -> Unit)

    private const val MIN_LIMIT = 2L * 1024 * 1024
    private const val MAX_RECONNECTS = 10

    private fun wholePiece(src: ImageSource, buffer: ByteArray): Piece {
        return Piece(src.size) { sink ->
            var pos = 0L
            while (pos < src.size) {
                val n = minOf(buffer.size.toLong(), src.size - pos).toInt()
                var done = 0
                while (done < n) {
                    val r = src.readAt(pos + done, buffer, done, n - done)
                    if (r <= 0) throw IOException("Unexpected end of image file")
                    done += r
                }
                sink(buffer, 0, n)
                pos += n
            }
        }
    }

    /** True for a dropped / failing USB link (as opposed to the device answering FAIL, or the user pressing Stop). */
    private fun isUsbFailure(e: IOException): Boolean {
        return e !is StopRequestedException && e !is FastbootException
    }

    private fun sendPiece(
        fb: FastbootClient,
        partition: String,
        piece: Piece,
        progressBase: Long,
        overall: Long,
        progress: (Long, Long) -> Unit
    ) {
        var sent = progressBase
        fb.beginDownload(piece.size)
        piece.writer { buf, off, len ->
            fb.sendData(buf, off, len)
            sent += len
            progress(sent, overall)
        }
        fb.endDownload()
        fb.command("flash:$partition", 15L * 60_000L)
    }

    /**
     * Downloads [src] and runs "flash:<partition>". Large images are split into sparse pieces.
     *
     * If the USB link drops (cable, power, phone-to-phone OTG quirks), and [reconnect] is given, the
     * flash reconnects, halves the part size and resumes after the last part that finished, so a
     * multi-GB super.img does not have to start over. Returns the fastboot client to keep using,
     * because a reconnect replaces it.
     */
    fun flash(
        fb: FastbootClient,
        partition: String,
        src: ImageSource,
        maxDownload: Long,
        cancel: CancelToken,
        progress: (Long, Long) -> Unit,
        log: (String) -> Unit,
        reconnect: (() -> FastbootClient)? = null
    ): FastbootClient {
        val buffer = ByteArray(512 * 1024)
        var client = fb
        var limit = maxDownload
        var useWhole = src.size <= limit
        var startBlock = 0L
        var attempt = 0
        var layout: SparseLayout? = null

        while (true) {
            try {
                if (useWhole) {
                    cancel.check()
                    sendPiece(client, partition, wholePiece(src, buffer), 0L, src.size, progress)
                    return client
                }
                val full = layout ?: (if (Sparse.isSparse(src)) Sparse.parse(src) else Sparse.rawLayout(src.size))
                layout = full
                val rest = Sparse.trimFrom(full, startBlock)
                if (rest.chunks.isEmpty() && startBlock > 0L) return client
                val plan = Sparse.plan(rest, limit)
                val sized = plan.map { p -> Piece(p.size) { sink -> Sparse.writePiece(p, src, buffer, sink) } }
                var overall = 0L
                for (p in sized) overall += p.size
                var done = 0L
                for ((index, piece) in sized.withIndex()) {
                    cancel.check()
                    if (sized.size > 1) log("  part " + (index + 1) + " of " + sized.size)
                    sendPiece(client, partition, piece, done, overall, progress)
                    done += piece.size
                    val last = plan[index].chunks.lastOrNull()
                    if (last != null) startBlock = last.startBlock + last.blocks
                }
                return client
            } catch (e: IOException) {
                if (e is StopRequestedException) throw e
                if (reconnect == null || !isUsbFailure(e) || attempt >= MAX_RECONNECTS) throw e
                attempt++
                val base = if (useWhole) minOf(limit, src.size) else limit
                limit = maxOf(MIN_LIMIT, base / 2)
                useWhole = false
                log(
                    "   USB problem (" + (e.message ?: "unknown") + "), reconnecting and continuing with parts of " +
                        formatSize(limit) + " (retry " + attempt + ")"
                )
                client = reconnect()
            }
        }
    }

    /** Downloads [src] and boots it once ("fastboot boot"). */
    fun bootImage(fb: FastbootClient, src: ImageSource, cancel: CancelToken, progress: (Long, Long) -> Unit) {
        val buffer = ByteArray(512 * 1024)
        val total = src.size
        fb.beginDownload(total)
        var pos = 0L
        while (pos < total) {
            cancel.check()
            val n = minOf(buffer.size.toLong(), total - pos).toInt()
            var done = 0
            while (done < n) {
                val r = src.readAt(pos + done, buffer, done, n - done)
                if (r <= 0) throw IOException("Unexpected end of image file")
                done += r
            }
            fb.sendData(buffer, 0, n)
            pos += n
            progress(pos, total)
        }
        fb.endDownload()
        fb.command("boot", 60_000L)
    }
}

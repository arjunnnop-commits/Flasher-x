package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.usb.StopRequestedException
import com.fairyteam.fairyflasherx.usb.UsbLink
import java.io.IOException

class FastbootException(message: String) : IOException(message)

/** Fastboot protocol over USB: ASCII commands, INFO/OKAY/FAIL/DATA replies. */
class FastbootClient(private val link: UsbLink, private val log: (String) -> Unit) {

    private val rbuf = ByteArray(512)
    private var cachedMaxDownload: Long = -1L

    private class Reply(val tag: String, val msg: String)

    private fun readReply(timeoutMs: Long): Reply {
        val n = link.readTransfer(rbuf, 0, rbuf.size, timeoutMs)
        if (n < 4) return Reply("", "")
        return Reply(String(rbuf, 0, 4, Charsets.US_ASCII), String(rbuf, 4, n - 4, Charsets.UTF_8))
    }

    private fun sendText(cmd: String) {
        val bytes = cmd.toByteArray(Charsets.UTF_8)
        if (bytes.size > 64) throw FastbootException("Fastboot command is longer than 64 bytes")
        link.write(bytes, 0, bytes.size, 10_000)
    }

    private fun waitFinal(timeoutMs: Long, quiet: Boolean, sink: ((String) -> Unit)?): String {
        var deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) throw FastbootException("Timed out waiting for the device")
            val r = readReply(remaining)
            when (r.tag) {
                "INFO" -> {
                    if (sink != null) sink(r.msg)
                    if (!quiet) log("(bootloader) " + r.msg)
                    deadline = System.currentTimeMillis() + timeoutMs
                }
                "TEXT" -> {
                    if (!quiet) log(r.msg)
                    deadline = System.currentTimeMillis() + timeoutMs
                }
                "OKAY" -> return r.msg
                "FAIL" -> throw FastbootException(if (r.msg.isEmpty()) "FAIL" else r.msg)
                "DATA" -> return "DATA" + r.msg
                "" -> {}
                else -> throw FastbootException("Unexpected reply from device: " + r.tag + r.msg)
            }
        }
    }

    /** Sends [cmd] and returns the text that follows the final OKAY. */
    fun command(
        cmd: String,
        timeoutMs: Long = 120_000L,
        quiet: Boolean = false,
        sink: ((String) -> Unit)? = null
    ): String {
        sendText(cmd)
        return waitFinal(timeoutMs, quiet, sink)
    }

    /**
     * Called right after (re)connecting: discards stale replies and checks the device answers
     * commands again. If the bootloader is still waiting for the rest of an interrupted download it
     * will not answer, and the person has to re-enter bootloader mode.
     */
    fun resync() {
        link.drain()
        if (probe()) return
        // The bootloader may still be waiting for the rest of an interrupted download.
        // Finish that download with zeros (nothing is flashed without a "flash:" command).
        log("Device is waiting for the rest of an interrupted download - finishing it...")
        finishInterruptedDownload()
        link.drain()
        if (probe()) return
        throw FastbootException(
            "Device is stuck in the middle of an interrupted transfer. " +
                "Unplug the cable, reboot the phone to bootloader, reconnect and press Retry."
        )
    }

    private fun probe(): Boolean {
        return try {
            command("getvar:version", 4_000L, true)
            true
        } catch (e: StopRequestedException) {
            throw e
        } catch (e: IOException) {
            false
        }
    }

    private fun finishInterruptedDownload() {
        val zeros = ByteArray(256 * 1024)
        val limit = 288L * 1024 * 1024
        var sent = 0L
        try {
            while (sent < limit) {
                link.write(zeros, 0, zeros.size, 5_000)
                sent += zeros.size
                if (sent % (8L * 1024 * 1024) == 0L) {
                    try {
                        val n = link.readTransfer(rbuf, 0, rbuf.size, 1_200L)
                        if (n >= 4) return // OKAY (or FAIL): the device is out of the download
                    } catch (e: StopRequestedException) {
                        throw e
                    } catch (e: IOException) {
                        // no reply yet, keep sending
                    }
                }
            }
        } catch (e: StopRequestedException) {
            throw e
        } catch (e: IOException) {
            // the device does not accept data any more
        }
    }

    fun getvar(name: String): String? {
        return try {
            command("getvar:$name", 10_000L, true)
        } catch (e: FastbootException) {
            null
        }
    }

    fun getAllVars(): List<String> {
        val lines = ArrayList<String>()
        command("getvar:all", 60_000L, true) { lines.add(it) }
        return lines
    }

    fun getMaxDownload(): Long {
        if (cachedMaxDownload > 0) return cachedMaxDownload
        val raw = getvar("max-download-size")?.trim() ?: ""
        var v = 0L
        try {
            v = if (raw.startsWith("0x") || raw.startsWith("0X")) raw.substring(2).toLong(16) else raw.toLong()
        } catch (e: NumberFormatException) {
            v = 0L
        }
        if (v <= 0L) v = 256L * 1024 * 1024
        if (v > 256L * 1024 * 1024) v = 256L * 1024 * 1024
        cachedMaxDownload = v
        return v
    }

    fun currentSlot(): String? {
        val s = getvar("current-slot")?.trim() ?: return null
        val t = s.removePrefix("_")
        return if (t.isEmpty()) null else t
    }

    // ------------------------------------------------------------ data transfer

    fun beginDownload(size: Long) {
        sendText("download:" + String.format("%08x", size))
        val deadline = System.currentTimeMillis() + 30_000L
        while (true) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) throw FastbootException("Device did not accept the download")
            val r = readReply(remaining)
            when (r.tag) {
                "DATA" -> {
                    val hex = r.msg.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }
                    val n = hex.toLongOrNull(16) ?: -1L
                    if (n != size) throw FastbootException("Device announced a different download size")
                    return
                }
                "INFO", "TEXT" -> log("(bootloader) " + r.msg)
                "FAIL" -> throw FastbootException(if (r.msg.isEmpty()) "FAIL" else r.msg)
                "OKAY" -> throw FastbootException("Device answered OKAY instead of DATA")
                else -> {}
            }
        }
    }

    fun sendData(buf: ByteArray, off: Int, len: Int) {
        link.write(buf, off, len, 60_000)
    }

    fun endDownload() {
        waitFinal(180_000L, false, null)
    }

    // ------------------------------------------------------------ convenience

    fun reboot(target: String) {
        val cmd = when (target) {
            "" -> "reboot"
            "bootloader" -> "reboot-bootloader"
            "recovery" -> "reboot-recovery"
            "fastboot" -> "reboot-fastboot"
            else -> "reboot-$target"
        }
        try {
            command(cmd, 15_000L)
        } catch (e: FastbootException) {
            throw e
        } catch (e: IOException) {
            // the device disconnects while rebooting
        }
    }
}

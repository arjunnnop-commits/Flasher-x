package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.usb.UsbLink
import com.fairyteam.fairyflasherx.usb.UsbTimeoutException
import java.io.IOException

open class FastbootException(message: String) : IOException(message)

/** The device stopped answering (as opposed to answering FAIL). Safe to reconnect and retry. */
class FastbootTimeoutException(message: String) : FastbootException(message)

/** Fastboot protocol over USB: ASCII commands, INFO/OKAY/FAIL/DATA replies. */
class FastbootClient(private val link: UsbLink, private val log: (String) -> Unit) {

    private val rbuf = ByteArray(512)
    private var cachedMaxDownload: Long = -1L

    /** Bytes of the current download the device is still waiting for (0 when idle). */
    @Volatile
    var pendingBytes: Long = 0L
        private set

    private class Reply(val tag: String, val msg: String)

    private fun readReply(timeoutMs: Long): Reply {
        val n = link.readTransfer(rbuf, 0, rbuf.size, timeoutMs)
        if (n < 4) return Reply("", "")
        return Reply(String(rbuf, 0, 4, Charsets.US_ASCII), String(rbuf, 4, n - 4, Charsets.UTF_8))
    }

    private fun sendText(cmd: String) {
        val bytes = cmd.toByteArray(Charsets.UTF_8)
        if (bytes.size > 64) throw FastbootException("Fastboot command is longer than 64 bytes")
        link.write(bytes, 0, bytes.size, 10_000)
    }

    private fun waitFinal(timeoutMs: Long, quiet: Boolean, sink: ((String) -> Unit)?): String {
        var deadline = System.currentTimeMillis() + timeoutMs
        while (true) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) throw FastbootTimeoutException("Timed out waiting for the device")
            val r = try {
                readReply(minOf(remaining, 15_000L))
            } catch (e: UsbTimeoutException) {
                val left = deadline - System.currentTimeMillis()
                if (left <= 0) throw FastbootTimeoutException("Timed out waiting for the device")
                if (!quiet) log("   device is busy, still waiting... (" + ((timeoutMs - left) / 1000) + " s)")
                continue
            }
            when (r.tag) {
                "INFO" -> {
                    if (sink != null) sink(r.msg)
                    if (!quiet) log("(bootloader) " + r.msg)
                    deadline = System.currentTimeMillis() + timeoutMs
                }
                "TEXT" -> {
                    if (!quiet) log(r.msg)
                    deadline = System.currentTimeMillis() + timeoutMs
                }
                "OKAY" -> return r.msg
                "FAIL" -> throw FastbootException(if (r.msg.isEmpty()) "FAIL" else r.msg)
                "DATA" -> return "DATA" + r.msg
                "" -> {}
                else -> throw FastbootException("Unexpected reply from device: " + r.tag + r.msg)
            }
        }
    }

    /** Sends [cmd] and returns the text that follows the final OKAY. */
    fun command(
        cmd: String,
        timeoutMs: Long = 120_000L,
        quiet: Boolean = false,
        sink: ((String) -> Unit)? = null
    ): String {
        sendText(cmd)
        return waitFinal(timeoutMs, quiet, sink)
    }

    /**
     * Called right after (re)connecting. If the previous link died in the middle of a download, the
     * bootloader is still waiting for [pending] bytes and would swallow our next commands as data.
     * We pad that download out with zeros (nothing is flashed because no flash: command follows),
     * then check the device answers commands again.
     */
    fun resync(pending: Long = 0L) {
        link.drain()
        if (pending > 0L) {
            val zeros = ByteArray(16384)
            var left = pending
            try {
                while (left > 0L) {
                    val n = minOf(zeros.size.toLong(), left).toInt()
                    link.write(zeros, 0, n, 5_000)
                    left -= n
                }
            } catch (e: IOException) {
                // fall through, the check below decides
            }
            try {
                Thread.sleep(500)
            } catch (e: InterruptedException) {
            }
            link.drain()
        }
        var lastErr: IOException? = null
        for (attempt in 0 until 3) {
            try {
                command("getvar:version", 4_000L, true)
                return
            } catch (e: IOException) {
                lastErr = e
                // the device may still be a few bytes short of the announced size: pad a little more
                try {
                    link.write(ByteArray(16384), 0, 16384, 3_000)
                } catch (x: IOException) {
                }
                link.drain()
            }
        }
        throw FastbootException(
            "Device is stuck in the middle of an interrupted transfer. " +
                "Unplug the cable, reboot the phone to bootloader, reconnect and press Retry."
        )
    }

    fun getvar(name: String): String? {
        return try {
            command("getvar:$name", 10_000L, true)
        } catch (e: FastbootException) {
            null
        }
    }

    fun getAllVars(): List<String> {
        val lines = ArrayList<String>()
        command("getvar:all", 60_000L, true) { lines.add(it) }
        return lines
    }

    fun getMaxDownload(): Long {
        if (cachedMaxDownload > 0) return cachedMaxDownload
        val raw = getvar("max-download-size")?.trim() ?: ""
        var v = 0L
        try {
            v = if (raw.startsWith("0x") || raw.startsWith("0X")) raw.substring(2).toLong(16) else raw.toLong()
        } catch (e: NumberFormatException) {
            v = 0L
        }
        if (v <= 0L) v = 256L * 1024 * 1024
        if (v > 64L * 1024 * 1024) v = 64L * 1024 * 1024
        cachedMaxDownload = v
        return v
    }

    fun currentSlot(): String? {
        val s = getvar("current-slot")?.trim() ?: return null
        val t = s.removePrefix("_")
        return if (t.isEmpty()) null else t
    }

    // ------------------------------------------------------------ data transfer

    fun beginDownload(size: Long) {
        pendingBytes = 0L
        sendText("download:" + String.format("%08x", size))
        val deadline = System.currentTimeMillis() + 30_000L
        while (true) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) throw FastbootException("Device did not accept the download")
            val r = readReply(remaining)
            when (r.tag) {
                "DATA" -> {
                    val hex = r.msg.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }
                    val n = hex.toLongOrNull(16) ?: -1L
                    if (n != size) throw FastbootException("Device announced a different download size")
                    pendingBytes = size
                    return
                }
                "INFO", "TEXT" -> log("(bootloader) " + r.msg)
                "FAIL" -> throw FastbootException(if (r.msg.isEmpty()) "FAIL" else r.msg)
                "OKAY" -> throw FastbootException("Device answered OKAY instead of DATA")
                else -> {}
            }
        }
    }

    fun sendData(buf: ByteArray, off: Int, len: Int) {
        link.write(buf, off, len, 10_000)
        pendingBytes = maxOf(0L, pendingBytes - len)
    }

    fun endDownload() {
        waitFinal(180_000L, false, null)
        pendingBytes = 0L
    }

    // ------------------------------------------------------------ convenience

    fun reboot(target: String) {
        val cmd = when (target) {
            "" -> "reboot"
            "bootloader" -> "reboot-bootloader"
            "recovery" -> "reboot-recovery"
            "fastboot" -> "reboot-fastboot"
            else -> "reboot-$target"
        }
        try {
            command(cmd, 15_000L)
        } catch (e: FastbootException) {
            throw e
        } catch (e: IOException) {
            // the device disconnects while rebooting
        }
    }
}

package com.fairyteam.fairyflasherx.io

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.DataFormatException
import java.util.zip.Inflater

/** One file inside a .zip, read from the central directory. */
class ZipEntryRef(
    val name: String,
    val method: Int,
    val compSize: Long,
    val size: Long,
    val localOffset: Long
)

/** A window into another random access source (used for stored / uncompressed zip entries). */
class SliceImageSource(private val parent: ImageSource, private val start: Long, override val size: Long) : ImageSource {
    override fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        if (pos >= size) return -1
        val n = minOf(len.toLong(), size - pos).toInt()
        return parent.readAt(start + pos, buf, off, n)
    }

    override fun close() {
        parent.close()
    }
}

/**
 * Decompresses a deflated zip entry on the fly. Reading forward is cheap; reading backwards restarts
 * the decompression from the beginning. Used only when there is no room to unpack to storage.
 */
class InflateStreamSource(
    private val zip: ImageSource,
    private val start: Long,
    private val compSize: Long,
    override val size: Long
) : ImageSource {
    private var inf = Inflater(true)
    private val inBuf = ByteArray(256 * 1024)
    private val skipBuf = ByteArray(256 * 1024)
    private var readPos = 0L
    private var outPos = 0L

    private fun restart() {
        inf.end()
        inf = Inflater(true)
        readPos = 0L
        outPos = 0L
    }

    private fun inflateInto(b: ByteArray, o: Int, l: Int): Int {
        while (true) {
            if (inf.needsInput()) {
                val want = minOf(inBuf.size.toLong(), compSize - readPos).toInt()
                if (want <= 0) return -1
                zip.readFullyAt(start + readPos, inBuf, 0, want)
                inf.setInput(inBuf, 0, want)
                readPos += want
            }
            val n = try {
                inf.inflate(b, o, l)
            } catch (ex: DataFormatException) {
                throw IOException("Damaged compressed data")
            }
            if (n > 0) {
                outPos += n
                return n
            }
            if (inf.finished()) return -1
            if (inf.needsDictionary()) throw IOException("Unsupported zip data")
        }
    }

    @Synchronized
    override fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        if (pos >= size) return -1
        if (pos < outPos) restart()
        while (outPos < pos) {
            val n = inflateInto(skipBuf, 0, minOf(skipBuf.size.toLong(), pos - outPos).toInt())
            if (n <= 0) throw IOException("Unexpected end of compressed data")
        }
        val want = minOf(len.toLong(), size - pos).toInt()
        var done = 0
        while (done < want) {
            val n = inflateInto(buf, off + done, want - done)
            if (n <= 0) break
            done += n
        }
        return if (done == 0) -1 else done
    }

    override fun close() {
        try {
            inf.end()
        } catch (e: Exception) {
        }
        try {
            zip.close()
        } catch (e: Exception) {
        }
    }
}

/** A temporary file that is deleted again when it is closed (used for compressed zip entries). */
class TempFileImageSource(private val file: File, private val parent: ImageSource?) : ImageSource {
    private val raf = RandomAccessFile(file, "r")
    override val size: Long = raf.length()

    @Synchronized
    override fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        raf.seek(pos)
        return raf.read(buf, off, len)
    }

    override fun close() {
        try {
            raf.close()
        } catch (e: Exception) {
        }
        file.delete()
        try {
            parent?.close()
        } catch (e: Exception) {
        }
    }
}

/**
 * Minimal random access .zip reader (zip64 aware). Stored entries are read in place without copying,
 * deflated entries are unpacked to the app cache first.
 */
object ZipSupport {
    private const val SIG_EOCD = 0x06054b50
    private const val SIG_EOCD64 = 0x06064b50
    private const val SIG_LOC64 = 0x07064b50
    private const val SIG_CEN = 0x02014b50
    private const val SIG_LOCAL = 0x04034b50

    fun isZip(src: ImageSource): Boolean {
        if (src.size < 22) return false
        val b = ByteArray(4)
        src.readFullyAt(0, b, 0, 4)
        return b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && (b[2] == 3.toByte() || b[2] == 5.toByte())
    }

    private fun le(b: ByteArray): ByteBuffer = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)

    fun list(src: ImageSource): List<ZipEntryRef> {
        val tailLen = minOf(src.size, 66_000L).toInt()
        val tailStart = src.size - tailLen
        val tail = ByteArray(tailLen)
        src.readFullyAt(tailStart, tail, 0, tailLen)
        var eocd = -1
        var i = tailLen - 22
        while (i >= 0) {
            if (le(tail).getInt(i) == SIG_EOCD) {
                eocd = i
                break
            }
            i--
        }
        if (eocd < 0) throw IOException("This is not a valid .zip file")
        val bb = le(tail)
        var total = (bb.getShort(eocd + 10).toLong() and 0xFFFF)
        var cdSize = (bb.getInt(eocd + 12).toLong() and 0xFFFFFFFFL)
        var cdOffset = (bb.getInt(eocd + 16).toLong() and 0xFFFFFFFFL)

        if (total == 0xFFFFL || cdSize == 0xFFFFFFFFL || cdOffset == 0xFFFFFFFFL) {
            val locPos = tailStart + eocd - 20
            if (locPos >= 0) {
                val loc = ByteArray(20)
                src.readFullyAt(locPos, loc, 0, 20)
                val lb = le(loc)
                if (lb.getInt(0) == SIG_LOC64) {
                    val e64Pos = lb.getLong(8)
                    val e64 = ByteArray(56)
                    src.readFullyAt(e64Pos, e64, 0, 56)
                    val eb = le(e64)
                    if (eb.getInt(0) == SIG_EOCD64) {
                        total = eb.getLong(32)
                        cdSize = eb.getLong(40)
                        cdOffset = eb.getLong(48)
                    }
                }
            }
        }
        if (cdSize <= 0 || cdSize > 96L * 1024 * 1024) throw IOException("Zip directory is too large or damaged")
        val cd = ByteArray(cdSize.toInt())
        src.readFullyAt(cdOffset, cd, 0, cd.size)
        val cb = le(cd)

        val out = ArrayList<ZipEntryRef>()
        var p = 0
        while (p + 46 <= cd.size && cb.getInt(p) == SIG_CEN) {
            val method = cb.getShort(p + 10).toInt() and 0xFFFF
            var comp = cb.getInt(p + 20).toLong() and 0xFFFFFFFFL
            var uncomp = cb.getInt(p + 24).toLong() and 0xFFFFFFFFL
            val nameLen = cb.getShort(p + 28).toInt() and 0xFFFF
            val extraLen = cb.getShort(p + 30).toInt() and 0xFFFF
            val commentLen = cb.getShort(p + 32).toInt() and 0xFFFF
            var localOff = cb.getInt(p + 42).toLong() and 0xFFFFFFFFL
            val name = String(cd, p + 46, nameLen, Charsets.UTF_8).replace('\\', '/')

            if (uncomp == 0xFFFFFFFFL || comp == 0xFFFFFFFFL || localOff == 0xFFFFFFFFL) {
                var q = p + 46 + nameLen
                val end = q + extraLen
                while (q + 4 <= end) {
                    val id = cb.getShort(q).toInt() and 0xFFFF
                    val sz = cb.getShort(q + 2).toInt() and 0xFFFF
                    if (id == 1) {
                        var r = q + 4
                        if (uncomp == 0xFFFFFFFFL && r + 8 <= end) { uncomp = cb.getLong(r); r += 8 }
                        if (comp == 0xFFFFFFFFL && r + 8 <= end) { comp = cb.getLong(r); r += 8 }
                        if (localOff == 0xFFFFFFFFL && r + 8 <= end) { localOff = cb.getLong(r) }
                        break
                    }
                    q += 4 + sz
                }
            }
            if (!name.endsWith("/")) out.add(ZipEntryRef(name, method, comp, uncomp, localOff))
            p += 46 + nameLen + extraLen + commentLen
        }
        return out
    }

    private fun dataOffset(zip: ImageSource, e: ZipEntryRef): Long {
        val h = ByteArray(30)
        zip.readFullyAt(e.localOffset, h, 0, 30)
        val hb = le(h)
        if (hb.getInt(0) != SIG_LOCAL) throw IOException("Damaged zip entry: " + e.name)
        val nameLen = hb.getShort(26).toInt() and 0xFFFF
        val extraLen = hb.getShort(28).toInt() and 0xFFFF
        return e.localOffset + 30 + nameLen + extraLen
    }

    /**
     * Opens one entry as a random access source. [zip] is owned by the returned source and closed with it.
     * Compressed entries are unpacked into [cacheDir]; [progress] reports that unpacking.
     */
    fun open(
        zip: ImageSource,
        e: ZipEntryRef,
        cacheDir: File,
        cancelCheck: () -> Unit,
        progress: (Long, Long) -> Unit
    ): ImageSource {
        try {
            val start = dataOffset(zip, e)
            if (e.method == 0) return SliceImageSource(zip, start, e.size)
            if (e.method != 8) throw IOException("Unsupported zip compression (method " + e.method + ") in " + e.name)

            if (cacheDir.usableSpace < e.size + 64L * 1024 * 1024) {
                // Not enough room to unpack: decompress on the fly instead (slower, needs no storage).
                return InflateStreamSource(zip, start, e.compSize, e.size)
            }
            val tmp = File.createTempFile("fairy_", ".bin", cacheDir)
            try {
                val inf = Inflater(true)
                val inBuf = ByteArray(256 * 1024)
                val outBuf = ByteArray(512 * 1024)
                var readPos = 0L
                var written = 0L
                RandomAccessFile(tmp, "rw").use { raf ->
                    while (!inf.finished()) {
                        cancelCheck()
                        if (inf.needsInput()) {
                            val want = minOf(inBuf.size.toLong(), e.compSize - readPos).toInt()
                            if (want <= 0) break
                            zip.readFullyAt(start + readPos, inBuf, 0, want)
                            inf.setInput(inBuf, 0, want)
                            readPos += want
                        }
                        val n = try {
                            inf.inflate(outBuf)
                        } catch (ex: DataFormatException) {
                            throw IOException("Damaged compressed data in " + e.name)
                        }
                        if (n > 0) {
                            raf.write(outBuf, 0, n)
                            written += n
                            progress(written, maxOf(e.size, 1L))
                        } else if (inf.needsDictionary()) {
                            throw IOException("Unsupported zip data in " + e.name)
                        }
                    }
                }
                inf.end()
                return TempFileImageSource(tmp, zip)
            } catch (ex: Throwable) {
                tmp.delete()
                throw ex
            }
        } catch (ex: Throwable) {
            try {
                zip.close()
            } catch (x: Exception) {
            }
            throw ex
        }
    }

    /** Reads a small entry (for example a flash script) completely. */
    fun readSmall(zip: ImageSource, e: ZipEntryRef, cacheDir: File, limit: Long = 2L * 1024 * 1024): ByteArray {
        if (e.size > limit) throw IOException(e.name + " is too large to be a script")
        val z = open(zip, e, cacheDir, {}, { _, _ -> })
        z.use { s ->
            val b = ByteArray(s.size.toInt())
            if (b.isNotEmpty()) s.readFullyAt(0, b, 0, b.size)
            return b
        }
    }
}

package com.fairyteam.fairyflasherx.fastboot

import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.usb.CancelToken
import com.fairyteam.fairyflasherx.usb.StopRequestedException
import java.io.IOException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

object FastbootFlasher {

    /**
     * Works out which partitions a "flash <name>" really targets, like the desktop fastboot tool:
     * "boot_ab" means both slots, slotted partitions get the current (or requested) slot suffix.
     */
    fun resolvePartitions(fb: FastbootClient, name: String, slot: String?): List<String> {
        if (name.endsWith("_ab")) {
            val base = name.removeSuffix("_ab")
            return listOf(base + "_a", base + "_b")
        }
        if (name.endsWith("_a") || name.endsWith("_b")) return listOf(name)
        val hasSlot = fb.getvar("has-slot:$name")?.trim()
        if (hasSlot == "yes") {
            if (slot == "all") return listOf(name + "_a", name + "_b")
            val s = if (slot != null && slot.isNotEmpty()) slot else (fb.currentSlot() ?: "a")
            return listOf(name + "_" + s)
        }
        return listOf(name)
    }

    private class Piece(val size: Long, val endBlock: Long, val writer: ((ByteArray, Int, Int) -> Unit) -> Unit)

    private class Chunk(val buf: ByteArray?, val len: Int)

    /** Remembers how far a flash got, so a retry after a USB drop resumes instead of starting over. */
    class FlashState {
        @Volatile var resumeBlock: Long = 0L
        @Volatile var sentBytes: Long = 0L
        @Volatile var piecesDone: Int = 0
    }

    private const val POOL_BUFFERS = 40
    private const val POOL_BUF_SIZE = 512 * 1024

    /**
     * Reads the image on a background thread and feeds the USB link from a queue (about 20 MB ahead),
     * so a slow disk / SAF read never leaves the bootloader waiting for data.
     */
    private fun pump(
        piece: Piece, fb: FastbootClient, cancel: CancelToken,
        free: ArrayBlockingQueue<ByteArray>, onSent: (Int) -> Unit
    ) {
        val full = LinkedBlockingQueue<Chunk>()
        val abort = AtomicBoolean(false)
        val error = AtomicReference<Throwable?>(null)
        val eof = Chunk(null, 0)
        val producer = Thread {
            try {
                piece.writer { b, off, len ->
                    var pos = 0
                    while (pos < len) {
                        var buf: ByteArray? = null
                        while (buf == null) {
                            if (abort.get()) throw StopRequestedException()
                            buf = free.poll(200, TimeUnit.MILLISECONDS)
                        }
                        val got: ByteArray = buf!!
                        val n = minOf(got.size, len - pos)
                        System.arraycopy(b, off + pos, got, 0, n)
                        full.put(Chunk(got, n))
                        pos += n
                    }
                }
            } catch (t: Throwable) {
                error.set(t)
            } finally {
                full.put(eof)
            }
        }
        producer.isDaemon = true
        producer.start()
        try {
            while (true) {
                cancel.check()
                val c = full.poll(500, TimeUnit.MILLISECONDS) ?: continue
                if (c === eof) break
                val buf = c.buf!!
                try {
                    fb.sendData(buf, 0, c.len)
                } finally {
                    free.put(buf)
                }
                onSent(c.len)
            }
            val t = error.get()
            if (t != null) throw t
        } finally {
            abort.set(true)
            try {
                producer.join(3000)
            } catch (e: InterruptedException) {
            }
            // return any buffers still queued so the pool stays full for the next attempt
            while (true) {
                val c = full.poll() ?: break
                val b = c.buf
                if (b != null) free.offer(b)
            }
        }
    }

    private fun buildPieces(src: ImageSource, maxDownload: Long, resumeBlock: Long): List<Piece> {
        val buffer = ByteArray(POOL_BUF_SIZE)
        val sparse = Sparse.isSparse(src)
        if (src.size <= maxDownload) {
            val whole = Piece(src.size, -1L) { sink ->
                var pos = 0L
                while (pos < src.size) {
                    val n = minOf(buffer.size.toLong(), src.size - pos).toInt()
                    var done = 0
                    while (done < n) {
                        val r = src.readAt(pos + done, buffer, done, n - done)
                        if (r <= 0) throw IOException("Unexpected end of image file")
                        done += r
                    }
                    sink(buffer, 0, n)
                    pos += n
                }
            }
            return listOf(whole)
        }
        val full = if (sparse) Sparse.parse(src) else Sparse.rawLayout(src.size)
        val layout = Sparse.trim(full, resumeBlock)
        val plan = Sparse.plan(layout, maxDownload)
        return plan.mapIndexed { idx, p ->
            val end = if (idx == plan.size - 1) layout.totalBlocks
            else p.chunks.lastOrNull()?.let { it.startBlock + it.blocks } ?: layout.totalBlocks
            Piece(p.size, end) { sink -> Sparse.writePiece(p, src, buffer, sink) }
        }
    }

    /** Downloads [src] and runs "flash:<partition>". Large images are split into sparse pieces. */
    fun flash(
        fb: FastbootClient,
        partition: String,
        src: ImageSource,
        maxDownload: Long,
        cancel: CancelToken,
        progress: (Long, Long) -> Unit,
        log: (String) -> Unit
    ) {
        flash(fb, partition, src, maxDownload, cancel, FlashState(), progress, log)
    }

    /** Same, but resumable: [state] says where to continue after an interrupted attempt. */
    fun flash(
        fb: FastbootClient,
        partition: String,
        src: ImageSource,
        maxDownload: Long,
        cancel: CancelToken,
        state: FlashState,
        progress: (Long, Long) -> Unit,
        log: (String) -> Unit
    ) {
        val pieces = buildPieces(src, maxDownload, state.resumeBlock)
        var remaining = 0L
        for (p in pieces) remaining += p.size
        val grand = state.sentBytes + remaining
        val free = ArrayBlockingQueue<ByteArray>(POOL_BUFFERS)
        repeat(POOL_BUFFERS) { free.add(ByteArray(POOL_BUF_SIZE)) }
        if (state.resumeBlock > 0L) log("  resuming after block " + state.resumeBlock)
        for ((index, piece) in pieces.withIndex()) {
            cancel.check()
            if (pieces.size > 1 && (index == 0 || (index + 1) % 20 == 0 || index == pieces.size - 1)) {
                log("  part " + (index + 1) + " of " + pieces.size)
            }
            val startSent = state.sentBytes
            try {
                fb.beginDownload(piece.size)
                pump(piece, fb, cancel, free) { len ->
                    state.sentBytes += len
                    progress(state.sentBytes, grand)
                }
                fb.endDownload()
                fb.command("flash:$partition", 5L * 60_000L)
            } catch (e: Throwable) {
                state.sentBytes = startSent
                throw e
            }
            if (piece.endBlock >= 0) state.resumeBlock = piece.endBlock
            state.piecesDone++
        }
    }

    /** Downloads [src] and boots it once ("fastboot boot"). */
    fun bootImage(fb: FastbootClient, src: ImageSource, cancel: CancelToken, progress: (Long, Long) -> Unit) {
        val buffer = ByteArray(512 * 1024)
        val total = src.size
        fb.beginDownload(total)
        var pos = 0L
        while (pos < total) {
            cancel.check()
            val n = minOf(buffer.size.toLong(), total - pos).toInt()
            var done = 0
            while (done < n) {
                val r = src.readAt(pos + done, buffer, done, n - done)
                if (r <= 0) throw IOException("Unexpected end of image file")
                done += r
            }
            fb.sendData(buffer, 0, n)
            pos += n
            progress(pos, total)
        }
        fb.endDownload()
        fb.command("boot", 60_000L)
    }
}

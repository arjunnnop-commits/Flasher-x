package com.fairyteam.fairyflasherx.io

import android.content.ContentResolver
import android.net.Uri
import java.io.Closeable
import java.io.EOFException
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/** Random access, read-only file. */
interface ImageSource : Closeable {
    val size: Long
    fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int
}

fun ImageSource.readFullyAt(pos: Long, buf: ByteArray, off: Int, len: Int) {
    var done = 0
    while (done < len) {
        val r = readAt(pos + done, buf, off + done, len - done)
        if (r <= 0) throw EOFException("Unexpected end of file")
        done += r
    }
}

/** A file picked through the Storage Access Framework. */
class UriImageSource(private val cr: ContentResolver, private val uri: Uri) : ImageSource {
    private var pfd: android.os.ParcelFileDescriptor = open()
    private var channel: FileChannel = FileInputStream(pfd.fileDescriptor).channel

    override val size: Long

    private fun open(): android.os.ParcelFileDescriptor =
        cr.openFileDescriptor(uri, "r") ?: throw IOException("Cannot open the selected file")

    init {
        val s = pfd.statSize
        size = if (s > 0) s else channel.size()
    }

    @Synchronized
    private fun reopen() {
        try { channel.close() } catch (e: Exception) {}
        try { pfd.close() } catch (e: Exception) {}
        pfd = open()
        channel = FileInputStream(pfd.fileDescriptor).channel
    }

    override fun readAt(pos: Long, buf: ByteArray, off: Int, len: Int): Int {
        var attempt = 0
        while (true) {
            try {
                return channel.read(ByteBuffer.wrap(buf, off, len), pos)
            } catch (e: IOException) {
                // Storage providers / FUSE can drop the descriptor under load: reopen and retry.
                attempt++
                if (attempt > 3) throw e
                try { Thread.sleep(300L * attempt) } catch (x: InterruptedException) {}
                reopen()
            }
        }
    }

    override fun close() {
        try {
            channel.close()
        } catch (e: Exception) {
        }
        try {
            pfd.close()
        } catch (e: Exception) {
        }
    }
}

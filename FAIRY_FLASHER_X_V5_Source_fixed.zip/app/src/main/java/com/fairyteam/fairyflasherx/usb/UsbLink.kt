package com.fairyteam.fairyflasherx.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.io.IOException

/** Thrown when the user pressed "Stop". */
class StopRequestedException : IOException("Stopped by user")

/** Shared flag that long running USB loops poll. */
class CancelToken {
    @Volatile
    var cancelled: Boolean = false

    fun check() {
        if (cancelled) throw StopRequestedException()
    }
}

enum class LinkKind { ADB, FASTBOOT }

/** A USB interface on an attached device that speaks ADB or Fastboot. */
class UsbCandidate(val device: UsbDevice, val iface: UsbInterface, val kind: LinkKind) {
    val key: String get() = device.deviceName + "#" + kind.name
    val vidPid: String
        get() = String.format("%04x:%04x", device.vendorId, device.productId)
}

object UsbScan {
    /** ADB = class 0xFF / subclass 0x42 / protocol 1, Fastboot = protocol 3. */
    fun find(manager: UsbManager): List<UsbCandidate> {
        val out = ArrayList<UsbCandidate>()
        for (d in manager.deviceList.values) {
            for (i in 0 until d.interfaceCount) {
                val f = d.getInterface(i)
                if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42) {
                    if (f.interfaceProtocol == 1) out.add(UsbCandidate(d, f, LinkKind.ADB))
                    if (f.interfaceProtocol == 3) out.add(UsbCandidate(d, f, LinkKind.FASTBOOT))
                }
            }
        }
        return out
    }
}

/** Thin blocking wrapper around one USB interface with a bulk IN and a bulk OUT endpoint. */
class UsbLink(
    private val manager: UsbManager,
    private val device: UsbDevice,
    private val iface: UsbInterface,
    private val cancel: CancelToken
) : Closeable {

    private var conn: UsbDeviceConnection? = null
    private var epIn: UsbEndpoint? = null
    private var epOut: UsbEndpoint? = null

    fun open() {
        val c = manager.openDevice(device)
            ?: throw IOException("Cannot open the USB device. Is USB permission granted?")
        if (!c.claimInterface(iface, true)) {
            c.close()
            throw IOException("Cannot claim the USB interface (another app may be using it)")
        }
        var i: UsbEndpoint? = null
        var o: UsbEndpoint? = null
        for (n in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(n)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                if (ep.direction == UsbConstants.USB_DIR_IN) i = ep else o = ep
            }
        }
        if (i == null || o == null) {
            c.releaseInterface(iface)
            c.close()
            throw IOException("USB bulk endpoints not found")
        }
        conn = c
        epIn = i
        epOut = o
    }

    fun write(buf: ByteArray, off: Int, len: Int, timeoutMs: Int = 30000) {
        val c = conn ?: throw IOException("USB link is closed")
        val ep = epOut ?: throw IOException("USB link is closed")
        var pos = 0
        var failures = 0
        while (pos < len) {
            cancel.check()
            val n = minOf(CHUNK, len - pos)
            val r = c.bulkTransfer(ep, buf, off + pos, n, timeoutMs)
            if (r > 0) {
                pos += r
                failures = 0
                continue
            }
            // r == 0 or r < 0: transient stall / host hiccup. Clear the halt and retry a few times
            // before giving up, instead of failing the whole flash on the first bad transfer.
            failures++
            if (failures > MAX_WRITE_RETRIES) {
                throw IOException("USB write failed (device disconnected or busy)")
            }
            try {
                c.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, 1000) // CLEAR_FEATURE(ENDPOINT_HALT)
            } catch (e: Exception) {
            }
            try {
                Thread.sleep(150L * failures)
            } catch (e: InterruptedException) {
                throw StopRequestedException()
            }
        }
    }

    /** Throws away anything the device still has queued for us. */
    fun drain() {
        val c = conn ?: return
        val ep = epIn ?: return
        val tmp = ByteArray(512)
        var guard = 0
        while (guard++ < 64) {
            val r = c.bulkTransfer(ep, tmp, 0, tmp.size, 150)
            if (r <= 0) break
        }
    }

    /** Reads one bulk transfer (up to [len] bytes). Waits up to [totalTimeoutMs]. */
    fun readTransfer(buf: ByteArray, off: Int, len: Int, totalTimeoutMs: Long): Int {
        val c = conn ?: throw IOException("USB link is closed")
        val ep = epIn ?: throw IOException("USB link is closed")
        val deadline = System.currentTimeMillis() + totalTimeoutMs
        while (true) {
            cancel.check()
            val t0 = System.currentTimeMillis()
            val r = c.bulkTransfer(ep, buf, off, len, 1000)
            if (r >= 0) return r
            val now = System.currentTimeMillis()
            // A negative result that returns immediately is an error, not a timeout.
            if (now - t0 < 400) throw IOException("USB read failed (device disconnected?)")
            if (now >= deadline) throw IOException("USB read timed out")
        }
    }

    fun readFully(buf: ByteArray, len: Int, totalTimeoutMs: Long) {
        val deadline = System.currentTimeMillis() + totalTimeoutMs
        var pos = 0
        while (pos < len) {
            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) throw IOException("USB read timed out")
            val n = readTransfer(buf, pos, minOf(CHUNK, len - pos), remaining)
            pos += n // zero-length packets are simply skipped
        }
    }

    override fun close() {
        val c = conn
        conn = null
        if (c != null) {
            try {
                c.releaseInterface(iface)
            } catch (e: Exception) {
            }
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    companion object {
        private const val CHUNK = 16384
        private const val MAX_WRITE_RETRIES = 4
    }
}

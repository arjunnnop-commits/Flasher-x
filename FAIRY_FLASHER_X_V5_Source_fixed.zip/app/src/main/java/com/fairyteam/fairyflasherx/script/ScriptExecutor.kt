package com.fairyteam.fairyflasherx.script

import com.fairyteam.fairyflasherx.adb.AdbConnection
import com.fairyteam.fairyflasherx.fastboot.FastbootClient
import com.fairyteam.fairyflasherx.fastboot.FastbootException
import com.fairyteam.fairyflasherx.fastboot.FastbootFlasher
import com.fairyteam.fairyflasherx.formatSize
import com.fairyteam.fairyflasherx.io.ImageSource
import com.fairyteam.fairyflasherx.io.TreeFile
import com.fairyteam.fairyflasherx.usb.CancelToken
import com.fairyteam.fairyflasherx.usb.StopRequestedException
import java.io.IOException

class PlanItem(val step: ScriptStep, val file: TreeFile?)

/** What the executor needs from the app: device connections, logging and file access. */
interface ScriptHost {
    fun fastboot(waitMs: Long): FastbootClient
    fun adb(waitMs: Long): AdbConnection
    fun closeFastboot()
    fun closeAdb()
    fun log(text: String)
    fun progress(fraction: Float, text: String)
    fun open(file: TreeFile): ImageSource

    /** Checklist hook: state 0 waiting, 1 running, 2 done, 3 failed, 4 skipped. */
    fun stepState(index: Int, state: Int, message: String) {}

    /** A step failed. Returns what the person chose: 0 abort, 1 retry, 2 skip. */
    fun onStepFailed(index: Int, message: String): Int = 0
}

class ScriptExecutor(private val host: ScriptHost, private val cancel: CancelToken) {

    private fun pause(ms: Long) {
        var t = 0L
        while (t < ms) {
            cancel.check()
            Thread.sleep(250)
            t += 250
        }
    }

    fun run(items: List<PlanItem>, keepData: Boolean, skipLock: Boolean) {
        var waitFb = 20_000L
        var waitAdb = 20_000L
        val n = items.size
        for ((i, item) in items.withIndex()) {
            cancel.check()
            val st = item.step
            val label = "[" + (i + 1) + "/" + n + "]"
            host.progress(i.toFloat() / n, label + " " + describeStep(st))

            if (st is SkippedStep) {
                host.log("$label skipped: ${st.reason}")
                host.stepState(i, 4, st.reason)
                continue
            }
            if (keepData && isWipeStep(st)) {
                host.log("$label skipped to keep your data: ${describeStep(st)}")
                host.stepState(i, 4, "keeps your data")
                continue
            }
            if (skipLock && isLockStep(st)) {
                host.log("$label skipped (bootloader lock/unlock): ${describeStep(st)}")
                host.stepState(i, 4, "lock / unlock skipped")
                continue
            }
            host.log("$label ${describeStep(st)}")
            host.stepState(i, 1, "")

            while (true) {
            try {
            when (st) {
                is FbFlash -> {
                    val f = item.file ?: throw IOException("Image not found in the selected folder: " + st.file)
                    // Open (and unpack, if zipped) the image first so the USB link is not idle
                    // for minutes while a multi-GB file is extracted.
                    host.open(f).use { src ->
                        val fb = host.fastboot(waitFb)
                        waitFb = 20_000L
                        val maxDl = fb.getMaxDownload()
                        val targets = FastbootFlasher.resolvePartitions(fb, st.partition, st.slot)
                        for (target in targets) {
                            host.log("   " + f.name + " -> " + target + " (" + formatSize(src.size) + ")")
                            FastbootFlasher.flash(
                                fb, target, src, maxDl, cancel,
                                { done, total -> host.progress((i + done.toFloat() / total) / n, "$label $target") },
                                { msg -> host.log(msg) }
                            )
                        }
                    }
                }
                is FbErase -> {
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    for (target in FastbootFlasher.resolvePartitions(fb, st.partition, null)) {
                        try {
                            fb.command("erase:$target", 600_000L)
                        } catch (e: FastbootException) {
                            host.log("   warning: erase $target failed: ${e.message}")
                        }
                    }
                }
                is FbWipe -> {
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    for (target in listOf("userdata", "metadata")) {
                        try {
                            fb.command("erase:$target", 600_000L)
                        } catch (e: FastbootException) {
                            host.log("   warning: erase $target failed: ${e.message}")
                        }
                    }
                }
                is FbSetActive -> {
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    fb.command("set_active:" + st.slot.removePrefix("_"), 30_000L)
                }
                is FbReboot -> {
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    fb.reboot(st.target)
                    host.closeFastboot()
                    pause(3000)
                    if (st.target == "bootloader" || st.target == "fastboot") waitFb = 120_000L
                }
                is FbBoot -> {
                    val f = item.file ?: throw IOException("Image not found in the selected folder: " + st.file)
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    host.open(f).use { src ->
                        FastbootFlasher.bootImage(fb, src, cancel) { done, total ->
                            host.progress((i + done.toFloat() / total) / n, label)
                        }
                    }
                }
                is FbRaw -> {
                    val fb = host.fastboot(waitFb)
                    waitFb = 20_000L
                    try {
                        val r = fb.command(st.command, 600_000L)
                        host.log("   " + st.command + (if (r.isNotEmpty()) " = $r" else ""))
                    } catch (e: FastbootException) {
                        if (st.command.startsWith("getvar")) {
                            host.log("   warning: ${st.command} failed: ${e.message}")
                        } else {
                            throw e
                        }
                    }
                }
                is AdbRebootStep -> {
                    val c = host.adb(waitAdb)
                    waitAdb = 20_000L
                    c.reboot(st.target)
                    host.closeAdb()
                    pause(3000)
                    if (st.target == "bootloader" || st.target == "fastboot") waitFb = 120_000L
                    if (st.target == "recovery" || st.target.startsWith("sideload")) waitAdb = 120_000L
                }
                is AdbSideloadStep -> {
                    val f = item.file ?: throw IOException("File not found in the selected folder: " + st.file)
                    val c = host.adb(waitAdb)
                    waitAdb = 20_000L
                    host.open(f).use { src ->
                        c.sideload(src) { done, total ->
                            host.progress((i + done.toFloat() / total) / n, label + " sideload")
                        }
                    }
                    host.closeAdb()
                }
                is AdbShellStep -> {
                    val c = host.adb(waitAdb)
                    waitAdb = 20_000L
                    val out = c.shell(st.command)
                    if (out.isNotBlank()) host.log(out.trimEnd())
                }
                is AdbPushStep -> {
                    val f = item.file ?: throw IOException("File not found in the selected folder: " + st.local)
                    val c = host.adb(waitAdb)
                    waitAdb = 20_000L
                    host.open(f).use { src ->
                        c.push(src, st.remote) { done, total ->
                            host.progress((i + done.toFloat() / total) / n, label + " push")
                        }
                    }
                }
                is AdbWaitStep -> {
                    host.adb(maxOf(waitAdb, 120_000L))
                    waitAdb = 20_000L
                }
                else -> {}
            }
            host.stepState(i, 2, "")
            break
            } catch (e: StopRequestedException) {
                throw e
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                host.log("   ERROR: $msg")
                host.stepState(i, 3, msg)
                // The old USB link is unusable after an error. Drop it so Retry / Skip reconnect cleanly.
                try { host.closeFastboot() } catch (x: Exception) {}
                try { host.closeAdb() } catch (x: Exception) {}
                waitFb = 60_000L
                waitAdb = 60_000L
                when (host.onStepFailed(i, msg)) {
                    1 -> {
                        host.log("   retrying step " + (i + 1))
                        host.stepState(i, 1, "")
                        continue
                    }
                    2 -> {
                        host.log("   skipped by you: ${describeStep(st)}")
                        host.stepState(i, 4, "skipped by you")
                        break
                    }
                    else -> throw e
                }
            }
            }
        }
        host.progress(1f, "Finished")
        host.log("Script finished.")
    }
}

package com.fairyteam.fairyflasherx.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.onClick
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Tap feedback: the element bounces down and springs back, a soft light wave spreads from the
 * finger, and the phone gives a light tick. Put it FIRST in the modifier chain (before clip / background)
 * so the whole element scales with its background.
 */
fun Modifier.bounceClick(
    shape: Shape,
    ripple: Color = Color.White,
    enabled: Boolean = true,
    onTap: () -> Unit
): Modifier = composed {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    var touch by remember { mutableStateOf(Offset.Zero) }
    val wave = remember { Animatable(0f) }
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "tapScale"
    )
    val action by rememberUpdatedState(onTap)
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .drawWithContent {
            drawContent()
            val w = wave.value
            if (pressed || (w > 0f && w < 1f)) {
                val path = outlinePath(shape.createOutline(size, layoutDirection, this@drawWithContent))
                clipPath(path) {
                    if (pressed) drawRect(ripple.copy(alpha = 0.10f))
                    if (w > 0f && w < 1f) {
                        drawCircle(ripple.copy(alpha = 0.32f * (1f - w)), radius = size.maxDimension * 1.2f * w, center = touch)
                    }
                }
            }
        }
        .semantics { role = Role.Button; onClick { if (enabled) action(); true } }
        .pointerInput(enabled) {
            if (enabled) {
                detectTapGestures(
                    onPress = { o ->
                        touch = o
                        pressed = true
                        scope.launch {
                            wave.snapTo(0f)
                            wave.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
                        }
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        action()
                    }
                )
            }
        }
}

private fun outlinePath(o: Outline): Path = when (o) {
    is Outline.Rectangle -> Path().apply { addRect(o.rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
    is Outline.Generic -> o.path
}

// ===================================================================== background emblems

private fun DrawScope.star(center: Offset, outer: Float, color: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outer else outer * 0.42f
        val a = -PI / 2 + i * PI / 5
        val x = center.x + (r * cos(a)).toFloat()
        val y = center.y + (r * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    drawPath(p, color)
}

val LocalDecorOn = androidx.compose.runtime.compositionLocalOf { true }

/** Soft animated emblem for the selected theme. [t] runs 0..1 and loops; use 0 for a still picture. */
@androidx.compose.runtime.Composable
fun ThemeDecor(p: FairyPalette, t: Float, modifier: Modifier = Modifier.fillMaxSize(), strength: Float = 1f, always: Boolean = false) {
    if (p.decor == "none") return
    if (!always && !LocalDecorOn.current) return
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (p.decor) {
            "spiral" -> {
                val c = Offset(w * 0.88f, h * 0.10f)
                val base = minOf(w, h) * 0.22f
                rotate(t * 360f, c) {
                    for (arm in 0 until 2) {
                        val path = Path()
                        var first = true
                        var th = 0f
                        while (th < 5.2f * PI.toFloat()) {
                            val r = base * th / (5.2f * PI.toFloat())
                            val a = th + arm * PI.toFloat()
                            val x = c.x + r * cos(a)
                            val y = c.y + r * sin(a)
                            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                            th += 0.12f
                        }
                        drawPath(path, p.blob1.copy(alpha = 0.14f * strength), style = Stroke(width = base * 0.05f))
                    }
                }
            }
            "sharingan" -> {
                val c = Offset(w * 0.86f, h * 0.10f)
                val r = minOf(w, h) * 0.19f
                val col = p.blob1.copy(alpha = 0.15f * strength)
                drawCircle(col, r, c, style = Stroke(r * 0.05f))
                drawCircle(col, r * 0.58f, c, style = Stroke(r * 0.03f))
                drawCircle(col, r * 0.16f, c)
                rotate(t * 360f, c) {
                    for (i in 0 until 3) {
                        val a = i * 2f * PI.toFloat() / 3f - PI.toFloat() / 2f
                        val q = Offset(c.x + r * 0.58f * cos(a), c.y + r * 0.58f * sin(a))
                        drawCircle(col, r * 0.10f, q)
                        drawArc(
                            col, startAngle = Math.toDegrees(a.toDouble()).toFloat() + 90f, sweepAngle = 70f, useCenter = false,
                            topLeft = Offset(c.x - r * 0.58f, c.y - r * 0.58f), size = androidx.compose.ui.geometry.Size(r * 1.16f, r * 1.16f),
                            style = Stroke(r * 0.07f)
                        )
                    }
                }
            }
            "dragonball" -> {
                val r = minOf(w, h) * 0.17f
                val c = Offset(w * 0.88f, h * 0.11f + 8f * sin(t * 2f * PI.toFloat()))
                drawCircle(p.blob1.copy(alpha = 0.12f * strength), r, c)
                drawCircle(p.blob2.copy(alpha = 0.18f * strength), r, c, style = Stroke(r * 0.05f))
                val pts = listOf(Offset(0f, 0f), Offset(-0.38f, -0.2f), Offset(0.38f, -0.2f), Offset(-0.24f, 0.32f))
                for (o in pts) star(Offset(c.x + o.x * r, c.y + o.y * r), r * 0.17f, Color(0xFFE53935).copy(alpha = 0.30f * strength))
            }
            "petals" -> {
                for (i in 0 until 14) {
                    val seed = (i * 0.6180339f) % 1f
                    val speed = 0.6f + (i % 4) * 0.18f
                    val prog = (t * speed + seed) % 1f
                    val x = (seed * w + 26f * sin((prog * 6f + i).toDouble()).toFloat()) % w
                    val y = prog * (h + 60f) - 30f
                    val col = (if (i % 2 == 0) p.blob1 else p.blob3).copy(alpha = 0.32f * strength)
                    rotate(prog * 360f + i * 20f, Offset(x, y)) {
                        drawOval(col, Offset(x - 9f, y - 5f), androidx.compose.ui.geometry.Size(18f, 10f))
                    }
                }
            }
            "sparks" -> {
                for (i in 0 until 22) {
                    val seed = (i * 0.7548776f) % 1f
                    val speed = 0.5f + (i % 5) * 0.14f
                    val prog = (t * speed + seed) % 1f
                    val x = seed * w + 18f * sin((prog * 7f + i).toDouble()).toFloat()
                    val y = h - prog * (h + 40f) + 20f
                    val fade = 1f - abs(prog * 2f - 1f)
                    val col = (if (i % 3 == 0) p.blob2 else p.blob1).copy(alpha = 0.40f * fade * strength)
                    drawCircle(col, 2.2f + (i % 3), Offset(x, y))
                }
            }
        }
    }
}

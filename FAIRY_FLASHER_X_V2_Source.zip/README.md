FAIRY FLASHER X V2 — Android Studio / GitHub Actions source

UI concept based on the user's liquid-glass reference: pastel glass surfaces, cyan/pink/blue edge lighting, navigation, splash animation, dashboard, ADB/Fastboot screens, ROM flasher, device manager and About.

Important: this is a UI prototype. ADB/Fastboot command execution, USB permissions/bridge, image picker and actual flashing are NOT implemented. Do not use it for real flashing yet. The app explicitly labels those controls as placeholders.

Build requirements:
- JDK 17
- Android SDK platform 35
- Gradle 8.9
- Run: gradle assembleDebug
- Output: app/build/outputs/apk/debug/app-debug.apk

Brand: FAIRY FLASHER X
Built by @yooitachiijod
Telegram: https://t.me/FairysTeamBase

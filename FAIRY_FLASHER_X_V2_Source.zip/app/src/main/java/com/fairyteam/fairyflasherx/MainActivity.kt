package com.fairyteam.fairyflasherx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay

private val Ink = Color(0xFF17223D)
private val Muted = Color(0xFF697694)
private val Blue = Color(0xFF6967F5)
private val Cyan = Color(0xFF69E6E4)
private val Pink = Color(0xFFF18BEA)
private val Back = Color(0xFFF0F3FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FairyApp() }
    }
}

@Composable fun FairyApp() {
    var page by remember { mutableStateOf("Home") }
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1900); showSplash = false }
    MaterialTheme {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFFE9EAF8), Color(0xFFFDF3F1), Color(0xFFDDFBFA))))) {
            if (showSplash) SplashScreen() else Column(Modifier.fillMaxSize()) {
                AnimatedContent(page, label = "page") { p ->
                    when (p) {
                        "ADB Tools" -> ToolsPage("ADB Tools", "Connect • Manage • Control", listOf(
                            Triple("Detect Device", "Check ADB connection", Icons.Default.Devices),
                            Triple("Reboot", "Reboot device (system/recovery)", Icons.Default.RestartAlt),
                            Triple("Install APK", "Choose an APK to install", Icons.Default.InstallMobile),
                            Triple("Uninstall App", "Manage installed packages", Icons.Default.DeleteOutline),
                            Triple("Shell Commands", "Run a custom ADB command", Icons.Default.Terminal),
                            Triple("File Transfer", "Push / pull files", Icons.Default.Folder)
                        ))
                        "Fastboot Tools" -> ToolsPage("Fastboot Tools", "Bootloader • Partitions • Flash", listOf(
                            Triple("Detect Fastboot", "Check fastboot connection", Icons.Default.Devices),
                            Triple("Reboot to Bootloader", "Switch to fastboot mode", Icons.Default.RestartAlt),
                            Triple("Reboot to Recovery", "Restart to recovery mode", Icons.Default.Build),
                            Triple("Partition Info", "View partition details", Icons.Default.Storage),
                            Triple("Flash Image", "Select image and target partition", Icons.Default.FlashOn)
                        ))
                        "ROM Flasher" -> FlasherPage()
                        "Device Manager" -> DevicePage()
                        "About" -> AboutPage()
                        else -> HomePage(onNavigate = { page = it })
                    }
                }
                Spacer(Modifier.weight(1f, fill = false))
                NavigationBar(containerColor = Color.White.copy(alpha=.72f)) {
                    listOf("Home" to Icons.Default.Home, "ADB Tools" to Icons.Default.Terminal, "Fastboot Tools" to Icons.Default.FlashOn, "About" to Icons.Default.AutoAwesome).forEach { (name, icon) ->
                        NavigationBarItem(selected = page == name, onClick = { page = name }, icon = { Icon(icon, null) }, label = { Text(name.replace(" Tools","")) })
                    }
                }
            }
        }
    }
}

@Composable fun SplashScreen() {
    val infinite = rememberInfiniteTransition(label="glow")
    val glow by infinite.animateFloat(0.35f, 0.95f, infiniteRepeatable(tween(950), RepeatMode.Reverse), label="alpha")
    Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF080A19), Color(0xFF24143D), Color(0xFF081D35)))).padding(28.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Box(Modifier.size(176.dp).shadow(28.dp, CircleShape, ambientColor=Pink, spotColor=Blue).background(Brush.linearGradient(listOf(Color(0xFFFE315C), Color(0xFF8C4BFA), Color(0xFF50E9EE))), CircleShape).padding(4.dp).background(Color(0xFF111426), CircleShape), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Icon(Icons.Default.AutoAwesome, null, tint=Color(0xFFFF466C), modifier=Modifier.size(55.dp))
                Text("FAIRY", color=Color.White, fontSize=29.sp, fontWeight=FontWeight.Black)
                Text("TEAM", color=Pink, fontSize=23.sp, fontWeight=FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(35.dp))
        Text("FAIRY FLASHER X", color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
        Spacer(Modifier.height(24.dp))
        LinearProgressIndicator(Modifier.fillMaxWidth(.65f).height(6.dp).clip(CircleShape), color=Pink, trackColor=Color.White.copy(alpha=.2f))
        Spacer(Modifier.height(10.dp))
        Text("Initializing Fairy Team…", color=Color.White.copy(alpha=glow), fontSize=13.sp)
    }
}

@Composable fun HomePage(onNavigate:(String)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp), contentPadding=PaddingValues(top=22.dp,bottom=18.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FAIRY FLASHER X", color=Ink, fontSize=25.sp, fontWeight=FontWeight.Black)
                    Text("ADB • FASTBOOT • DEVICE CONTROL", color=Muted, fontSize=11.sp, letterSpacing=1.sp)
                }
                GlassIcon(Icons.Default.Settings, {})
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(45.dp).background(Color(0xFFE2F9EF), CircleShape), contentAlignment=Alignment.Center) { Icon(Icons.Default.PhoneAndroid, null, tint=Color(0xFF20A879), modifier=Modifier.size(25.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Device Status", fontWeight=FontWeight.Bold, color=Ink)
                        Text("Connect a device to get started", color=Muted, fontSize=12.sp)
                    }
                    Surface(color=Color(0xFFFFF0D8), shape=RoundedCornerShape(20.dp)) { Text("Offline", Modifier.padding(horizontal=11.dp, vertical=6.dp), color=Color(0xFFB67B24), fontSize=11.sp, fontWeight=FontWeight.Bold) }
                }
                Spacer(Modifier.height(18.dp))
                HorizontalDivider(color=Color.White.copy(alpha=.8f))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                    StatusItem("ADB", "Not connected", Blue)
                    StatusItem("Fastboot", "Not connected", Pink)
                    StatusItem("Mode", "Waiting", Color(0xFF1DAFAE))
                }
            }
        }
        item { Text("Quick Access", color=Ink, fontSize=18.sp, fontWeight=FontWeight.Bold) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                HomeTile("ADB Tools","Manage your device", Icons.Default.Terminal, Blue, Modifier.weight(1f)) { onNavigate("ADB Tools") }
                HomeTile("Fastboot Tools","Bootloader & flash", Icons.Default.FlashOn, Pink, Modifier.weight(1f)) { onNavigate("Fastboot Tools") }
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                HomeTile("ROM Flasher","Flash images & ROMs", Icons.Default.Memory, Color(0xFF15BFC6), Modifier.weight(1f)) { onNavigate("ROM Flasher") }
                HomeTile("Device Manager","Device actions", Icons.Default.Devices, Color(0xFF9274EF), Modifier.weight(1f)) { onNavigate("Device Manager") }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, null, tint=Blue, modifier=Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Flash safely", color=Ink, fontWeight=FontWeight.Bold)
                        Text("Verify device mode and partition before flashing.", color=Muted, fontSize=12.sp)
                    }
                }
            }
        }
    }
}

@Composable fun StatusItem(label:String, value:String, color:Color) {
    Column {
        Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(7.dp).background(color, CircleShape)); Spacer(Modifier.width(5.dp)); Text(label, color=Muted, fontSize=11.sp) }
        Text(value, color=Ink, fontSize=11.sp, fontWeight=FontWeight.SemiBold)
    }
}
@Composable fun HomeTile(title:String, subtitle:String, icon: androidx.compose.ui.graphics.vector.ImageVector, color:Color, modifier:Modifier=Modifier, onClick:()->Unit) {
    GlassCard(modifier.clickable { onClick() }) {
        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(color.copy(alpha=.24f), Color.White)), RoundedCornerShape(15.dp)), contentAlignment=Alignment.Center) { Icon(icon, null, tint=color, modifier=Modifier.size(24.dp)) }
        Spacer(Modifier.height(15.dp))
        Text(title, color=Ink, fontWeight=FontWeight.Bold, fontSize=14.sp)
        Text(subtitle, color=Muted, fontSize=11.sp)
        Spacer(Modifier.height(4.dp))
        Icon(Icons.Default.ArrowForward, null, tint=color, modifier=Modifier.align(Alignment.End))
    }
}

@Composable fun ToolsPage(title:String, subtitle:String, tools:List<Triple<String,String,androidx.compose.ui.graphics.vector.ImageVector>>) {
    var selected by remember { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp), contentPadding=PaddingValues(top=20.dp,bottom=20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text(title, color=Ink, fontSize=26.sp, fontWeight=FontWeight.Black); Text(subtitle, color=Muted) }
        item { GlassCard(Modifier.fillMaxWidth()) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Info, null, tint=Blue); Spacer(Modifier.width(8.dp)); Text("Connection backend not configured yet", color=Muted, fontSize=12.sp) } } }
        items(tools) { (name, desc, icon) ->
            GlassCard(Modifier.fillMaxWidth().clickable { selected=name }) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Color.White, Blue.copy(alpha=.18f))), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) { Icon(icon, null, tint=Blue, modifier=Modifier.size(23.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(name, color=Ink, fontWeight=FontWeight.Bold); Text(desc, color=Muted, fontSize=12.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint=Blue)
                }
            }
        }
    }
    if (selected != null) AlertDialog(onDismissRequest={selected=null}, title={Text(selected!!)}, text={Text("This control is part of the UI scaffold. ADB/Fastboot execution still needs to be implemented and tested before it can run commands.")}, confirmButton={ TextButton2("Got it") { selected=null } })
}

@Composable fun FlasherPage() {
    var image by remember { mutableStateOf("No image selected") }
    var partition by remember { mutableStateOf("Choose partition") }
    var mode by remember { mutableStateOf("Normal (recommended)") }
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding=PaddingValues(bottom=20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("ROM Flasher", color=Ink, fontSize=26.sp, fontWeight=FontWeight.Black); Text("Flash your device carefully", color=Muted) }
        item { GlassCard(Modifier.fillMaxWidth()) {
            SelectRow("Select Image", image, Icons.Default.FolderOpen) { image="Image picker not connected" }
            Spacer(Modifier.height(12.dp))
            SelectRow("Select Partition", partition, Icons.Default.Layers) { partition=if(partition=="Choose partition") "boot" else "Choose partition" }
            Spacer(Modifier.height(12.dp))
            SelectRow("Flash Mode", mode, Icons.Default.Tune) { mode=if(mode.startsWith("Normal")) "Slot-aware" else "Normal (recommended)" }
        } }
        item { GlassCard(Modifier.fillMaxWidth()) { Row(verticalAlignment=Alignment.Top) { Icon(Icons.Default.WarningAmber, null, tint=Color(0xFFEC8C44)); Spacer(Modifier.width(8.dp)); Text("Flashing can make a device unbootable if the image or partition is wrong. This screen is currently a UI prototype; it does not flash anything.", color=Muted, fontSize=12.sp) } } }
        item { Button(onClick={confirm=true}, modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(18.dp), colors=ButtonDefaults.buttonColors(containerColor=Blue)) { Text("Start Flash", fontWeight=FontWeight.Bold) } }
    }
    if(confirm) AlertDialog(onDismissRequest={confirm=false}, title={Text("Flash not available")}, text={Text("The flashing backend is not implemented yet. No partition will be modified.")}, confirmButton={ TextButton2("Understood") { confirm=false } })
}

@Composable fun SelectRow(title:String, value:String, icon:androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha=.58f)).clickable { onClick() }.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
        Icon(icon, null, tint=Blue, modifier=Modifier.size(24.dp)); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color=Ink, fontWeight=FontWeight.Bold); Text(value, color=Muted, fontSize=12.sp) }
        Icon(Icons.Default.ChevronRight, null, tint=Muted)
    }
}

@Composable fun DevicePage() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Device Manager", color=Ink, fontSize=26.sp, fontWeight=FontWeight.Black)
        Text("Connected devices", color=Muted)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.PhoneAndroid, null, tint=Blue, modifier=Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("No device detected", color=Ink, fontWeight=FontWeight.Bold); Text("Connect through a supported ADB/Fastboot bridge", color=Muted, fontSize=12.sp) }
                Icon(Icons.Default.Circle, null, tint=Color.LightGray, modifier=Modifier.size(10.dp))
            }
        }
        Text("Quick Actions", color=Ink, fontWeight=FontWeight.Bold)
        GlassCard(Modifier.fillMaxWidth()) { Text("Reboot • Recovery • Bootloader • Install APK", color=Muted, fontSize=13.sp); Spacer(Modifier.height(6.dp)); Text("Actions will be enabled after the device bridge is implemented.", color=Muted, fontSize=12.sp) }
    }
}

@Composable fun AboutPage() {
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(115.dp).background(Brush.linearGradient(listOf(Color(0xFFFF4067), Color(0xFF754BFF), Color(0xFF55E7E6))), CircleShape), contentAlignment=Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint=Color.White, modifier=Modifier.size(60.dp)) }
        Text("FAIRY FLASHER X", color=Ink, fontSize=23.sp, fontWeight=FontWeight.Black)
        Text("Liquid Glass • ADB • Fastboot", color=Muted)
        GlassCard(Modifier.fillMaxWidth()) {
            InfoRow("Built by", "@yooitachiijod")
            InfoRow("Team", "FAIRY TEAM")
            InfoRow("Telegram", "t.me/FairysTeamBase")
            InfoRow("Version", "2.0 UI Preview")
        }
        Text("Independent project. Not affiliated with Bugjaeger.", color=Muted, fontSize=11.sp)
    }
}
@Composable fun InfoRow(label:String, value:String) {
    Row(Modifier.fillMaxWidth().padding(vertical=8.dp), horizontalArrangement=Arrangement.SpaceBetween) { Text(label, color=Muted); Text(value, color=Ink, fontWeight=FontWeight.SemiBold) }
    HorizontalDivider(color=Color.White.copy(alpha=.8f))
}

@Composable fun GlassIcon(icon:androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit) {
    Surface(onClick=onClick, shape=CircleShape, color=Color.White.copy(alpha=.48f), modifier=Modifier.size(42.dp), border=BorderStroke(1.dp, Color.White.copy(alpha=.8f)), shadowElevation=8.dp) { Box(contentAlignment=Alignment.Center) { Icon(icon, null, tint=Ink) } }
}
@Composable fun GlassCard(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Column(modifier.shadow(12.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color.White.copy(alpha=.82f), Color(0xFFE8F3FF).copy(alpha=.67f), Color.White.copy(alpha=.55f)))).border(1.dp, Brush.linearGradient(listOf(Color.White, Cyan.copy(alpha=.55f), Pink.copy(alpha=.25f))), RoundedCornerShape(24.dp)).padding(16.dp), content=content)
}
@Composable fun TextButton2(label:String, onClick:()->Unit) {
    TextButton(onClick=onClick) { Text(label, color=Blue, fontWeight=FontWeight.Bold) }
}
